import re,json
from datetime import datetime
def describe(message,error):
    body=message.get('body','');subject=message.get('subject','')
    number=re.search(r'(?:#\s*|\b)(WEB-\d+)|#\s*(\d+)',subject+'\n'+body,re.I)
    delivery=re.search(r'(?:Date de livraison[^:]*|Delivery date|Desired delivery date|Date livraison)[:\t ]+\s*(\d{2}\.\d{2}\.\d{4})',body,re.I)
    try:date=datetime.strptime(delivery[1],'%d.%m.%Y').date().isoformat() if delivery else ''
    except ValueError:date=''
    reason=str(error)
    kind='unreadable'
    if 'Somma articoli' in reason:kind='totals'
    elif 'conflict' in reason or 'modificato' in reason:kind='conflict'
    elif re.search(r'Your Order|Grand Total',body):kind='format'
    return dict(subject=subject[:300],number=next((x for x in number.groups() if x),'') if number else '',supplier=message.get('supplier') or ('Munhowen' if 'munhowen' in body.lower() else 'GVS'),date=date,error=reason[:600],kind=kind)
def save(folder,period,errors,results):
    issues=[dict(x) for x in errors]
    for r in results:
        if r['status'] in ('review','conflict'):issues.append(r.get('issue') or describe(r,r.get('details',r['status'])))
    unique={}
    for item in issues:
        item.setdefault('kind','unreadable');item.setdefault('error','Messaggio Outlook non leggibile')
        key=(item.get('supplier'),item.get('number') or item.get('subject') or item.get('index'),item['error'])
        unique[key]=item
    data=list(unique.values());path=folder/('issues-'+period+'.json');tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
    return data
