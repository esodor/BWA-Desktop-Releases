from pathlib import Path
from decimal import Decimal
import re,json
from parse_gvs_text import amount

def restaurant_name(s):
 # Read address lines, not forwarded mail headers or the currently configured PC.
 lines=[line.strip() for line in s.splitlines() if line.strip()]
 names=[]
 for i,line in enumerate(lines):
  match=re.fullmatch(r"L['’]OSTERIA(?:[ \t]+(.+))?",line,re.I)
  if not match:continue
  if match[1]:names.append(match[1].strip())
  elif i+1<len(lines):
   branch=re.fullmatch(r'Lo[ \t]+(.+)',lines[i+1],re.I)
   if branch and branch[1].casefold()!='lux sarl':names.append(branch[1].strip())
 keys={re.sub(r'\s+',' ',name).casefold() for name in names}
 if len(keys)!=1:raise ValueError('Ristorante Munhowen mancante o ambiguo nel documento')
 return "L'OSTERIA "+names[0]

def parse(s):
 s=s.replace('\r','');rows=[]
 for line in s.splitlines():
  cols=[c.strip() for c in line.split('\t')]
  if not re.fullmatch(r'\d{6}',cols[0]) or len(cols)<6:continue
  num=lambda x:amount(re.sub(r'[^\d, .-]','',x))
  qty,price,total=num(cols[2]),num(cols[4]),num(cols[5])
  deposit=num(cols[7]) if len(cols)>7 and cols[7] else Decimal('0.00')
  if qty*price!=total:raise ValueError('Quantita e prezzo non coincidono per '+cols[0])
  rows.append(dict(code=cols[0],name=cols[1],quantity=str(qty),unit=cols[3],unit_price=str(price),net_total=str(total),excluded_deposit=str(deposit)))
 summary=re.search(r'^[ \t]*(?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d+)(?:,\d+)?[ \u00a0\u202f]+kg\t(.*)$',s,re.M)
 if not summary or not rows:raise ValueError('Ordine incompleto')
 totals=[num(v) for v in summary[1].split('\t') if v.strip()]
 net,tax,gross,deposit,total=totals
 if sum(Decimal(r['net_total']) for r in rows)!=net or sum(Decimal(r['excluded_deposit']) for r in rows)!=deposit or net+tax!=gross or gross+deposit!=total:raise ValueError('Totali non coerenti')
 def field(pattern):
  m=re.search(pattern,s)
  if not m:raise ValueError('Campo mancante')
  return m[1]
 return dict(supplier='Munhowen',document_type='order',number=field(r'commande\t\s*(WEB-\d+)'),order_date=field(r'Date commande\t\s*(\d{2}\.\d{2}\.\d{4})'),delivery_date=field(r'Date livraison\t\s*(\d{2}\.\d{2}\.\d{4})'),restaurant=restaurant_name(s),net_total=str(net),tax=str(tax),included_gross_total=str(gross),excluded_deposit=str(deposit),document_total=str(total),items=rows)
