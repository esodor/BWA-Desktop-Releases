from pathlib import Path
import re,json,unicodedata
from decimal import Decimal
root=Path('work/orders-samples')
months={'janvier':1,'fevrier':2,'mars':3,'avril':4,'mai':5,'juin':6,'juillet':7,'aout':8,'septembre':9,'octobre':10,'novembre':11,'decembre':12}
def amount(s):return Decimal(re.sub(r'\s','',s).replace(',','.'))
def parse(s):
 s=s.replace('\r','')
 # English GVS confirmations have the same table, but English dates and
 # currency before the amount. Normalize only these known display fields.
 english=re.search(r'Your Order\s*#(\d+)\s*\((\w+)\s+(\d+),\s*(\d{4})',s,re.I)
 if english:
  en=['january','february','march','april','may','june','july','august','september','october','november','december']
  month=en.index(english[2].lower())+1
  fr=next(k for k,v in months.items() if v==month)
  s=s[:english.start()]+f'commande est #{english[1]} ({english[3]} {fr} {english[4]}'+s[english.end():]
  s=re.sub(r'Hello,', 'Bonjour,',s,flags=re.I)
  s=re.sub(r'Desired delivery date\s*:', 'Date de livraison souhaitée:',s,flags=re.I)
  s=re.sub(r'Grand Total', 'Total final',s,flags=re.I)
  s=re.sub(r'€\s*([\d,]+\.\d{2})',lambda m:m[1].replace(',','').replace('.',',')+' €',s)
 number=re.search(r'commande est\s*#(\d+)',s,re.I)
 date=re.search(r'#\d+\s*\((\d+)\s+(\w+)\s+(\d{4})',s)
 delivery=re.search(r'Date de livraison[^:]*:\s*(\d{2}\.\d{2}\.\d{4})',s,re.I)
 restaurant=re.search(r'Bonjour,\s*(.*?)\s+LO LUX',s)
 total=re.search(r'Total final\s+([\d ,\u00a0]+,\d{2})',s)
 rows=[]
 pattern=r'^\s*(\d{3,8})\t([^\n]+)\n+\s*([\d,]+)\s+(\w+)\s*\t\s*([\d,]+)\s+(\w+)\s*\t\s*([\d ,\u00a0]+,\d{2})'
 for m in re.finditer(pattern,s,re.M):
  code,name,qty,unit,pack,packunit,value=m.groups()
  rows.append(dict(code=code,name=name.strip(),order_quantity=str(amount(qty)),order_unit=unit,price_quantity=str(amount(pack)),price_unit=packunit,total=str(amount(value))))
 if not all([number,date,delivery,restaurant,total,rows]):raise ValueError('Ordine incompleto: revisione richiesta')
 if len(rows)!=len(re.findall(r'^\s*\d{3,8}\t[^\n]+',s,re.M)):raise ValueError('Una o più righe articolo non sono leggibili: revisione richiesta')
 excluded=[r for r in rows if re.match(r'^vides\b',r['name'],re.I)]
 excluded_total=sum((Decimal(r['total']) for r in excluded),Decimal(0))
 for r in rows:r['included']=r not in excluded
 declared=amount(total[1]);calculated=sum((Decimal(r['total']) for r in rows),Decimal(0))
 if declared!=calculated:raise ValueError('Somma articoli diversa dal totale email')
 return dict(supplier='GVS',document_type='order',number=number[1],restaurant=restaurant[1],order_date=f'{date[3]}-{months[unicodedata.normalize('NFKD',date[2].lower()).encode('ascii','ignore').decode()]:02d}-{int(date[1]):02d}',delivery_date=delivery[1],total=str(declared),excluded_vides=str(excluded_total),included_total=str(declared-excluded_total),sum_items=str(calculated),difference=str(declared-calculated),items=rows)
