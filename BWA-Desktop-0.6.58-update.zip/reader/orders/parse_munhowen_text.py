from pathlib import Path
from decimal import Decimal
import re,json
from parse_gvs_text import amount

def parse(s):
 s=s.replace('\r','');rows=[]
 for line in s.splitlines():
  cols=[c.strip() for c in line.split('\t')]
  if not re.fullmatch(r'\d{6}',cols[0]) or len(cols)<6:continue
  num=lambda x:amount(re.sub(r'[^\d, .-]','',x))
  qty,price,total=num(cols[2]),num(cols[4]),num(cols[5])
  deposit=num(cols[7]) if len(cols)>7 and cols[7] else Decimal('0.00')
  if qty*price!=total:raise ValueError('Quantita e prezzo non coincidono per '+cols[0])
  rows.append(dict(code=cols[0],name=cols[1],quantity=str(qty),unit=cols[3],unit_price=str(price),net_total=str(total),excluded_deposit=str(deposit)))
 summary=re.search(r'^\s*[\d,]+ kg\t(.*)$',s,re.M)
 if not summary or not rows:raise ValueError('Ordine incompleto')
 totals=[num(v) for v in summary[1].split('\t') if v.strip()]
 net,tax,gross,deposit,total=totals
 if sum(Decimal(r['net_total']) for r in rows)!=net or sum(Decimal(r['excluded_deposit']) for r in rows)!=deposit or net+tax!=gross or gross+deposit!=total:raise ValueError('Totali non coerenti')
 def field(pattern):
  m=re.search(pattern,s)
  if not m:raise ValueError('Campo mancante')
  return m[1]
 return dict(supplier='Munhowen',document_type='order',number=field(r'commande\t\s*(WEB-\d+)'),order_date=field(r'Date commande\t\s*(\d{2}\.\d{2}\.\d{4})'),delivery_date=field(r'Date livraison\t\s*(\d{2}\.\d{2}\.\d{4})'),restaurant=field(r"(L'OSTERIA [^\n]+)"),net_total=str(net),tax=str(tax),included_gross_total=str(gross),excluded_deposit=str(deposit),document_total=str(total),items=rows)
