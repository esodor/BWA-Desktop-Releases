"""Combine an ordered, validated list of monthly scans without Office dependencies."""
import io
import json
import os
import sys
from pathlib import Path
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (ArrayObject, DecodedStreamObject, DictionaryObject,
                         NameObject, NumberObject)


def append_image(writer, entry):
    width, height = int(entry['width']), int(entry['height'])
    if width <= 0 or height <= 0 or width * height > 120_000_000:
        raise ValueError('Dimensioni della scansione non valide.')
    raw = Path(entry['path']).read_bytes()
    if not raw.startswith(b'\xff\xd8'):
        raise ValueError('Immagine JPEG non valida.')
    page_width, page_height = (841.89, 595.28) if width > height else (595.28, 841.89)
    page = writer.add_blank_page(page_width, page_height)
    scale = min((page_width - 36) / width, (page_height - 36) / height)
    shown_width, shown_height = width * scale, height * scale
    left, bottom = (page_width - shown_width) / 2, (page_height - shown_height) / 2
    image = DecodedStreamObject()
    image.set_data(raw)
    image.update({NameObject('/Type'): NameObject('/XObject'),
                  NameObject('/Subtype'): NameObject('/Image'),
                  NameObject('/Width'): NumberObject(width),
                  NameObject('/Height'): NumberObject(height),
                  NameObject('/ColorSpace'): NameObject('/DeviceRGB'),
                  NameObject('/BitsPerComponent'): NumberObject(8),
                  NameObject('/Filter'): NameObject('/DCTDecode')})
    page[NameObject('/Resources')] = DictionaryObject({
        NameObject('/XObject'): DictionaryObject({NameObject('/Scan'): writer._add_object(image)})})
    contents = DecodedStreamObject()
    contents.set_data(f'q {shown_width:.6f} 0 0 {shown_height:.6f} {left:.6f} {bottom:.6f} cm /Scan Do Q'.encode('ascii'))
    page[NameObject('/Contents')] = writer._add_object(contents)


def combine(request):
    entries = request['files']
    if not isinstance(entries, list) or not 1 <= len(entries) <= 150:
        raise ValueError('Elenco documenti Petty Cash non valido.')
    writer = PdfWriter()
    buffers = []
    for entry in entries:
        if entry['kind'] == 'pdf':
            buffer = io.BytesIO(Path(entry['path']).read_bytes())
            buffers.append(buffer)
            reader = PdfReader(buffer, strict=False)
            if reader.is_encrypted:
                raise ValueError('Una scansione PDF è protetta da password. Importa una copia leggibile.')
            if not reader.pages:
                raise ValueError('Una scansione PDF non contiene pagine.')
            # The scans are printed hand-signed pages; retain page graphics and annotations.
            writer.append(reader, import_outline=False)
        elif entry['kind'] == 'jpeg':
            append_image(writer, entry)
        else:
            raise ValueError('Formato della scansione non supportato.')
        if len(writer.pages) > 500:
            raise ValueError('Il fascicolo supera 500 pagine.')
    writer.add_metadata({'/Title': request.get('title', 'Petty Cash'), '/Producer': 'BWA Desktop'})
    output = Path(request['output'])
    temporary = output.with_suffix(output.suffix + '.tmp')
    try:
        with temporary.open('wb') as stream:
            writer.write(stream)
        with temporary.open('rb') as stream:
            check = PdfReader(stream)
            if len(check.pages) != len(writer.pages):
                raise ValueError('Conteggio delle pagine PDF non valido.')
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()
    return {'ok': True, 'pages': len(writer.pages)}


def main():
    request_path, result_path = sys.argv[1:3]
    try:
        response = combine(json.loads(Path(request_path).read_text(encoding='utf-8-sig')))
        code = 0
    except Exception as error:
        response, code = {'ok': False, 'error': str(error), 'pages': 0}, 1
    Path(result_path).write_text(json.dumps(response, ensure_ascii=False), encoding='utf-8')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
