// Returned statuses contain no credentials. Only the first-party Nesto origin is allowed.
(async () => {
  if (location.protocol !== 'https:' || !['nesto.app','account.nesto.app'].includes(location.hostname) || location.port) return 'manual-origin';
  const auth=__CREDENTIALS__;
  const visible = (e,allowDisabled=false) => { const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&(allowDisabled||!e.disabled); };
  const inputs=[...document.querySelectorAll('input')].filter(e=>visible(e));
  const description=e=>[e.name,e.id,e.autocomplete,e.placeholder].join(' ').toLowerCase();
  if(inputs.some(e=>/one-time-code|otp|verification|authenticator|totp/.test(description(e))))return 'manual-verification';
  if(inputs.some(e=>e.autocomplete==='new-password'))return 'manual-password-change';
  const passwords=inputs.filter(e=>e.type==='password');if(passwords.length>1)return 'manual-ambiguous';
  const users=inputs.filter(e=>e.type==='email'||(['text',''].includes(e.type)&&/user|email|e-mail|login/.test(description(e))));
  if(users.length>1)return 'manual-ambiguous';
  const pw=passwords[0],user=users[0];if(!pw&&!user)return 'not-found';
  const stage=pw?'password':'username';if(auth.attempted.includes(stage))return 'already-attempted';
  const form=(pw&&pw.form)||(user&&user.form);if(!form)return 'manual-form';
  if(new URL(form.action||location.href,location.href).origin!==location.origin)return 'manual-form-origin';
  const findSubmit=()=>[...form.querySelectorAll('button,input[type=submit]')].filter(e=>visible(e,true)).filter(e=>e.type==='submit'||/^(log ?in|sign ?in|anmelden|connexion|se connecter|accedi|weiter|continue|next)$/i.test((e.innerText||e.value||'').trim()));
  let submit=findSubmit();
  if(submit.length!==1||typeof form.requestSubmit!=='function')return 'manual-submit';
  const set=(el,value)=>{el.focus();Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(el,value);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));el.dispatchEvent(new Event('change',{bubbles:true}));el.blur();};
  if(user)set(user,auth.username);if(pw)set(pw,auth.password);
  await new Promise(resolve=>setTimeout(resolve,100));submit=findSubmit();
  if(submit.length!==1||submit[0].disabled)return 'manual-validation';
  if(!form.checkValidity())return 'manual-validation';
  // Use the observed form submitter; never click arbitrary links or SSO buttons.
  submit[0].click();return stage+'-submitted';
})()
