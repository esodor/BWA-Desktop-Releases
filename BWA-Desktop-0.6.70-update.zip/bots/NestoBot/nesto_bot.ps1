﻿param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{4}-\d{2}-\d{2}$')]
    [string]$Date,

    [Parameter(Mandatory = $true)]
    [string]$Output,
    [string]$EvidenceFolder,
    [switch]$VisibleBrowser
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '../AccessConfig/BrowserWindow.ps1')
if ($env:BWA_VISIBLE_BROWSER -eq '1') { $VisibleBrowser = $true }

$AppName = 'BWA-NestoBot'
$AppDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) $AppName
$ConfigFile = Join-Path $AppDir 'nesto_url.txt'
$CredentialsFile = Join-Path $AppDir 'credentials.dat'
$SettingsFile = Join-Path $AppDir 'settings.json'
$AutoLoginEnabled = $false
if (Test-Path -LiteralPath $SettingsFile) {
    try { $loginSettings = Get-Content -LiteralPath $SettingsFile -Raw | ConvertFrom-Json; $AutoLoginEnabled = ($loginSettings.auto_login -eq $true) } catch {}
}
$BaseUrl = ''
if (Test-Path -LiteralPath $ConfigFile) {
    $savedUrl = (Get-Content -LiteralPath $ConfigFile -Raw -ErrorAction Stop).Trim()
    if ($savedUrl) { $BaseUrl = $savedUrl }
}
if ($env:BWA_SUPPORT_NESTO_URL) { $BaseUrl = $env:BWA_SUPPORT_NESTO_URL }
$BaseUrl = $BaseUrl -replace '[?#].*$', ''
$BaseUrl = $BaseUrl.TrimEnd('/')
$BaseUrl = $BaseUrl -replace '/\d{4}-\d{2}-\d{2}$', ''
if ($BaseUrl -notmatch '^https://nesto\.app/[^/]+/[^/]+/recordedAssignments$') {
    throw 'Configura il link Nesto Recorded Assignments del ristorante in Admin > Accessi.'
}
$TargetUrl = "$BaseUrl/$Date"
$DisplayDate = [DateTime]::ParseExact($Date, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture).ToString('dd/MM/yyyy', [System.Globalization.CultureInfo]::InvariantCulture)
$ProfileDir = Join-Path $AppDir 'edge-profile'
$LogDir = Join-Path $AppDir 'logs'
$Port = 9339
$LoginTimeoutSeconds = 300
$ModalOpenTimeoutSeconds = 75
$CostLoadTimeoutSeconds = 120
$UiPollMilliseconds = 500

New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$LogFile = Join-Path $LogDir "nesto_${Date}_${stamp}.log"
$ScreenshotFile = Join-Path $LogDir "errore_${Date}_${stamp}.png"
$BrowserLogFile = Join-Path $LogDir "edge_${Date}_${stamp}.log"
$script:WebSocket = $null
$script:CdpId = 0
$script:Stage = 'inizializzazione'
$script:Hours = $null

function Add-Log {
    param([string]$Text)
    $line = "{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    if ($env:BWA_RUN_LOG) { try { Add-Content -LiteralPath $env:BWA_RUN_LOG -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8 } catch {} }
}

function Format-InvariantNumber {
    param([double]$Value)
    return $Value.ToString('0.00', [System.Globalization.CultureInfo]::InvariantCulture)
}

function Write-ResultFile {
    param(
        [string]$Status,
        [string]$Message,
        [double]$CrewHours = 0,
        [double]$ManagerHours = 0,
        [double]$TraineeHours = 0,
        [double]$ApprenticeHours = 0,
        [double]$TotalHours = 0,
        [double]$CrewWage = 0,
        [double]$HolidayEuro = 0,
        [double]$SickEuro = 0,
        [double]$CrewHolidayEuro = 0,
        [double]$CrewSickEuro = 0,
        [double]$ManagerHolidayEuro = 0,
        [double]$ManagerSickEuro = 0
    )

    $parent = Split-Path -Parent $Output
    if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    $safeMessage = ($Message -replace "[\r\n]+", ' ').Trim()
    $lines = @(
        "status=$Status",
        "date=$Date",
        "crew_hours=$(Format-InvariantNumber $CrewHours)",
        "manager_hours=$(Format-InvariantNumber $ManagerHours)",
        "trainee_hours=$(Format-InvariantNumber $TraineeHours)",
        "apprentice_hours=$(Format-InvariantNumber $ApprenticeHours)",
        "total_hours=$(Format-InvariantNumber $TotalHours)",
        "crew_wage=$(Format-InvariantNumber $CrewWage)",
        "holiday_euro=$(Format-InvariantNumber $HolidayEuro)",
        "sick_euro=$(Format-InvariantNumber $SickEuro)",
        "crew_holiday_euro=$(Format-InvariantNumber $CrewHolidayEuro)",
        "crew_sick_euro=$(Format-InvariantNumber $CrewSickEuro)",
        "manager_holiday_euro=$(Format-InvariantNumber $ManagerHolidayEuro)",
        "manager_sick_euro=$(Format-InvariantNumber $ManagerSickEuro)",
        "message=$safeMessage"
    )
    [System.IO.File]::WriteAllLines($Output, $lines, ([System.Text.UTF8Encoding]::new($false)))
}

function Find-EdgeExecutable {
    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($registryPath in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'
    )) {
        try {
            $value = (Get-ItemProperty -LiteralPath $registryPath -ErrorAction Stop).'(default)'
            if ($value) { $candidates.Add([string]$value) }
        } catch {}
    }

    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA, $env:ProgramW6432)) {
        if ($base) { $candidates.Add((Join-Path $base 'Microsoft\Edge\Application\msedge.exe')) }
    }

    try {
        $command = Get-Command msedge.exe -ErrorAction Stop
        if ($command.Source) { $candidates.Add([string]$command.Source) }
    } catch {}

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            Add-Log "Edge trovato: $candidate"
            return $candidate
        }
    }

    throw 'Microsoft Edge non trovato. Apri Edge almeno una volta oppure verifica che sia installato.'
}

function Test-DebugEndpoint {
    try {
        $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
        return $true
    } catch {
        return $false
    }
}

function Start-DedicatedEdge {
    $edge = Find-EdgeExecutable
    Reset-BwaLegacyHeadless -Port $Port -Profile $ProfileDir
    $backgroundMode = (-not $VisibleBrowser -and $AutoLoginEnabled -and (Test-Path -LiteralPath $CredentialsFile))
    if (-not (Test-DebugEndpoint)) {
        Add-Log "Avvio Edge dedicato: $edge"
        $arguments = @(
            "--remote-debugging-port=$Port",
            "--user-data-dir=`"$ProfileDir`"",
            '--no-first-run',
            '--no-default-browser-check',
            '--enable-logging',
            "--log-file=`"$BrowserLogFile`"",
            $TargetUrl
        )
        $backgroundMode = (-not $VisibleBrowser -and $AutoLoginEnabled -and (Test-Path -LiteralPath $CredentialsFile))
        if ($backgroundMode) {
            $arguments = @('--window-position=-32000,-32000','--window-size=1600,1000','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-background-timer-throttling') + $arguments
            Add-Log 'Edge Nesto avviato in background.'
            $windowStyle = 'Hidden'
        } else { $arguments = @('--start-maximized') + $arguments; $windowStyle = 'Normal' }
        Start-Process -FilePath $edge -ArgumentList $arguments -WindowStyle $windowStyle | Out-Null
    }

    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if (Test-DebugEndpoint) { Set-BwaBrowserVisibility -Port $Port -Profile $ProfileDir -Visible (-not $backgroundMode); Add-Log "Browser normale pronto; finestra visibile: $(-not $backgroundMode)"; return }
        Start-Sleep -Milliseconds 400
    }
    throw 'Impossibile collegarsi a Microsoft Edge.'
}

function Get-PageTarget {
    # Do not wrap the REST result in @(): Windows PowerShell 5.1 emits
    # JSON arrays as one object. The next pipeline must enumerate its pages.
    $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 5
    $pages = @($targets | Where-Object { $_.type -eq 'page' })
    if ($pages.Count -eq 0) { throw 'Nessuna pagina Edge disponibile.' }

    $preferred = $pages | Where-Object { $_.url -like '*nesto.app*' } | Select-Object -First 1
    if ($null -eq $preferred) { $preferred = $pages | Select-Object -First 1 }
    return $preferred
}

function Connect-Cdp {
    $target = Get-PageTarget
    $script:WebSocket = New-Object System.Net.WebSockets.ClientWebSocket
    $wsUrl = [string]$target.webSocketDebuggerUrl
    if ([string]::IsNullOrWhiteSpace($wsUrl)) { throw 'Nesto: URL WebSocket CDP non disponibile.' }
    [System.Uri]$uri = $wsUrl
    try {
        $null = $script:WebSocket.ConnectAsync($uri, [Threading.CancellationToken]::None).GetAwaiter().GetResult()
    } catch {
        $connectionError = $_.Exception
        while ($connectionError) {
            Add-Log ("CDP connection: " + $connectionError.GetType().FullName + ': ' + $connectionError.Message)
            $connectionError = $connectionError.InnerException
        }
        throw
    }
    # Authentication callbacks carry one-time authorization codes in their query string.
    Add-Log ("CDP collegato a " + ([string]$target.url -replace '[?#].*$', ''))
}

function Receive-WebSocketText {
    $buffer = New-Object byte[] 65536
    $stream = New-Object System.IO.MemoryStream
    do {
        $segment = [System.ArraySegment[byte]]::new($buffer)
        $result = $script:WebSocket.ReceiveAsync(
            $segment,
            [Threading.CancellationToken]::None
        ).GetAwaiter().GetResult()

        if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
            throw 'La connessione con Edge e stata chiusa.'
        }
        $stream.Write($buffer, 0, $result.Count)
    } while (-not $result.EndOfMessage)

    $text = [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
    $stream.Dispose()
    return $text
}

function Invoke-Cdp {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [hashtable]$Params = @{}
    )

    $script:CdpId++
    $id = $script:CdpId
    $request = @{ id = $id; method = $Method; params = $Params } | ConvertTo-Json -Depth 20 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($request)
    $segment = [System.ArraySegment[byte]]::new($bytes)
    $null = $script:WebSocket.SendAsync(
        $segment,
        [System.Net.WebSockets.WebSocketMessageType]::Text,
        $true,
        [Threading.CancellationToken]::None
    ).GetAwaiter().GetResult()

    while ($true) {
        $responseText = Receive-WebSocketText
        $response = $responseText | ConvertFrom-Json
        if ($response.id -eq $id) {
            if ($response.error) { throw "CDP $Method`: $($response.error.message)" }
            return $response
        }
    }
}

function Invoke-JavaScript {
    param([Parameter(Mandatory = $true)][string]$Expression)
    $response = Invoke-Cdp -Method 'Runtime.evaluate' -Params @{
        expression = $Expression
        returnByValue = $true
        awaitPromise = $true
    }
    if ($response.result.exceptionDetails) {
        throw "Errore JavaScript: $($response.result.exceptionDetails.text)"
    }
    return $response.result.result.value
}

function Get-BodyText {
    return [string](Invoke-JavaScript "(document.body && document.body.innerText) ? document.body.innerText : ''")
}

function Get-CurrentUrl {
    return [string](Invoke-JavaScript 'location.href')
}

function Press-Escape {
    try {
        Invoke-Cdp -Method 'Input.dispatchKeyEvent' -Params @{ type='keyDown'; key='Escape'; code='Escape'; windowsVirtualKeyCode=27 } | Out-Null
        Invoke-Cdp -Method 'Input.dispatchKeyEvent' -Params @{ type='keyUp'; key='Escape'; code='Escape'; windowsVirtualKeyCode=27 } | Out-Null
    } catch {}
}

function Get-NestoCredential {
    if (-not $AutoLoginEnabled -or -not (Test-Path -LiteralPath $CredentialsFile)) { return $null }
    try {
        $stored = Import-Clixml -LiteralPath $CredentialsFile -ErrorAction Stop
        if ($stored -is [Management.Automation.PSCredential]) { return $stored }
    } catch {}
    Add-Log 'Credenziali Nesto non leggibili: inserirle nuovamente in Configura accessi.'
    return $null
}

function Invoke-NestoAutoLogin {
    param([Management.Automation.PSCredential]$Credential, [string[]]$Attempted)
    if ($null -eq $Credential) { return 'disabled' }
    # Check the destination in PowerShell and again inside the page at execution time.
    $pageUri = $null
    if (-not [Uri]::TryCreate((Get-CurrentUrl),[UriKind]::Absolute,[ref]$pageUri) -or $pageUri.Scheme -ne 'https' -or $pageUri.Host -notin @('nesto.app','account.nesto.app') -or $pageUri.Port -ne 443) { return 'manual-origin' }
    $payload = $null; $expression = $null
    try {
        $payload = @{ username=$Credential.UserName; password=$Credential.GetNetworkCredential().Password; attempted=@($Attempted) } | ConvertTo-Json -Compress
        $template = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'nesto_login.js'))
        $expression = $template.Replace('__CREDENTIALS__',$payload)
        return [string](Invoke-JavaScript $expression)
    } catch {
        # Do not log exception text: it could contain the evaluated credential payload.
        Add-Log 'Accesso automatico Nesto non completato. Continuare manualmente nel browser.'
        return 'manual-error'
    } finally { $payload=$null; $expression=$null }
}

function Invoke-NestoContinue {
    $pageUri = $null
    if (-not [Uri]::TryCreate((Get-CurrentUrl),[UriKind]::Absolute,[ref]$pageUri) -or $pageUri.Scheme -ne 'https' -or $pageUri.Host -notin @('nesto.app','account.nesto.app') -or $pageUri.Port -ne 443) { return 'manual-origin' }
    $expression = @"
(() => {
  const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&!e.disabled;};
  const normalize=value=>(value||'').replace(/\s+/g,' ').trim().toLowerCase().replace(/[.!:]+$/,'');
  const allowed=/^(weiter|fortfahren|bestätigen|akzeptieren|zustimmen|erlauben|autorisieren|genehmigen|zur app|zur anwendung|continue|proceed|confirm|accept|allow|authorize|continuer|confirmer|accepter|autoriser|continua|continuare|conferma|accetta|autorizza)$/i;
  const buttons=[...document.querySelectorAll('button,input[type=submit]')].filter(visible).filter(e=>allowed.test(normalize(e.innerText||e.value)));
  if(buttons.length===0)return 'not-found';
  if(buttons.length!==1)return 'manual-ambiguous';
  buttons[0].click();return 'clicked';
})()
"@
    try { return [string](Invoke-JavaScript $expression) } catch { return 'manual-error' }
}

function Invoke-NestoSessionRecovery {
    param([bool]$AllowClick)
    $template = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'nesto_session_recovery.js'))
    $expression = $template.Replace('__ALLOW_CLICK__', $AllowClick.ToString().ToLowerInvariant())
    return [string](Invoke-JavaScript $expression)
}

function Wait-ForNestoData {
    Add-Log "Nesto base URL: $BaseUrl"
    Add-Log "Apro $TargetUrl"
    Invoke-Cdp -Method 'Page.enable' | Out-Null
    Invoke-Cdp -Method 'Runtime.enable' | Out-Null
    Invoke-Cdp -Method 'Page.navigate' -Params @{ url = $TargetUrl } | Out-Null

    # Let the authentication callback finish. Reloading after a fixed delay can
    # consume its single-use authorization code twice and strand the login page.
    Add-Log 'Attendo il completamento della pagina e dell''accesso Nesto.'
    $deadline = (Get-Date).AddSeconds($LoginTimeoutSeconds)
    $lastNavigation = Get-Date '2000-01-01'
    $loginLogged = $false
    $loginCredential = Get-NestoCredential
    $loginAttempts = @()
    $autoLoginStopped = $false
    $continueClicks = 0
    $sessionRetries = 0
    $lastSessionRetry = Get-Date '2000-01-01'
    $blankSince = $null
    $blankReloaded = $false

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 800
        try {
            $body = Get-BodyText
            $currentUrl = Get-CurrentUrl
            if ($currentUrl.TrimEnd('/') -eq $TargetUrl -and $body -match '(?i)Total\s*\(without break\)') {
                Add-Log 'Riepilogo ore trovato.'
                return $body
            }
            if ($body -match '(?i)Falscher Benutzername oder falsches Passwort|incorrect (username|user name) or password|invalid (username|user name) or password|identifiant ou mot de passe incorrect|nome utente o password (non validi|errati)') {
                throw 'Credenziali Nesto non accettate. Apri Admin > Accessi > Nesto, reinserisci username e password, attiva Accesso automatico e salva.'
            }

            $recoveryAction = Invoke-NestoSessionRecovery -AllowClick ($sessionRetries -eq 0)
            if ($recoveryAction -eq 'clicked') {
                $sessionRetries++
                $lastSessionRetry=Get-Date
                $loginAttempts=@(); $autoLoginStopped=$false; $loginLogged=$false
                Add-Log 'Nesto segnala una sessione non riuscita: premuto Zum Login e riavviato automaticamente un solo accesso.'
                Start-Sleep -Seconds 2
                continue
            }
            if ($recoveryAction -like 'failed-session*' -and ((Get-Date)-$lastSessionRetry).TotalSeconds -ge 10) {
                throw 'Sessione Nesto non riuscita anche dopo il recupero automatico. Apri Admin > Accessi > Nesto e verifica l''accesso; nessun dato della giornata è stato modificato.'
            }

            # One reload is allowed only for a blank application page that has
            # stayed on the requested date. Never reload an authentication URL.
            if ($currentUrl.TrimEnd('/') -eq $TargetUrl -and $body.Trim().Length -lt 30) {
                if ($null -eq $blankSince) { $blankSince=Get-Date }
                if (-not $blankReloaded -and ((Get-Date)-$blankSince).TotalSeconds -ge 20) {
                    Invoke-Cdp -Method 'Page.reload' -Params @{ ignoreCache=$false } | Out-Null
                    $blankReloaded=$true; $blankSince=$null
                    Add-Log 'Pagina Nesto vuota da 20 secondi: eseguito un solo aggiornamento della giornata.'
                    continue
                }
            } else { $blankSince=$null }

            $hasPassword = [bool](Invoke-JavaScript "!!document.querySelector('input[type=password]')")
            $hasLoginForm = [bool](Invoke-JavaScript "[...document.querySelectorAll('input')].some(e=>e.getBoundingClientRect().width>0 && (e.type==='password'||e.type==='email'||/username|one-time-code|otp|verification|totp/i.test([e.name,e.id,e.autocomplete].join(' '))))")
            if ($loginCredential -and -not $autoLoginStopped) {
                $loginAction = Invoke-NestoAutoLogin -Credential $loginCredential -Attempted $loginAttempts
                if ($loginAction -eq 'username-submitted') { $loginAttempts += 'username'; Add-Log 'Identificativo Nesto inviato; attendo la pagina password.'; Start-Sleep -Seconds 2; continue }
                if ($loginAction -eq 'password-submitted') { $loginAttempts += 'password'; $autoLoginStopped=$true; Add-Log 'Accesso automatico Nesto inviato; attendo la risposta.'; Start-Sleep -Seconds 2; continue }
                if ($loginAction -like 'manual-*') {
                    $autoLoginStopped=$true
                    $loginHost='sconosciuto'
                    try { $loginHost=([Uri](Get-CurrentUrl)).Host } catch {}
                    Add-Log "Accesso automatico Nesto sospeso: $loginAction (host: $loginHost)."
                }
            }
            if ($hasLoginForm -and -not $loginLogged) {
                Add-Log 'Login Nesto richiesto: attendo accesso manuale nel browser.'
                $loginLogged = $true
            }

            if (-not $hasLoginForm) {
                $currentUrl = Get-CurrentUrl
                if ($continueClicks -lt 2) {
                    $continueAction = Invoke-NestoContinue
                    if ($continueAction -eq 'clicked') {
                        $continueClicks++
                        Add-Log 'Conferma successiva al login Nesto premuta automaticamente.'
                        Start-Sleep -Seconds 2
                        continue
                    }
                    if ($continueAction -like 'manual-*') { Add-Log "Conferma Nesto non automatizzata: $continueAction." }
                }
                if ($currentUrl -like 'https://nesto.app/*' -and $currentUrl -notlike "$TargetUrl*" -and $currentUrl -notmatch '(?i)/login|/auth|/signin|/sign-in|/verify|/mfa|/otp') {
                    if (((Get-Date) - $lastNavigation).TotalSeconds -ge 5) {
                        Invoke-Cdp -Method 'Page.navigate' -Params @{ url = $TargetUrl } | Out-Null
                        $lastNavigation = Get-Date
                    }
                }
            }
        } catch {
            if ($_.Exception.Message -like 'Credenziali Nesto non accettate.*' -or $_.Exception.Message -like 'Sessione Nesto non riuscita*') { throw }
            Add-Log "Attesa pagina: $($_.Exception.Message)"
        }
    }
    throw 'Tempo scaduto. Effettua il login a Nesto e riprova.'
}

function Convert-NestoNumber {
    param([Parameter(Mandatory = $true)][string]$Raw)
    $value = $Raw.Trim()
    $value = $value -replace '€|EUR', ''
    $value = $value -replace "[\s\u00A0\u202F'’]", ''
    $lastComma = $value.LastIndexOf(',')
    $lastDot = $value.LastIndexOf('.')

    if ($lastComma -ge 0 -and $lastDot -ge 0) {
        if ($lastComma -gt $lastDot) {
            $value = $value.Replace('.', '').Replace(',', '.')
        } else {
            $value = $value.Replace(',', '')
        }
    } elseif ($lastComma -ge 0) {
        $value = $value.Replace(',', '.')
    }

    $value = $value -replace '[^0-9+\-.]', ''
    if (-not $value) { throw "Numero vuoto: $Raw" }
    return [double]::Parse($value, [System.Globalization.CultureInfo]::InvariantCulture)
}

function Get-LabeledHours {
    param([string]$Text, [string]$Label)
    $escaped = [Regex]::Escape($Label)
    $pattern = "(?im)(?:^|\r?\n|\s)$escaped\s*[:\-]?\s*([0-9][0-9.,]*)\s*h\b"
    $matches = [Regex]::Matches($Text, $pattern)
    if ($matches.Count -eq 0) { throw "Ore '$Label' non trovate." }
    return Convert-NestoNumber $matches[$matches.Count - 1].Groups[1].Value
}

function Read-HoursSummary {
    param([string]$BodyText)
    $manager = Get-LabeledHours $BodyText 'Manager'
    $crew = Get-LabeledHours $BodyText 'Crew'
    $trainee = Get-LabeledHours $BodyText 'Trainee'
    $apprentice = Get-LabeledHours $BodyText 'Apprentice'
    $total = Get-LabeledHours $BodyText 'Total (without break)'

    $calculated = $manager + $crew + $trainee + $apprentice
    if ([Math]::Abs($calculated - $total) -gt 0.05) {
        throw "Controllo ore fallito: somma=$calculated, totale=$total"
    }
    if ([Math]::Abs($trainee) -gt 0.001 -or [Math]::Abs($apprentice) -gt 0.001) {
        throw "Trainee o Apprentice non sono zero (Trainee=$trainee, Apprentice=$apprentice)."
    }

    return [PSCustomObject]@{
        Manager = $manager
        Crew = $crew
        Trainee = $trainee
        Apprentice = $apprentice
        Total = $total
    }
}


function Wait-ForStableHours {
    param([int]$TimeoutSeconds = 90)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $lastKey = ''
    $stableCount = 0
    $firstValidAt = $null
    $lastError = ''

    Add-Log "Attendo che il riepilogo ore diventi stabile (timeout ${TimeoutSeconds}s)."
    Invoke-JavaScript 'window.scrollTo(0, document.body.scrollHeight); true' | Out-Null
    Start-Sleep -Milliseconds 900

    while ((Get-Date) -lt $deadline) {
        try {
            $body = Get-BodyText
            $current = Read-HoursSummary $body

            if ($null -eq $firstValidAt) { $firstValidAt = Get-Date }

            $key = '{0:F2}|{1:F2}|{2:F2}|{3:F2}|{4:F2}' -f `
                $current.Manager, $current.Crew, $current.Trainee, `
                $current.Apprentice, $current.Total

            if ($key -eq $lastKey) {
                $stableCount++
            } else {
                Add-Log "Nuovo campione ore: Manager=$($current.Manager), Crew=$($current.Crew), Total=$($current.Total)"
                $lastKey = $key
                $stableCount = 1
            }

            # Per una giornata con ore > 0 bastano quattro letture identiche.
            # Se Nesto mostra inizialmente tutti zero, aspettiamo almeno 12 secondi:
            # evita di registrare gli zeri temporanei mentre la pagina sta caricando.
            $validAge = ((Get-Date) - $firstValidAt).TotalSeconds
            if ($current.Total -gt 0.001 -and $stableCount -ge 4) {
                Add-Log "Riepilogo ore stabile: $key"
                return $current
            }
            if ($current.Total -le 0.001 -and $stableCount -ge 8 -and $validAge -ge 12) {
                Add-Log "Riepilogo ore stabile a zero dopo attesa prudenziale: $key"
                return $current
            }
        } catch {
            $lastError = $_.Exception.Message
            Add-Log "Ore non ancora pronte: $lastError"
            $lastKey = ''
            $stableCount = 0
            $firstValidAt = $null
        }

        Start-Sleep -Milliseconds 650
    }

    if ([string]::IsNullOrWhiteSpace($lastError)) {
        $lastError = 'valori non stabilizzati'
    }
    throw "Le ore Crew/Manager non sono diventate stabili entro $TimeoutSeconds secondi: $lastError"
}

function Click-CdpPoint {
    param([double]$X, [double]$Y)

    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{
        type = 'mouseMoved'; x = $X; y = $Y
    } | Out-Null
    Start-Sleep -Milliseconds 80
    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{
        type = 'mousePressed'; x = $X; y = $Y; button = 'left'; clickCount = 1
    } | Out-Null
    Start-Sleep -Milliseconds 80
    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{
        type = 'mouseReleased'; x = $X; y = $Y; button = 'left'; clickCount = 1
    } | Out-Null
}

function Test-WageMenuVisible {
    try {
        $result = Invoke-JavaScript @'
(() => {
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05 &&
           r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };
  const norm = s => String(s || '')
    .replace(/[’`´]/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
  const rx = /today.?s\s+wage\s+evaluation/i;
  const selectors = [
    '[role="menuitem"]', '.mat-menu-item', '.mat-mdc-menu-item',
    'button', 'a', 'li', '[role="button"]', '[tabindex]', 'div', 'span'
  ].join(',');
  return [...document.querySelectorAll(selectors)]
    .some(el => visible(el) && rx.test(norm(el.innerText || el.textContent)));
})()
'@
        return [bool]$result
    } catch {
        return $false
    }
}

function Test-WageModalVisible {
    try {
        $result = Invoke-JavaScript @'
(() => {
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05;
  };
  return [...document.querySelectorAll('[role=dialog],mat-dialog-container,.mat-mdc-dialog-container,.cdk-overlay-pane,.modal,[class*=dialog]')]
    .some(el => visible(el) && /Simulated\s+wage\s+costs/i.test(el.innerText || el.textContent || ''));
})()
'@
        return [bool]$result
    } catch {
        return $false
    }
}

function Send-CdpKey {
    param(
        [Parameter(Mandatory = $true)][string]$Key,
        [Parameter(Mandatory = $true)][string]$Code,
        [Parameter(Mandatory = $true)][int]$VirtualKeyCode
    )

    Invoke-Cdp -Method 'Input.dispatchKeyEvent' -Params @{
        type = 'rawKeyDown'; key = $Key; code = $Code;
        windowsVirtualKeyCode = $VirtualKeyCode; nativeVirtualKeyCode = $VirtualKeyCode
    } | Out-Null
    Start-Sleep -Milliseconds 70
    Invoke-Cdp -Method 'Input.dispatchKeyEvent' -Params @{
        type = 'keyUp'; key = $Key; code = $Code;
        windowsVirtualKeyCode = $VirtualKeyCode; nativeVirtualKeyCode = $VirtualKeyCode
    } | Out-Null
}

function Get-WageModalCount {
    try {
        $result = Invoke-JavaScript @'
(() => {
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05;
  };

  const all = [...document.querySelectorAll(
    '[role=dialog],mat-dialog-container,.mat-mdc-dialog-container,.cdk-overlay-pane,.modal,[class*=dialog]'
  )].filter(el => visible(el) && /Simulated\s+wage\s+costs/i.test(el.innerText || el.textContent || ''));

  const outermost = all.filter(el => !all.some(other => other !== el && other.contains(el)));
  return outermost.length;
})()
'@
        return [int]$result
    } catch {
        return 0
    }
}

function Ensure-SingleWageModal {
    $count = Get-WageModalCount
    if ($count -le 1) { return }

    Add-Log "Rilevate $count finestre costi sovrapposte. Chiudo le copie in eccesso."
    $deadline = (Get-Date).AddSeconds(8)
    while ($count -gt 1 -and (Get-Date) -lt $deadline) {
        Press-Escape
        Start-Sleep -Milliseconds 600
        $count = Get-WageModalCount
    }

    if ($count -gt 1) {
        throw "Sono rimaste aperte $count finestre Simulated wage costs. Importazione annullata per evitare valori duplicati."
    }
}

function Open-WageEvaluation {
    # Open the toolbar normally; activate the verified wage item once through the DOM.
    Invoke-JavaScript 'window.scrollTo(0,0); true' | Out-Null
    Start-Sleep -Milliseconds 900

    $candidateScript = @'
(() => {
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05 &&
           r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };

  const selectors = [
    'button','[role="button"]','[aria-haspopup]','[tabindex]','a',
    'mat-icon','i','svg','div','span'
  ].join(',');

  const raw = [...document.querySelectorAll(selectors)].filter(visible);
  const items = [];

  for (const el of raw) {
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    const meta = `${el.getAttribute('aria-label') || ''} ${el.getAttribute('title') || ''} ` +
                 `${el.getAttribute('data-testid') || ''} ${el.getAttribute('class') || ''} ` +
                 `${el.innerText || ''} ${el.textContent || ''} ${el.innerHTML || ''}`;

    if (r.left < innerWidth * 0.62 || r.top < 85 || r.top > 285) continue;
    if (r.width > 150 || r.height > 120 || r.width < 4 || r.height < 4) continue;

    const pointer = s.cursor === 'pointer';
    const interactive = el.matches('button,[role="button"],[aria-haspopup],a,[tabindex]') ||
                        pointer || !!el.onclick;
    const iconLike = el.matches('svg,mat-icon,i') || !!el.querySelector('svg,mat-icon,i');
    const menuMeta = /more|action|menu|option|ellipsis|kebab|dots|weitere|mehr|more_vert|more_horiz|vertical/i.test(meta);

    // Only identified menu controls; never probe employee actions or arbitrary coordinates.
    const menuControl = el.matches('button,[role="button"],[aria-haspopup]') &&
      (/dropdown-trigger|ellipsis|kebab|more_vert|more_horiz|dots|weitere|mehr/i.test(meta) ||
       el.getAttribute('aria-haspopup') === 'menu');
    if (!menuControl) continue;

    let score = 0;
    if (menuMeta) score += 260;
    if ((el.getAttribute('aria-haspopup') || '').toLowerCase() === 'menu') score += 190;
    if (pointer) score += 80;
    if (interactive) score += 60;
    if (iconLike) score += 45;
    if (r.left > innerWidth * 0.88) score += 110;
    if (r.left > innerWidth * 0.94) score += 75;
    if (r.top >= 135 && r.top <= 245) score += 70;
    if (r.width <= 56 && r.height <= 56) score += 45;
    if ((el.innerText || '').trim() === '') score += 20;

    items.push({
      x: r.left + r.width / 2,
      y: r.top + r.height / 2,
      score,
      tag: el.tagName,
      aria: el.getAttribute('aria-label') || '',
      title: el.getAttribute('title') || '',
      cls: String(el.getAttribute('class') || '').slice(0,120)
    });
  }

  items.sort((a,b) => (b.score-a.score) || (b.x-a.x) || (a.y-b.y));
  const unique = [];
  for (const item of items) {
    if (!unique.some(u => Math.abs(u.x-item.x) < 7 && Math.abs(u.y-item.y) < 7)) {
      unique.push(item);
    }
  }
  return { width: innerWidth, height: innerHeight, candidates: unique.slice(0,35) };
})()
'@

    $candidateData = Invoke-JavaScript $candidateScript
    Add-Log ("Candidati menu desktop: " + ($candidateData | ConvertTo-Json -Depth 8 -Compress))

    $menuFound = Test-WageMenuVisible
    $menuButtonX = 0.0
    $menuButtonY = 0.0
    $candidateNumber = 0

    foreach ($candidate in @($candidateData.candidates)) {
        if ($menuFound) { break }
        Press-Escape
        Start-Sleep -Milliseconds 160
        $candidateNumber++
        Add-Log ("Click candidato menu $candidateNumber a x=$($candidate.x), y=$($candidate.y), score=$($candidate.score), tag=$($candidate.tag), aria=$($candidate.aria), title=$($candidate.title)")
        Click-CdpPoint -X ([double]$candidate.x) -Y ([double]$candidate.y)

        $deadline = (Get-Date).AddSeconds(4)
        while ((Get-Date) -lt $deadline) {
            if (Test-WageMenuVisible) {
                $menuFound = $true
                $menuButtonX = [double]$candidate.x
                $menuButtonY = [double]$candidate.y
                break
            }
            Start-Sleep -Milliseconds 200
        }
        if ($menuFound) { break }
    }

    if (-not $menuFound) {
        throw "Il menu con la voce 'Today's wage evaluation' non e comparso dopo il click sui tre puntini."
    }

    Add-Log "Menu salari aperto. Individuo la voce senza attivarla via JavaScript."
    Start-Sleep -Milliseconds 700

    $locateMenuItemScript = @'
(() => {
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05 &&
           r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };
  const norm = s => String(s || '')
    .replace(/[’`´]/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
  const rx = /today.?s\s+wage\s+evaluation/i;

  const elements = [...document.querySelectorAll('*')];
  const candidates = [];

  for (const el of elements) {
    if (!visible(el)) continue;
    const text = norm(el.innerText || el.textContent || '');
    if (!rx.test(text) || text.length > 240) continue;

    let target = el.closest && el.closest(
      'button,[role="menuitem"],[role="button"],a,li,[tabindex],.mat-menu-item,.mat-mdc-menu-item'
    );
    if (!target) target = el;
    if (!visible(target)) continue;

    const r = target.getBoundingClientRect();
    const role = target.getAttribute('role') || '';
    const cls = String(target.getAttribute('class') || '');
    let score = 0;
    if (text === "today's wage evaluation") score += 700;
    if (/menuitem/i.test(role)) score += 300;
    if (/menu-item|menuitem/i.test(cls)) score += 220;
    if (target.tagName === 'BUTTON') score += 180;
    if (r.width > 110 && r.width < 600 && r.height > 22 && r.height < 100) score += 100;
    if (r.left > innerWidth * 0.55) score += 50;
    score -= Math.min(text.length, 200);

    candidates.push({target, text, score, r});
  }

  candidates.sort((a,b) => b.score-a.score || a.text.length-b.text.length);
  if (!candidates.length) return {ok:false, reason:'no-visible-text-candidate'};

  const chosen = candidates[0];
  const target = chosen.target;
  target.scrollIntoView({block:'center', inline:'center'});
  try { target.focus({preventScroll:true}); } catch (_) { try { target.focus(); } catch (_) {} }

  const r = target.getBoundingClientRect();
  target.click(); // Exactly one dispatch on the identified menu item.
  return {
    ok:true,
    x:r.left + r.width / 2,
    y:r.top + r.height / 2,
    tag:target.tagName,
    role:target.getAttribute('role') || '',
    cls:String(target.getAttribute('class') || '').slice(0,160),
    text:chosen.text
  };
})()
'@

    $item = Invoke-JavaScript $locateMenuItemScript
    Add-Log ("Voce wage individuata: " + ($item | ConvertTo-Json -Depth 8 -Compress))
    if (-not $item.ok) {
        throw "La voce 'Today's wage evaluation' non e stata individuata nel menu."
    }

    Add-Log "Voce Today's wage evaluation attivata una sola volta tramite il controllo della pagina."

    $modalDeadline = (Get-Date).AddSeconds($ModalOpenTimeoutSeconds)
    $stableChecks = 0
    while ((Get-Date) -lt $modalDeadline) {
        if (Test-WageModalVisible) {
            $stableChecks++
            if ($stableChecks -ge 3) {
                Ensure-SingleWageModal
                Add-Log "Finestra 'Simulated wage costs' aperta stabilmente con un solo click."
                Start-Sleep -Seconds 3
                return
            }
        } else {
            $stableChecks = 0
        }
        Start-Sleep -Milliseconds 350
    }

    # Non ripetiamo il click: meglio passare al manuale che aprire due volte il
    # dialog e rischiare che Nesto accumuli i costi.
    throw "La voce 'Today's wage evaluation' e stata cliccata una volta, ma la finestra 'Simulated wage costs' non e comparsa entro $ModalOpenTimeoutSeconds secondi."
}

function Get-FirstCurrency {
    param([string]$Text, [bool]$Required = $true)
    if (-not $Text) {
        if ($Required) { throw 'Importo in euro non trovato.' }
        return 0.0
    }
    $match = [Regex]::Match($Text, "€\s*[-+]?\s*[0-9][0-9\s.,'’\u00A0\u202F]*")
    if (-not $match.Success) {
        if ($Required) { throw "Importo in euro non trovato in: $Text" }
        return 0.0
    }
    return Convert-NestoNumber $match.Value
}

function Read-DepartmentCosts {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet('Crew','Manager')]
        [string]$Department,
        [int]$TimeoutSeconds = 90
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $lastProgressLog = Get-Date '2000-01-01'
    $expandClicked = $false
    $expandAttempts = 0
    $expandClickedAt = $null
    $lastState = $null
    $stableKey = ''
    $stableCount = 0
    $detailVisibleAt = $null
    $minimumDetailWaitSeconds = 7

    $stateScript = @'
(() => {
  const displayDate = '__DISPLAY_DATE__';
  const department = '__DEPARTMENT__';
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 &&
           s.visibility !== 'hidden' && s.display !== 'none' &&
           Number(s.opacity || 1) > 0.05 &&
           r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
  };
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const moneyFindRx = /€\s*[-+]?\s*[0-9][0-9\s.,'’\u00A0\u202F]*/g;
  const moneyAnyRx = /€\s*[-+]?\s*[0-9][0-9\s.,'’\u00A0\u202F]*/;

  const dialogs = [...document.querySelectorAll(
    '[role=dialog],mat-dialog-container,.mat-mdc-dialog-container,.cdk-overlay-pane,.modal,[class*=dialog]'
  )].filter(visible);
  let root = dialogs.find(d => /Simulated\s+wage\s+costs/i.test(d.innerText || d.textContent || ''));
  if (!root) return {modal:false, department};

  const rootRect = root.getBoundingClientRect();
  const exactAll = label => [...root.querySelectorAll('*')]
    .filter(visible)
    .filter(el => norm(el.innerText || el.textContent).toLowerCase() === label.toLowerCase());

  const smallestExact = (label, minY = -Infinity, maxY = Infinity) => exactAll(label)
    .map(el => ({el, r:el.getBoundingClientRect()}))
    .filter(o => {
      const y = o.r.top + o.r.height / 2;
      return y >= minY && y < maxY;
    })
    .sort((a,b) => (a.r.width*a.r.height)-(b.r.width*b.r.height) || a.r.top-b.r.top)[0]?.el || null;

  let departmentEl = smallestExact(department);
  if (!departmentEl) {
    const offscreen = [...root.querySelectorAll('*')].filter(el => {
      const r=el.getBoundingClientRect(), s=getComputedStyle(el);
      return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden' &&
        norm(el.innerText || el.textContent).toLowerCase()===department.toLowerCase();
    }).sort((a,b)=>a.getBoundingClientRect().height-b.getBoundingClientRect().height)[0];
    if (offscreen) {
      offscreen.scrollIntoView({block:'center',inline:'nearest'});
      return {modal:true,department,departmentFound:true,scrolled:true};
    }
  }
  if (!departmentEl) return {modal:true, department, departmentFound:false};

  const depRect = departmentEl.getBoundingClientRect();
  const depY = depRect.top + depRect.height / 2;
  const topLabels = ['Manager','Crew','Trainee','Apprentice'];
  const below = [];
  for (const label of topLabels) {
    if (label.toLowerCase() === department.toLowerCase()) continue;
    const el = smallestExact(label);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    const y = r.top + r.height / 2;
    if (y > depY + 8) below.push(y);
  }
  const sectionBottom = below.length ? Math.min(...below) - 4 : rootRect.bottom - 12;
  const detailMinY = depY + Math.max(8, depRect.height * 0.40);
  const detailMaxY = Math.max(detailMinY + 20, sectionBottom);

  const salaryEl = smallestExact('Salary', detailMinY, detailMaxY);
  const holidayEl = smallestExact('Holiday', detailMinY, detailMaxY);
  const sickEl = smallestExact('sick', detailMinY, detailMaxY);

  const headerPool = [...root.querySelectorAll('*')]
    .filter(el => {
      // Horizontal column identity remains valid when its header scrolls out of view.
      const r=el.getBoundingClientRect(), s=getComputedStyle(el);
      return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden';
    })
    .map(el => {
      const r = el.getBoundingClientRect();
      return {el, r, text:norm(el.innerText || el.textContent), area:r.width*r.height};
    })
    .filter(o => o.r.top <= rootRect.top + Math.min(190, rootRect.height * 0.30));

  // Match the same calendar day regardless of the Windows date separator.
  const dateKey = text => {
    const m=norm(text).match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
    return m ? `${Number(m[3])}-${Number(m[2])}-${Number(m[1])}` : null;
  };
  const expectedDateKey=dateKey(displayDate);
  const dailyHeader = headerPool
    .filter(o => expectedDateKey !== null && dateKey(o.text) === expectedDateKey)
    .sort((a,b) => a.area-b.area || a.r.top-b.r.top)[0] || null;
  const accumulatingHeader = headerPool
    .filter(o => /accumulating/i.test(o.text))
    .sort((a,b) => a.area-b.area || b.r.left-a.r.left)[0] || null;
  const dailyX = dailyHeader ? dailyHeader.r.left + dailyHeader.r.width / 2 : null;
  const accumulatingX = accumulatingHeader
    ? accumulatingHeader.r.left + accumulatingHeader.r.width / 2
    : null;

  const findDataRow = (el, label) => {
    if (!el) return null;
    let node = el, best = null, bestArea = Number.POSITIVE_INFINITY;
    for (let i = 0; i < 12 && node && node !== root; i++, node = node.parentElement) {
      const r = node.getBoundingClientRect();
      const t = norm(node.innerText || node.textContent);
      const hasLabel = t.toLowerCase().includes(label.toLowerCase());
      const hasMoney = moneyAnyRx.test(t);
      if (visible(node) && hasLabel && hasMoney && r.width > 180 && r.height >= 24 && r.height <= 160) {
        const area = r.width * r.height;
        if (area < bestArea) { best = node; bestArea = area; }
      }
    }
    return best || el.parentElement || el;
  };

  const currencyForElement = (el, label) => {
    if (!el) return {text:'', rowText:'', reason:'label-not-found', candidates:[]};
    const row = findDataRow(el, label);
    if (!row) return {text:'', rowText:'', reason:'row-not-found', candidates:[]};

    const rowText = norm(row.innerText || row.textContent);
    const labelRect = el.getBoundingClientRect();
    const labelY = labelRect.top + labelRect.height / 2;
    const rowRect = row.getBoundingClientRect();
    const raw = [];

    for (const node of [...row.querySelectorAll('*')].filter(visible)) {
      const text = norm(node.innerText || node.textContent);
      if (!moneyAnyRx.test(text)) continue;
      const childHasMoney = [...node.children]
        .some(ch => visible(ch) && moneyAnyRx.test(norm(ch.innerText || ch.textContent)));
      if (childHasMoney) continue;
      const matches = text.match(moneyFindRx) || [];
      if (matches.length !== 1) continue;

      const r = node.getBoundingClientRect();
      const x = r.left + r.width / 2;
      const y = r.top + r.height / 2;
      const yTolerance = Math.max(42, Math.min(82, rowRect.height * 0.68));
      if (Math.abs(y - labelY) > yTolerance) continue;

      raw.push({
        text:matches[0], x, y, area:r.width*r.height,
        dxDaily:dailyX === null ? null : Math.abs(x-dailyX),
        dxAccum:accumulatingX === null ? null : Math.abs(x-accumulatingX)
      });
    }

    const unique = [];
    for (const item of raw.sort((a,b) => a.area-b.area)) {
      if (!unique.some(u => Math.abs(u.x-item.x)<6 && Math.abs(u.y-item.y)<6 && u.text===item.text)) {
        unique.push(item);
      }
    }

    let eligible = [...unique];
    let reason = '';
    if (dailyX === null) {
      eligible = [];
      reason = 'daily-header-not-found';
    } else if (accumulatingX !== null) {
      eligible = eligible.filter(v => v.dxDaily + 3 < v.dxAccum);
      if (!eligible.length) reason = 'no-candidate-in-daily-column';
    }

    let chosen = null;
    if (eligible.length) {
      chosen = eligible.sort((a,b) => {
        const sa = Math.abs(a.x-dailyX)*5 + Math.abs(a.y-labelY)*12 + a.area*0.00005;
        const sb = Math.abs(b.x-dailyX)*5 + Math.abs(b.y-labelY)*12 + b.area*0.00005;
        return sa-sb;
      })[0];
    }

    if (!chosen) {
      const matches = rowText.match(moneyFindRx) || [];
      if (matches.length === 1 && dailyX !== null) {
        chosen = {text:matches[0], x:null, y:null};
        reason = 'single-currency-row-fallback';
      }
    }

    return {
      text:chosen ? chosen.text : '', rowText, reason,
      candidates:unique.map(v => ({
        text:v.text,x:v.x,y:v.y,dxDaily:v.dxDaily,dxAccum:v.dxAccum
      })).slice(0,12)
    };
  };

  const total = currencyForElement(departmentEl, department);
  const holiday = currencyForElement(holidayEl, 'Holiday');
  const sick = currencyForElement(sickEl, 'sick');
  const detailVisible = !!(salaryEl || holidayEl || sickEl);

  let click = {ok:false};
  let expanded = detailVisible;
  if (!expanded) {
    const row = findDataRow(departmentEl, department);
    const rowRect = row ? row.getBoundingClientRect() : depRect;
    const candidates = [];
    const seen = new Set();
    const departmentRow = departmentEl.closest('tr,[role="row"]');
    const rawCandidates = [...root.querySelectorAll(
      'button,[role="button"],[aria-expanded],[tabindex],mat-icon,svg,i,span,' +
      '[class*="expand"],[class*="toggle"],[class*="chevron"],[class*="accordion"]'
    )].filter(visible);

    for (const raw of rawCandidates) {
      const target = raw.closest('button,[role="button"],[aria-expanded],[tabindex]') || raw;
      if (!visible(target) || seen.has(target)) continue;
      if (departmentRow && target.closest('tr,[role="row"]') !== departmentRow) continue;
      seen.add(target);
      const r = target.getBoundingClientRect();
      const cy = r.top + r.height / 2;
      if (Math.abs(cy-depY) > Math.max(12, Math.min(24, depRect.height*0.5+4))) continue;
      if (r.left > depRect.left + 26 || r.right < depRect.left - 95 || r.height>65) continue;

      const ariaExpanded = (target.getAttribute('aria-expanded') || '').toLowerCase();
      const meta = `${target.getAttribute('aria-label') || ''} ${target.getAttribute('title') || ''} ` +
                   `${target.getAttribute('class') || ''} ${target.textContent || ''} ${target.innerHTML || ''}`.toLowerCase();
      const plus = /^(\+|add|add_circle|add_circle_outline|expand_more)$/.test(norm(target.textContent)) ||
        /(^|[\s_-])(plus|add|expand)([\s_-]|$)/.test(meta);
      if (!plus && !target.matches('button,[role="button"],[aria-expanded],[tabindex],svg,mat-icon,i')) continue;
      const x=Math.max(0,Math.min(innerWidth-1,r.left+r.width/2));
      const y=Math.max(0,Math.min(innerHeight-1,r.top+r.height/2));
      const hit=document.elementFromPoint(x,y);
      if (!hit || !(target===hit || target.contains(hit) || hit.contains(target))) continue;
      let score = 0;
      if (plus) score += 800;
      if (ariaExpanded === 'false') score += 1200;
      if (/add|plus|expand|chevron|keyboard_arrow|accordion|toggle/.test(meta)) score += 600;
      if (target.matches('button,[role="button"],[aria-expanded]')) score += 280;
      if (r.right <= depRect.left + 10) score += 450;
      score += Math.max(0, 320-Math.abs(depRect.left-r.right)*8);
      score += Math.max(0, 180-Math.abs(cy-depY)*12);
      if (r.width <= 48 && r.height <= 48) score += 160;
      candidates.push({target,r,score,meta:meta.slice(0,160),ariaExpanded,retrySafe:ariaExpanded==='false' || plus});
    }

    candidates.sort((a,b) => b.score-a.score);
    if (candidates.length && candidates[0].ariaExpanded === 'true') expanded = true;
    if (!expanded && candidates.length) {
      const c = candidates[0], r = c.r;
      click = {
        ok:true, x:r.left+r.width/2, y:r.top+r.height/2,
        tag:c.target.tagName, kind:'nearest-control', score:c.score,
        meta:c.meta, expanded:c.ariaExpanded, retrySafe:c.retrySafe
      };
    } else if (!expanded) {
      let x = depRect.left - 18;
      x = Math.max(rowRect.left + 10, Math.min(x, depRect.left - 6));
      click = {
        ok:true, x, y:depY, tag:'POINT', kind:'left-of-department-fallback',
        score:0, meta:`rowLeft=${rowRect.left};departmentLeft=${depRect.left}`, expanded:''
      };
    }
  }

  return {
    modal:true, department, departmentFound:true,
    dailyX, accumulatingX, sectionBottom,
    detailVisible, expanded,
    salaryVisible:!!salaryEl, holidayVisible:!!holidayEl, sickVisible:!!sickEl,
    totalDaily:total.text, holidayDaily:holiday.text, sickDaily:sick.text,
    totalReason:total.reason, holidayReason:holiday.reason, sickReason:sick.reason,
    totalCandidates:total.candidates, holidayCandidates:holiday.candidates,
    sickCandidates:sick.candidates, click
  };
})()
'@
    $stateScript = $stateScript.Replace('__DISPLAY_DATE__', $DisplayDate)
    $stateScript = $stateScript.Replace('__DEPARTMENT__', $Department)

    while ((Get-Date) -lt $deadline) {
        try {
            $state = Invoke-JavaScript $stateScript
            $lastState = $state

            if (-not $state.modal) {
                Start-Sleep -Milliseconds $UiPollMilliseconds
                continue
            }
            if (-not $state.departmentFound) {
                throw "Riga $Department non trovata nella finestra costi."
            }
            if ($state.scrolled) { Start-Sleep -Milliseconds 500; continue }
            if (-not $state.detailVisible) {
                if (-not $expandClicked) {
                    if (-not $state.click.ok) {
                        throw "Pulsante + accanto a $Department non trovato."
                    }
                    $expandClicked = $true
                    $expandAttempts++
                    $expandClickedAt = Get-Date
                    Add-Log ("Espansione {0}: click verificato a x={1}, y={2}, kind={3}, meta={4}" -f $Department, $state.click.x, $state.click.y, $state.click.kind, $state.click.meta)
                    Click-CdpPoint -X ([double]$state.click.x) -Y ([double]$state.click.y)
                    Start-Sleep -Milliseconds 1800
                    continue
                }

                $elapsed = ((Get-Date) - $expandClickedAt).TotalSeconds
                # Retry only when a freshly located control still explicitly shows closed.
                # An expanded/loading panel is never toggled a second time.
                if ($elapsed -ge 8 -and $expandAttempts -lt 3 -and -not $state.expanded -and
                    $state.click.ok -and $state.click.retrySafe) {
                    $expandClicked = $false
                    Add-Log "$Department ancora chiuso; riprovo il pulsante + verificato."
                    continue
                }
                if ($elapsed -lt 35) {
                    if (((Get-Date) - $lastProgressLog).TotalSeconds -ge 5) {
                        Add-Log "$Department cliccato una volta; attendo il dettaglio senza altri click (${elapsed}s)."
                        $lastProgressLog = Get-Date
                    }
                    Start-Sleep -Milliseconds $UiPollMilliseconds
                    continue
                }
                throw "Il dettaglio $Department non si e caricato entro 35 secondi dopo il click unico."
            }

            if ([string]::IsNullOrWhiteSpace([string]$state.totalDaily)) {
                if (((Get-Date) - $lastProgressLog).TotalSeconds -ge 5) {
                    Add-Log "$Department`: attendo il totale giornaliero della riga."
                    $lastProgressLog = Get-Date
                }
                Start-Sleep -Milliseconds $UiPollMilliseconds
                continue
            }

            if (-not $detailVisibleAt) {
                $detailVisibleAt = Get-Date
                Add-Log ("{0}: dettaglio visibile. Attendo almeno {1}s prima di accettare Holiday/sick a zero." -f $Department, $minimumDetailWaitSeconds)
            }

            $key = "{0}|{1}|{2}" -f [string]$state.totalDaily, [string]$state.holidayDaily, [string]$state.sickDaily
            if ($key -eq $stableKey) {
                $stableCount++
            } else {
                $stableKey = $key
                $stableCount = 1
                Add-Log ("{0} costi: totale='{1}', Holiday='{2}', sick='{3}'" -f $Department, [string]$state.totalDaily, [string]$state.holidayDaily, [string]$state.sickDaily)
            }

            # Nesto puo mostrare subito Salary/Total e caricare Holiday/sick qualche secondo dopo.
            # Senza questa attesa il reparto Manager veniva spesso confermato prematuramente con 0/0.
            $detailAge = ((Get-Date) - $detailVisibleAt).TotalSeconds
            if ($detailAge -lt $minimumDetailWaitSeconds) {
                Start-Sleep -Milliseconds 650
                continue
            }

            if ($stableCount -lt 3) {
                Start-Sleep -Milliseconds 650
                continue
            }

            $departmentTotal = Get-FirstCurrency ([string]$state.totalDaily) $true
            $holiday = Get-FirstCurrency ([string]$state.holidayDaily) $false
            $sick = Get-FirstCurrency ([string]$state.sickDaily) $false
            if ($departmentTotal -lt 0 -or $holiday -lt 0 -or $sick -lt 0) {
                throw "Valori negativi non validi nella sezione $Department."
            }

            Add-Log ("{0} letto: Total={1}, Holiday={2}, sick={3}" -f $Department, $departmentTotal, $holiday, $sick)
            return [PSCustomObject]@{
                Department = $Department
                Total = $departmentTotal
                Holiday = $holiday
                Sick = $sick
            }
        } catch {
            Add-Log ("Attesa costi $Department`: " + $_.Exception.Message)
            Start-Sleep -Milliseconds $UiPollMilliseconds
        }
    }

    $diag = ''
    if ($lastState) {
        try { $diag = ($lastState | ConvertTo-Json -Depth 10 -Compress) } catch {}
    }
    Add-Log ("Stato finale $Department`: " + $diag)
    throw "I dati salariali $Department non sono stati caricati entro $TimeoutSeconds secondi."
}

function Read-WageCosts {
    # Wage, Holiday e sick restano separati per reparto.
    # Il BWA scrive Crew Holiday/sick nelle colonne T/U e
    # Manager Holiday/sick nelle colonne AD/AE.
    # Leggiamo prima Manager: e sopra Crew nella finestra Nesto. In questo modo
    # l'espansione di Crew non modifica la geometria della sezione Manager prima
    # che Holiday/sick Manager siano stati acquisiti.
    $manager = Read-DepartmentCosts -Department 'Manager' -TimeoutSeconds $CostLoadTimeoutSeconds
    $crew = Read-DepartmentCosts -Department 'Crew' -TimeoutSeconds $CostLoadTimeoutSeconds

    Add-Log ("Assenze separate: Crew Holiday={0}, Crew sick={1}; Manager Holiday={2}, Manager sick={3}" -f `
        $crew.Holiday, $crew.Sick, $manager.Holiday, $manager.Sick)

    return [PSCustomObject]@{
        CrewWage = $crew.Total
        CrewHoliday = $crew.Holiday
        CrewSick = $crew.Sick
        ManagerHoliday = $manager.Holiday
        ManagerSick = $manager.Sick
        Holiday = $crew.Holiday
        Sick = $crew.Sick
    }
}

function Save-EvidenceScreenshot {
    param([string]$Name)
    if (-not $EvidenceFolder) { return }
    $savedScreenshotPath = $script:ScreenshotFile
    try {
        New-Item -ItemType Directory -Path $EvidenceFolder -Force | Out-Null
        $script:ScreenshotFile = Join-Path $EvidenceFolder ($Name + '.png')
        Save-ErrorScreenshot
    } finally { $script:ScreenshotFile = $savedScreenshotPath }
}

function Save-ErrorScreenshot {
    try {
        if ($script:WebSocket -and $script:WebSocket.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $shot = Invoke-Cdp -Method 'Page.captureScreenshot' -Params @{ format='png'; captureBeyondViewport=$true }
            if ($shot.result.data) {
                [System.IO.File]::WriteAllBytes($ScreenshotFile, [Convert]::FromBase64String($shot.result.data))
            }
        }
    } catch {
        Add-Log "Screenshot errore non salvato: $($_.Exception.Message)"
    }
}

try {
    if (Test-Path -LiteralPath $Output) { Remove-Item -LiteralPath $Output -Force }
    Add-Log "Avvio NestoBot per data $Date"
    $script:Stage = 'avvio Microsoft Edge'
    Start-DedicatedEdge
    $script:Stage = 'collegamento al browser'
    Connect-Cdp
    $script:Stage = 'apertura pagina Nesto e login'
    $body = Wait-ForNestoData
    Save-EvidenceScreenshot '01-nesto-giornata'
    $script:Stage = 'attesa e lettura ore Crew e Manager'
    $hours = Wait-ForStableHours -TimeoutSeconds 90
    $script:Hours = $hours
    Save-EvidenceScreenshot '02-nesto-ore'
    Add-Log "Ore lette e salvate: Manager=$($hours.Manager), Crew=$($hours.Crew), Total=$($hours.Total)"
    Write-ResultFile -Status 'PARTIAL' -Message 'Ore lette correttamente; lettura costi in corso.' `
        -CrewHours $hours.Crew -ManagerHours $hours.Manager `
        -TraineeHours $hours.Trainee -ApprenticeHours $hours.Apprentice `
        -TotalHours $hours.Total
    $script:Stage = "apertura Today's wage evaluation"
    Open-WageEvaluation
    $script:Stage = 'lettura Wage Crew, Holiday e sick'
    $costs = Read-WageCosts
    Save-EvidenceScreenshot '03-nesto-costi'

    if ($hours.Crew -gt 0 -and $costs.CrewWage -le 0) {
        throw 'Ore Crew presenti, ma totale Wage Crew non trovato.'
    }
    if ($costs.CrewWage -gt 0 -and $hours.Total -le 0.001) {
        throw 'Nesto mostra costi Crew, ma le ore risultano ancora zero. Lettura ore non affidabile.'
    }

    Add-Log "Ore: Manager=$($hours.Manager), Crew=$($hours.Crew), Total=$($hours.Total)"
    Add-Log "Costi: CrewWage=$($costs.CrewWage), CrewHoliday=$($costs.CrewHoliday), CrewSick=$($costs.CrewSick), ManagerHoliday=$($costs.ManagerHoliday), ManagerSick=$($costs.ManagerSick), CrewHolidayOutput=$($costs.Holiday), CrewSickOutput=$($costs.Sick)"

    Write-ResultFile -Status 'OK' -Message 'Dati Nesto letti correttamente.' `
        -CrewHours $hours.Crew -ManagerHours $hours.Manager `
        -TraineeHours $hours.Trainee -ApprenticeHours $hours.Apprentice `
        -TotalHours $hours.Total -CrewWage $costs.CrewWage `
        -HolidayEuro $costs.Holiday -SickEuro $costs.Sick `
        -CrewHolidayEuro $costs.CrewHoliday -CrewSickEuro $costs.CrewSick `
        -ManagerHolidayEuro $costs.ManagerHoliday -ManagerSickEuro $costs.ManagerSick

    try { Invoke-Cdp -Method 'Browser.close' | Out-Null } catch {}
    exit 0
} catch {
    $originalFailure=$_
    try { Set-BwaBrowserVisibility -Port $Port -Profile $ProfileDir -Visible $true } catch {}
    $message = "Fase: $script:Stage. $($originalFailure.Exception.Message)"
    if (Test-Path -LiteralPath $BrowserLogFile) {
        if ($EvidenceFolder) {
            New-Item -ItemType Directory -Path $EvidenceFolder -Force | Out-Null
            Copy-Item -LiteralPath $BrowserLogFile -Destination (Join-Path $EvidenceFolder 'edge-diagnostica.log')
        }
        $browserErrors = Get-Content -LiteralPath $BrowserLogFile -Raw
        if ($browserErrors -match "GPU process isn't usable") {
            $message = 'Edge si è arrestato: il componente grafico non riesce ad avviarsi. Verificare il programma dalla propria sessione Windows. Nessun dato letto o salvato. ' + $message
        }
    }
    $failure = $originalFailure.Exception.InnerException
    while ($failure) {
        Add-Log ("Dettaglio: " + $failure.GetType().FullName + ': ' + $failure.Message)
        $failure = $failure.InnerException
    }
    Add-Log "ERRORE: $message"
    Save-ErrorScreenshot
    Save-EvidenceScreenshot 'errore-nesto'
    if ($script:Hours) {
        Write-ResultFile -Status 'PARTIAL' -Message $message `
            -CrewHours $script:Hours.Crew -ManagerHours $script:Hours.Manager `
            -TraineeHours $script:Hours.Trainee -ApprenticeHours $script:Hours.Apprentice `
            -TotalHours $script:Hours.Total
    } else {
        Write-ResultFile -Status 'ERROR' -Message $message
    }
    exit 1
} finally {
    try {
        if ($script:WebSocket) { $script:WebSocket.Dispose() }
    } catch {}
}
