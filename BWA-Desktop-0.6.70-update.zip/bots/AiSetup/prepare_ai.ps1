﻿param([string]$Language='it')
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
$Model='qwen2.5:7b'
$texts=@{
 it=@('Controllo AI locale','Download Ollama ufficiale (puo richiedere diversi minuti)','Installazione Ollama','Avvio Ollama','Download modello Mini Matteo','Verifica modello','Mini Matteo AI pronto','Preparazione AI non completata. Riprovare con una connessione Internet disponibile.');
 en=@('Checking local AI','Downloading official Ollama (may take several minutes)','Installing Ollama','Starting Ollama','Downloading Mini Matteo model','Verifying model','Mini Matteo AI ready','AI setup incomplete. Retry with an Internet connection.');
 fr=@('Verification IA locale','Telechargement officiel Ollama (plusieurs minutes possibles)','Installation Ollama','Demarrage Ollama','Telechargement du modele Mini Matteo','Verification du modele','Mini Matteo IA pret','Preparation IA incomplete. Reessayez avec une connexion Internet.');
 de=@('Lokale KI pruefen','Offizielles Ollama herunterladen (kann mehrere Minuten dauern)','Ollama installieren','Ollama starten','Mini-Matteo-Modell herunterladen','Modell pruefen','Mini Matteo KI bereit','KI-Einrichtung unvollstaendig. Mit Internetverbindung erneut versuchen.')
}
if(!$texts.ContainsKey($Language)){$Language='it'}
function Report([int]$Index,[string]$Suffix=''){Write-Output ($texts[$Language][$Index]+' '+$Suffix)}
function LocalRequest([string]$Path,[string]$Body=''){
 $r=[Net.HttpWebRequest]::Create('http://127.0.0.1:11434/api/'+$Path);$r.Proxy=$null;$r.AllowAutoRedirect=$false;$r.Timeout=10000;$r.ReadWriteTimeout=10000
 if($Body){$r.Method='POST';$r.ContentType='application/json';$b=[Text.Encoding]::UTF8.GetBytes($Body);$r.ContentLength=$b.Length;$s=$r.GetRequestStream();try{$s.Write($b,0,$b.Length)}finally{$s.Dispose()}}
 $response=$r.GetResponse();try{$reader=[IO.StreamReader]::new($response.GetResponseStream());try{return ($reader.ReadToEnd()|ConvertFrom-Json)}finally{$reader.Dispose()}}finally{$response.Dispose()}
}
function Available {try{$v=LocalRequest 'version';return [bool]$v.version}catch{return $false}}
function HasModel {$tags=LocalRequest 'tags';return @($tags.models|Where-Object {$_.name -eq $Model -or $_.model -eq $Model}).Count -gt 0}
function FindOllama {
 $standard=Join-Path $env:LOCALAPPDATA 'Programs/Ollama/ollama.exe';if(Test-Path -LiteralPath $standard){return $standard}
 $command=Get-Command ollama.exe -ErrorAction SilentlyContinue;if($command){return $command.Source};return $null
}
function InstallOllama {
 Report 1
 $headers=@{'User-Agent'='BWA-Desktop-AI-Setup';Accept='application/vnd.github+json'}
 $release=Invoke-RestMethod -Uri 'https://api.github.com/repos/ollama/ollama/releases/latest' -Headers $headers -TimeoutSec 60
 $asset=@($release.assets|Where-Object {$_.name -eq 'OllamaSetup.exe'})
 if($asset.Count -ne 1 -or $asset[0].digest -notmatch '^sha256:[a-fA-F0-9]{64}$'){throw 'Official installer checksum unavailable'}
 $asset=$asset[0];$url=[Uri]$asset.browser_download_url
 if($url.Scheme -ne 'https' -or $url.Host -ne 'github.com' -or !$url.AbsolutePath.StartsWith('/ollama/ollama/releases/download/')){throw 'Unexpected installer source'}
 $cache=Join-Path $env:LOCALAPPDATA 'BWA-Desktop/ai-setup';[IO.Directory]::CreateDirectory($cache)|Out-Null
 $setup=Join-Path $cache ($asset.digest.Substring(7)+'.exe')
 if(!(Test-Path -LiteralPath $setup) -or (Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $asset.digest.Substring(7).ToLowerInvariant()){
  $client=[Net.WebClient]::new();try{$client.DownloadFile($url,$setup)}finally{$client.Dispose()}
 }
 if((Get-FileHash -LiteralPath $setup -Algorithm SHA256).Hash.ToLowerInvariant() -ne $asset.digest.Substring(7).ToLowerInvariant()){throw 'Ollama installer checksum mismatch'}
 if((Get-AuthenticodeSignature -LiteralPath $setup).Status -ne 'Valid'){throw 'Ollama installer signature invalid'}
 Report 2
 $p=Start-Process -FilePath $setup -ArgumentList '/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-' -WindowStyle Hidden -PassThru
 if(!$p.WaitForExit(1800000)){throw 'Ollama installation is still running; retry after completion'}
 if($p.ExitCode -notin @(0,3010)){throw ('Ollama installer exit '+$p.ExitCode)}
}
function PullModel {
 Report 4
 $r=[Net.HttpWebRequest]::Create('http://127.0.0.1:11434/api/pull');$r.Proxy=$null;$r.AllowAutoRedirect=$false;$r.Method='POST';$r.ContentType='application/json';$r.Timeout=60000;$r.ReadWriteTimeout=180000
 $b=[Text.Encoding]::UTF8.GetBytes((@{model=$Model;stream=$true}|ConvertTo-Json -Compress));$r.ContentLength=$b.Length
 $s=$r.GetRequestStream();try{$s.Write($b,0,$b.Length)}finally{$s.Dispose()}
 $response=$r.GetResponse();$success=$false;$last='';$clock=[Diagnostics.Stopwatch]::StartNew()
 try{$reader=[IO.StreamReader]::new($response.GetResponseStream());try{
  while(($line=$reader.ReadLine()) -ne $null){
   if($clock.Elapsed.TotalHours -gt 4){throw 'Model download timeout; retry to resume'}
   $part=$line|ConvertFrom-Json;if($part.error){throw [string]$part.error}
   if($part.status -eq 'success'){$success=$true}
   if($part.total -gt 0){$progress=([Math]::Min(100,[Math]::Floor(100.0*$part.completed/$part.total))).ToString()+'%';if($progress -ne $last){Report 4 $progress;$last=$progress}}
  }
 }finally{$reader.Dispose()}}finally{$response.Dispose()}
 if(!$success){throw 'Incomplete model download; retry to resume'}
}
try{
 Report 0
 if(!(Available)){
  $exe=FindOllama;if(!$exe){InstallOllama;$exe=FindOllama}
  if(!$exe){throw 'Ollama executable not found after installation'}
  if(!(Available)){Report 3;Start-Process -FilePath $exe -ArgumentList 'serve' -WindowStyle Hidden -PassThru|Out-Null}
  $deadline=[DateTime]::UtcNow.AddSeconds(90);while(!(Available)){if([DateTime]::UtcNow -gt $deadline){throw 'Ollama local server unavailable'};Start-Sleep -Milliseconds 500}
 }
 if(!(HasModel)){PullModel}
 Report 5
 if(!(HasModel)){throw 'Model missing after download'}
 $show=LocalRequest 'show' (@{model=$Model}|ConvertTo-Json -Compress)
 if(!$show.details){throw 'Model validation failed'}
 Report 6;exit 0
}catch{Write-Output ($texts[$Language][7]+' '+$_.Exception.Message);exit 1}
