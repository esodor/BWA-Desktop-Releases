// Reads Lightspeed's rendered receipt, retaining the reported tax bases and VAT.
// No inverse reconstruction of tax amounts is permitted.
(function(root){
 'use strict';
 function fail(message){throw new Error(message);}
 function cents(value){
  var s=String(value).replace(/[\s\u00a0\u202f'€]/g,'');
  if(s.indexOf(',')>=0&&s.indexOf('.')>=0){var comma=s.lastIndexOf(',')>s.lastIndexOf('.');s=comma?s.replace(/\./g,'').replace(',','.'):s.replace(/,/g,'');}
  else s=s.replace(',','.');
  if(!/^-?\d+(?:\.\d{1,2})?$/.test(s))fail('Importo del ticket non leggibile: '+value);
  var n=Number(s);if(!Number.isFinite(n))fail('Importo non valido');return Math.round(n*100);
 }
 function parseReceipt(text,expected){
  text=String(text).replace(/\r/g,'');
  var ticket=String(expected.ticket),escaped=ticket.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  var header=text.match(new RegExp('Ticket\\s+'+escaped+'\\s+(\\d{2})/(\\d{2})/(\\d{4})\\s+\\d{2}:\\d{2}'));
  if(!header)fail('Il dettaglio non contiene il ticket atteso '+ticket);
  var printedDate=header[3]+'-'+header[2]+'-'+header[1];
  var delta=(Date.parse(printedDate+'T00:00:00Z')-Date.parse(expected.date+'T00:00:00Z'))/86400000;
  if(delta!==0&&delta!==1)fail('La data stampata del ticket non corrisponde alla giornata');
  var total=text.match(/^\s*Total\s+€\s*([\d.,\s\u00a0\u202f]+)\s*$/mi);
  var netTotal=text.match(/\(HT:\s*€\s*([\d.,\s\u00a0\u202f]+)\)/i);
  if(!total||!netTotal)fail('Totali lordo/netto non presenti nel ticket');
  var gross=cents(total[1]),net=cents(netTotal[1]);
  if(gross!==cents(expected.total)||gross<=0)fail('Il totale del ticket non coincide con il riepilogo Lightspeed');
  var taxes=[],seen={},sumGross=0,sumNet=0,sumVat=0;
  var lines=text.split('\n');
  lines.forEach(function(line){
   if(!/^\s*[A-Z]:\s*TVA\b/i.test(line))return;
   var match=line.match(/^\s*[A-Z]:\s*TVA\s+(\d+(?:[.,]\d+)?)%\s+sur\s+([\d.,\s\u00a0\u202f]+):\s*€\s*([\d.,\s\u00a0\u202f]+)\s*\(([\d.,\s\u00a0\u202f]+)\)\s*$/i);
   if(!match)fail('Dettaglio IVA non riconosciuto: '+line.trim());
   var rate=Number(match[1].replace(',','.')),n=cents(match[2]),v=cents(match[3]),g=cents(match[4]);
   if([0,3,14,17].indexOf(rate)<0||seen[rate]||n<0||v<0||g<0||n+v!==g)fail('Riga IVA non valida o aliquota non supportata');
   seen[rate]=true;sumGross+=g;sumNet+=n;sumVat+=v;taxes.push({Rate:rate,Gross:g/100,ReportedNet:n/100,ReportedVat:v/100});
  });
  if(!taxes.length||sumGross!==gross||sumNet!==net||sumVat!==gross-net)fail('Le righe IVA non quadrano con i totali stampati sul ticket');
  [0,3,14,17].forEach(function(rate){if(!seen[rate])taxes.push({Rate:rate,Gross:0,ReportedNet:0,ReportedVat:0});});
  taxes.sort(function(a,b){return a.Rate-b.Rate;});
  var payment=0,paymentLines=0,tip=0;
  lines.forEach(function(line){
   var p=line.match(/^\s*Facture\s+€\s*([\d.,\s\u00a0\u202f]+)\s*$/i);if(p){payment+=cents(p[1]);paymentLines++;}
   var t=line.match(/^\s*(?:Pourboire|Gratuity|Tip|Trinkgeld)\s*:?\s*€\s*([\d.,\s\u00a0\u202f]+)\s*$/i);if(t)tip+=cents(t[1]);
  });
  if(!paymentLines||payment<=0||payment>gross+tip)fail('Montant du paiement Facture non vérifiable sur le ticket');
  if(tip<0)fail('Mance non valide nel ticket');
  return {Date:expected.date,PrintedDate:printedDate,Ticket:ticket,Tip:tip/100,PaymentAmount:payment/100,Taxes:taxes,MixedPayment:payment!==gross+tip};
 }
 root.BwaInvoiceReader={cents:cents,parseReceipt:parseReceipt};
 if(typeof module!=='undefined'&&module.exports)module.exports=root.BwaInvoiceReader;
})(typeof window!=='undefined'?window:globalThis);
