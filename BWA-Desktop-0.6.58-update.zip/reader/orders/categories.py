﻿import json
from decimal import Decimal
from collections import defaultdict
from orders import ROOT,identity

LABELS={'food':'Cibo','vegetables':'Frutta e verdura','beverages':'Bevande','paper':'Carta','tableware':'Stoviglie','cleaning':'Pulizia','op':'OP','marketing':'Marketing / LSM','vides':'Vides / cauzioni (esclusi)'}

class Categories:
    def __init__(self,archive):
        self.db=archive.db
        self.db.execute('CREATE TABLE IF NOT EXISTS categories(restaurant TEXT,supplier TEXT,code TEXT,category TEXT,PRIMARY KEY(restaurant,supplier,code))')
        self.db.execute('CREATE TABLE IF NOT EXISTS reviewed_categories(restaurant TEXT,supplier TEXT,code TEXT,category TEXT,source TEXT,reason TEXT,PRIMARY KEY(restaurant,supplier,code))')
        from verified import apply_verified
        apply_verified(self.db)
        path=ROOT/'category-candidates.json'
        self.candidates={r['code']:r for r in json.loads(path.read_text(encoding='utf-8'))['products']} if path.exists() else {}
    def confirm(self,restaurant,supplier,codes,category):
        if category not in LABELS or supplier not in ('GVS','Munhowen'):raise ValueError('Categoria o fornitore non valido')
        if not codes or any(not str(c).strip() for c in codes):raise ValueError('Codice articolo mancante')
        with self.db:
            for code in codes:self.db.execute('INSERT OR REPLACE INTO categories VALUES(?,?,?,?)',(identity(restaurant),supplier,str(code),category))
    def lines(self,order):
        results=[]
        for item in order['items']:
            code=item['code'];supplier=order['supplier'];fixed=not item.get('included',True)
            row=self.db.execute('SELECT category FROM categories WHERE restaurant=? AND supplier=? AND code=?',(identity(order['restaurant']),supplier,code)).fetchone()
            category=None;confirmed=False;source=None
            reviewed=self.db.execute('SELECT category,source FROM reviewed_categories WHERE restaurant=? AND supplier=? AND code=?',(identity(order['restaurant']),supplier,code)).fetchone()
            if fixed:category='vides';confirmed=True;source='document'
            elif row:category=row[0];confirmed=True;source='user'
            elif reviewed:category=reviewed[0];confirmed=True;source='bomito_verified' if reviewed[1]=='bomito_verified' else 'assistant_review'
            elif supplier=='GVS':
                candidate=self.candidates.get(code,{})
                if candidate.get('category') in LABELS and candidate['category']!='vides':category=candidate['category']
            elif supplier=='Munhowen':category='beverages'
            results.append(dict(code=code,name=item['name'],amount=item.get('total',item.get('net_total')),category=category,confirmed=confirmed,source=source,excluded=fixed or (confirmed and category=='vides'),fixed_exclusion=fixed))
        return results
    def summary(self,order):
        confirmed=defaultdict(Decimal);suggested=defaultdict(Decimal);pending=Decimal(0);excluded=Decimal(order.get('excluded_deposit','0'))
        for line in self.lines(order):
            value=Decimal(line['amount'])
            if line['excluded']:excluded+=value
            elif line['confirmed']:confirmed[line['category']]+=value
            else:
                pending+=value
                if line['category']:suggested[line['category']]+=value
        return dict(confirmed=dict(confirmed),suggested=dict(suggested),pending=pending,excluded=excluded)

def open_editor(parent,archive_folder,order,on_saved):
    import tkinter as tk
    from tkinter import ttk,messagebox
    from orders import Archive
    window=tk.Toplevel(parent);window.title('Categorie - '+order['supplier']+' '+order['number']);window.geometry('1040x670')
    archive=Archive(archive_folder);categories=Categories(archive);rows=[]
    ttk.Label(window,text=order['supplier']+' '+order['number']+' | '+order['restaurant'],font=('Segoe UI',15,'bold')).pack(anchor='w',padx=16,pady=12)
    ttk.Label(window,text='Seleziona uno o piu articoli, scegli la categoria e conferma. Le stime non sono categorie confermate.').pack(anchor='w',padx=16)
    tree=ttk.Treeview(window,columns=('code','name','amount','category','status'),show='headings',selectmode='extended')
    for key,label,width in [('code','Codice',85),('name','Articolo',390),('amount','Importo EUR',95),('category','Categoria',180),('status','Stato',155)]:tree.heading(key,text=label);tree.column(key,width=width)
    scroll=ttk.Scrollbar(window,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=scroll.set)
    scroll.pack(side='right',fill='y');tree.pack(fill='both',expand=True,padx=16,pady=12)
    controls=ttk.Frame(window);controls.pack(fill='x',padx=16)
    choice=ttk.Combobox(controls,state='readonly',values=list(LABELS.values()),width=34);choice.pack(side='left')
    summary=tk.Text(window,height=9,wrap='word');summary.pack(fill='x',padx=16,pady=12)
    def refresh():
        nonlocal rows
        rows=categories.lines(order);tree.delete(*tree.get_children())
        for i,line in enumerate(rows):tree.insert('', 'end',iid=str(i),values=(line['code'],line['name'],line['amount'],LABELS.get(line['category'],'Da assegnare'),'Escluso' if line['excluded'] else 'Revisionata assistente' if line['source']=='assistant_review' else 'Confermata da te' if line['confirmed'] else 'Proposta da verificare'))
        data=categories.summary(order);text=['Base: '+order['amount_basis'],'Categorie assegnate (tue conferme e revisione assistente):']
        text += [LABELS[k]+': '+str(v)+' EUR' for k,v in data['confirmed'].items()]
        text += ['Importo ancora da confermare: '+str(data['pending'])+' EUR','Vides / cauzioni esclusi: '+str(data['excluded'])+' EUR','Proposte (gia comprese nell’importo da confermare):']
        text += [LABELS[k]+': '+str(v)+' EUR' for k,v in data['suggested'].items()]
        summary.configure(state='normal');summary.delete('1.0','end');summary.insert('end','\n'.join(text));summary.configure(state='disabled')
    def select(event):
        ids=tree.selection()
        if ids:choice.set(LABELS.get(rows[int(ids[0])]['category'],''))
    tree.bind('<<TreeviewSelect>>',select)
    def save():
        ids=tree.selection();category=next((k for k,v in LABELS.items() if v==choice.get()),None)
        if not ids or category is None:return
        selected=[rows[int(i)] for i in ids]
        if any(r['fixed_exclusion'] for r in selected):messagebox.showinfo('Vides','Le righe Vides dell’ordine restano escluse.',parent=window);return
        try:
            categories.confirm(order['restaurant'],order['supplier'],[r['code'] for r in selected],category)
            refresh();on_saved()
        except Exception as error:messagebox.showerror('Categorie',str(error),parent=window)
    ttk.Button(controls,text='Conferma categoria',command=save).pack(side='left',padx=12)
    ttk.Label(controls,text='La scelta vale anche per gli altri ordini dello stesso articolo.').pack(side='left')
    window.protocol('WM_DELETE_WINDOW',window.destroy)
    window.bind('<Destroy>',lambda event:archive.close() if event.widget is window else None)
    refresh()
