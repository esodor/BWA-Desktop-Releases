﻿function Get-BwaWindowsDownloads {
    try {
        $shell = New-Object -ComObject Shell.Application
        try {
            $folder = $shell.NameSpace('shell:Downloads')
            if ($folder -and $folder.Self.Path -and [IO.Path]::IsPathRooted($folder.Self.Path)) { return $folder.Self.Path }
        } finally { if ($shell) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell) } }
    } catch {}
    try {
        $key = Get-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' -ErrorAction Stop
        $found = [Environment]::ExpandEnvironmentVariables([string]$key.'{374DE290-123F-4565-9164-39C4925E467B}')
        if ($found -and [IO.Path]::IsPathRooted($found)) { return $found }
    } catch {}
    return (Join-Path $env:USERPROFILE 'Downloads')
}
function Resolve-BwaDownloadFolder {
    param([string]$Override, [string]$Configured)
    $path = if ($Override) { $Override } elseif ($Configured) { $Configured } else { Get-BwaWindowsDownloads }
    $path = [Environment]::ExpandEnvironmentVariables($path.Trim())
    if (-not [IO.Path]::IsPathRooted($path)) { throw 'Choose an absolute download folder in Admin > Access.' }
    return [IO.Path]::GetFullPath($path)
}
