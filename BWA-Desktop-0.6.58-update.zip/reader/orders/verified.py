"""Apply an explicitly approved, restaurant-scoped Bomito review exactly once."""
import json
from orders import ROOT,identity

def apply_verified(db):
    path=ROOT/'bomito-verified.json'
    if not path.exists():return
    seed=json.loads(path.read_text(encoding='utf-8'))
    restaurant=identity(seed['restaurant']);revision=seed['id']
    db.execute('CREATE TABLE IF NOT EXISTS category_migrations(id TEXT PRIMARY KEY,applied_at TEXT DEFAULT CURRENT_TIMESTAMP)')
    db.execute('CREATE TABLE IF NOT EXISTS category_migration_changes(id TEXT,restaurant TEXT,supplier TEXT,code TEXT,previous_user TEXT,previous_review TEXT,category TEXT,account TEXT,document TEXT,PRIMARY KEY(id,restaurant,supplier,code))')
    with db:
        if db.execute('SELECT 1 FROM category_migrations WHERE id=?',(revision,)).fetchone():return
        for item in seed['products']:
            key=(restaurant,item['supplier'],item['code'])
            old=db.execute('SELECT category FROM categories WHERE restaurant=? AND supplier=? AND code=?',key).fetchone()
            review=db.execute('SELECT category,source,reason FROM reviewed_categories WHERE restaurant=? AND supplier=? AND code=?',key).fetchone()
            db.execute('INSERT INTO category_migration_changes VALUES(?,?,?,?,?,?,?,?,?)',(revision,*key,old[0] if old else None,json.dumps(list(review)) if review else None,item['category'],item['account'],item['document']))
            # Only this approved revision can replace a manual choice; future user
            # changes keep priority and this migration never runs a second time.
            db.execute('DELETE FROM categories WHERE restaurant=? AND supplier=? AND code=?',key)
            db.execute('INSERT OR REPLACE INTO reviewed_categories VALUES(?,?,?,?,?,?)',(*key,item['category'],'bomito_verified','Bomito '+item['account']+' / '+item['document']+' / '+seed['verified_at']))
        db.execute('INSERT INTO category_migrations(id) VALUES(?)',(revision,))
