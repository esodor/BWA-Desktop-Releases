﻿param([string]$CompletionFile, [switch]$InitialSetup)
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$NestoDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) 'BWA-NestoBot'
$LightspeedDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) 'BWA-LightspeedBot'
$BomitoDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) 'BWA-BomitoBot'

foreach ($dir in @($NestoDir, $LightspeedDir, $BomitoDir)) {
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
}

$NestoUrlFile = Join-Path $NestoDir 'nesto_url.txt'
$NestoSettings = Join-Path $NestoDir 'settings.json'
$NestoCredentials = Join-Path $NestoDir 'credentials.dat'
$LightspeedSettings = Join-Path $LightspeedDir 'settings.json'
$LightspeedCredentials = Join-Path $LightspeedDir 'credentials.dat'
$BomitoSettings = Join-Path $BomitoDir 'bomito_settings.json'
$BomitoRestaurantFile = Join-Path $BomitoDir 'restaurant.txt'
$BomitoCredentials = Join-Path $BomitoDir 'credentials.dat'

$DefaultNestoUrl = ''
$DefaultLightspeedUrl = 'https://manager.lsk.lightspeed.app/'
$DefaultBomitoUrl = 'https://login.bomito.com/application/reporting_financialaccounts_overview.cfm?md=1'

$BomitoCodes = @(
    @{ Code = '60610020'; Label = 'Food' },
    @{ Code = '60610010'; Label = 'Drinks' },
    @{ Code = '60330010'; Label = 'Paper' },
    @{ Code = '60330060'; Label = 'Operating Supplies' },
    @{ Code = '60330030'; Label = 'Glass' },
    @{ Code = '60330020'; Label = 'Silver / Cutlery' },
    @{ Code = '60330040'; Label = 'China / Porcelain' },
    @{ Code = '60320000'; Label = 'Cleaning Supplies' },
    @{ Code = '61830000'; Label = 'Waste disposal' },
    @{ Code = '61853000'; Label = 'Linen / Work Clothing' },
    @{ Code = '61228000'; Label = 'Repair & Maintenance' },
    @{ Code = '60330070'; Label = 'Outside Service' },
    @{ Code = '64130000'; Label = 'Software' },
    @{ Code = '61532000'; Label = 'Telefon' },
    @{ Code = '61228010'; Label = 'Service ID' },
    @{ Code = '61845000'; Label = 'Electricity 61845000' },
    @{ Code = '60315000'; Label = 'Electricity 60315000' },
    @{ Code = '61843000'; Label = 'Gas' }
)

function Read-JsonFile {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $null
    }

    try {
        return (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop | ConvertFrom-Json)
    }
    catch {
        return $null
    }
}

function Get-CredentialUser {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return ''
    }

    try {
        $credential = Import-Clixml -LiteralPath $Path -ErrorAction Stop
        if ($credential -is [System.Management.Automation.PSCredential]) {
            return [string]$credential.UserName
        }
    }
    catch {}

    return ''
}

function Save-Credential {
    param(
        [string]$Path,
        [string]$User,
        [string]$Password
    )

    if ([string]::IsNullOrWhiteSpace($Password)) {
        return
    }

    if ([string]::IsNullOrWhiteSpace($User)) {
        throw 'Enter a username/email before saving a new password.'
    }

    $securePassword = ConvertTo-SecureString $Password -AsPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($User, $securePassword)
    $credential | Export-Clixml -LiteralPath $Path -Force
}

function New-Label {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width = 180
    )

    $control = New-Object System.Windows.Forms.Label
    $control.Text = $Text
    $control.Location = New-Object System.Drawing.Point($X, $Y)
    $control.Size = New-Object System.Drawing.Size($Width, 24)
    return $control
}

function New-TextBox {
    param(
        [string]$Text,
        [int]$X,
        [int]$Y,
        [int]$Width = 560
    )

    $control = New-Object System.Windows.Forms.TextBox
    $control.Text = $Text
    $control.Location = New-Object System.Drawing.Point($X, $Y)
    $control.Size = New-Object System.Drawing.Size($Width, 24)
    return $control
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Access Manager'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(900, 720)
$form.MinimumSize = New-Object System.Drawing.Size(900, 720)
$form.MaximizeBox = $false

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Location = New-Object System.Drawing.Point(12, 12)
$tabs.Size = New-Object System.Drawing.Size(860, 600)
$form.Controls.Add($tabs)

# NESTO
$tabNesto = New-Object System.Windows.Forms.TabPage
$tabNesto.Text = 'Nesto'
$tabs.TabPages.Add($tabNesto)

$nestoUrl = $DefaultNestoUrl
if (Test-Path -LiteralPath $NestoUrlFile -PathType Leaf) {
    try {
        $savedNestoUrl = (Get-Content -LiteralPath $NestoUrlFile -Raw -ErrorAction Stop).Trim()
        if ($savedNestoUrl) {
            $nestoUrl = $savedNestoUrl
        }
    }
    catch {}
}

$tabNesto.Controls.Add((New-Label 'Recorded Assignments URL' 20 30 190))
$txtNestoUrl = New-TextBox $nestoUrl 220 28 590
$tabNesto.Controls.Add($txtNestoUrl)

$lblNestoInfo = New-Label 'The final date /YYYY-MM-DD is removed automatically when you save.' 220 62 590
$lblNestoInfo.ForeColor = [System.Drawing.Color]::DimGray
$tabNesto.Controls.Add($lblNestoInfo)

$tabNesto.Controls.Add((New-Label 'Username / email' 20 110))
$txtNestoUser = New-TextBox (Get-CredentialUser $NestoCredentials) 220 108 360
$tabNesto.Controls.Add($txtNestoUser)
$tabNesto.Controls.Add((New-Label 'New password' 20 155))
$txtNestoPassword = New-TextBox '' 220 153 360
$txtNestoPassword.UseSystemPasswordChar = $true
$tabNesto.Controls.Add($txtNestoPassword)
$chkNestoAuto = New-Object System.Windows.Forms.CheckBox
$chkNestoAuto.Text = 'Automatic login'
$chkNestoAuto.Location = New-Object System.Drawing.Point(220, 198)
$chkNestoAuto.Size = New-Object System.Drawing.Size(220, 28)
$nestoSettingsObject = Read-JsonFile $NestoSettings
$chkNestoAuto.Checked = ($nestoSettingsObject -and $nestoSettingsObject.auto_login -eq $true -and -not [string]::IsNullOrWhiteSpace($txtNestoUser.Text))
$tabNesto.Controls.Add($chkNestoAuto)
$loginInfo = New-Label 'Windows protects the saved password. Leave New password empty to keep it.' 220 238 590
$loginInfo.Height = 45
$tabNesto.Controls.Add($loginInfo)
$mfaInfo = New-Label 'Verification codes and external identity providers require manual login.' 220 286 590
$mfaInfo.Height = 45
$tabNesto.Controls.Add($mfaInfo)
$btnClearNesto = New-Object System.Windows.Forms.Button
$btnClearNesto.Text = 'Clear credentials'
$btnClearNesto.Location = New-Object System.Drawing.Point(220, 340)
$btnClearNesto.Size = New-Object System.Drawing.Size(180, 34)
$btnClearNesto.Add_Click({
    if (Test-Path -LiteralPath $NestoCredentials) { Remove-Item -LiteralPath $NestoCredentials -Force }
    $txtNestoUser.Text = ''
    $txtNestoPassword.Text = ''
    $chkNestoAuto.Checked = $false
    [ordered]@{auto_login=$false} | ConvertTo-Json | Set-Content -LiteralPath $NestoSettings -Encoding UTF8
})
$tabNesto.Controls.Add($btnClearNesto)

# LIGHTSPEED
$tabLightspeed = New-Object System.Windows.Forms.TabPage
$tabLightspeed.Text = 'Lightspeed'
$tabs.TabPages.Add($tabLightspeed)

$lightspeedSettingsObject = Read-JsonFile $LightspeedSettings
$lightspeedUrl = $DefaultLightspeedUrl
$lightspeedAutoLogin = $true
$lightspeedDownloadDir = ''

if ($null -ne $lightspeedSettingsObject) {
    if ($lightspeedSettingsObject.login_url) {
        $lightspeedUrl = [string]$lightspeedSettingsObject.login_url
    }
    if ($null -ne $lightspeedSettingsObject.auto_login) {
        $lightspeedAutoLogin = [bool]$lightspeedSettingsObject.auto_login
    }
    if ($lightspeedSettingsObject.download_dir) {
        $lightspeedDownloadDir = [string]$lightspeedSettingsObject.download_dir
    }
}

$tabLightspeed.Controls.Add((New-Label 'Manager URL' 20 30))
$txtLightspeedUrl = New-TextBox $lightspeedUrl 220 28 590
$tabLightspeed.Controls.Add($txtLightspeedUrl)

$tabLightspeed.Controls.Add((New-Label 'Username / email' 20 75))
$txtLightspeedUser = New-TextBox (Get-CredentialUser $LightspeedCredentials) 220 73 360
$tabLightspeed.Controls.Add($txtLightspeedUser)

$tabLightspeed.Controls.Add((New-Label 'New password' 20 120))
$txtLightspeedPassword = New-TextBox '' 220 118 360
$txtLightspeedPassword.UseSystemPasswordChar = $true
$tabLightspeed.Controls.Add($txtLightspeedPassword)

$chkLightspeedAuto = New-Object System.Windows.Forms.CheckBox
$chkLightspeedAuto.Text = 'Automatic login'
$chkLightspeedAuto.Checked = $lightspeedAutoLogin
$chkLightspeedAuto.Location = New-Object System.Drawing.Point(220, 160)
$chkLightspeedAuto.Size = New-Object System.Drawing.Size(220, 28)
$tabLightspeed.Controls.Add($chkLightspeedAuto)

$downloadFolderLabel = New-Label 'Download folder (empty = automatic Windows Downloads)' 20 205 195
$downloadFolderLabel.Height = 44
$tabLightspeed.Controls.Add($downloadFolderLabel)
$txtLightspeedDownload = New-TextBox $lightspeedDownloadDir 220 203 590
$tabLightspeed.Controls.Add($txtLightspeedDownload)

$btnClearLightspeed = New-Object System.Windows.Forms.Button
$btnClearLightspeed.Text = 'Clear credentials'
$btnClearLightspeed.Location = New-Object System.Drawing.Point(220, 250)
$btnClearLightspeed.Size = New-Object System.Drawing.Size(180, 34)
$btnClearLightspeed.Add_Click({
    if (Test-Path -LiteralPath $LightspeedCredentials -PathType Leaf) {
        Remove-Item -LiteralPath $LightspeedCredentials -Force -ErrorAction SilentlyContinue
    }
    $txtLightspeedUser.Text = ''
    $txtLightspeedPassword.Text = ''
    [System.Windows.Forms.MessageBox]::Show('Lightspeed credentials cleared.', 'Access Manager') | Out-Null
})
$tabLightspeed.Controls.Add($btnClearLightspeed)

# BOMITO
$tabBomito = New-Object System.Windows.Forms.TabPage
$tabBomito.Text = 'Bomito'
$tabs.TabPages.Add($tabBomito)

$panelBomito = New-Object System.Windows.Forms.Panel
$panelBomito.Dock = 'Fill'
$panelBomito.AutoScroll = $true
$tabBomito.Controls.Add($panelBomito)

$bomitoSettingsObject = Read-JsonFile $BomitoSettings
$bomitoUrl = $DefaultBomitoUrl
$bomitoRestaurant = ''
$bomitoAutoLogin = $true
$existingLinks = @{}

if ($null -ne $bomitoSettingsObject) {
    if ($bomitoSettingsObject.overview_url) {
        $bomitoUrl = [string]$bomitoSettingsObject.overview_url
    }
    if ($bomitoSettingsObject.restaurant) {
        $bomitoRestaurant = [string]$bomitoSettingsObject.restaurant
    }
    if ($null -ne $bomitoSettingsObject.auto_login) {
        $bomitoAutoLogin = [bool]$bomitoSettingsObject.auto_login
    }
    if ($bomitoSettingsObject.account_links) {
        foreach ($property in $bomitoSettingsObject.account_links.PSObject.Properties) {
            $existingLinks[$property.Name] = [string]$property.Value
        }
    }
}
elseif (Test-Path -LiteralPath $BomitoRestaurantFile -PathType Leaf) {
    try {
        $savedRestaurant = (Get-Content -LiteralPath $BomitoRestaurantFile -Raw -ErrorAction Stop).Trim()
        if ($savedRestaurant) {
            $bomitoRestaurant = $savedRestaurant
        }
    }
    catch {}
}

$panelBomito.Controls.Add((New-Label 'G/L Accounts URL' 20 20))
$txtBomitoUrl = New-TextBox $bomitoUrl 220 18 590
$panelBomito.Controls.Add($txtBomitoUrl)

$panelBomito.Controls.Add((New-Label 'Restaurant keyword' 20 62))
$txtBomitoRestaurant = New-TextBox $bomitoRestaurant 220 60 360
$panelBomito.Controls.Add($txtBomitoRestaurant)

$panelBomito.Controls.Add((New-Label 'Username / email' 20 104))
$txtBomitoUser = New-TextBox (Get-CredentialUser $BomitoCredentials) 220 102 360
$panelBomito.Controls.Add($txtBomitoUser)

$panelBomito.Controls.Add((New-Label 'New password' 20 146))
$txtBomitoPassword = New-TextBox '' 220 144 360
$txtBomitoPassword.UseSystemPasswordChar = $true
$panelBomito.Controls.Add($txtBomitoPassword)

$chkBomitoAuto = New-Object System.Windows.Forms.CheckBox
$chkBomitoAuto.Text = 'Automatic login'
$chkBomitoAuto.Checked = $bomitoAutoLogin
$chkBomitoAuto.Location = New-Object System.Drawing.Point(220, 184)
$chkBomitoAuto.Size = New-Object System.Drawing.Size(220, 28)
$panelBomito.Controls.Add($chkBomitoAuto)

$btnClearBomito = New-Object System.Windows.Forms.Button
$btnClearBomito.Text = 'Clear credentials'
$btnClearBomito.Location = New-Object System.Drawing.Point(460, 180)
$btnClearBomito.Size = New-Object System.Drawing.Size(180, 34)
$btnClearBomito.Add_Click({
    if (Test-Path -LiteralPath $BomitoCredentials -PathType Leaf) {
        Remove-Item -LiteralPath $BomitoCredentials -Force -ErrorAction SilentlyContinue
    }
    $txtBomitoUser.Text = ''
    $txtBomitoPassword.Text = ''
    [System.Windows.Forms.MessageBox]::Show('Bomito credentials cleared.', 'Access Manager') | Out-Null
})
$panelBomito.Controls.Add($btnClearBomito)

$lblBomitoLinks = New-Label 'Bomito account detail links' 20 230 300
$lblBomitoLinks.Font = New-Object System.Drawing.Font($lblBomitoLinks.Font, [System.Drawing.FontStyle]::Bold)
$panelBomito.Controls.Add($lblBomitoLinks)

$script:BomitoLinkBoxes = @{}
$y = 268
foreach ($item in $BomitoCodes) {
    $panelBomito.Controls.Add((New-Label ($item.Code + ' - ' + $item.Label) 20 $y 210))

    $linkValue = ''
    if ($existingLinks.ContainsKey($item.Code)) {
        $linkValue = [string]$existingLinks[$item.Code]
    }

    $linkBox = New-TextBox $linkValue 235 ($y - 2) 575
    $panelBomito.Controls.Add($linkBox)
    $script:BomitoLinkBoxes[$item.Code] = $linkBox
    $y += 36
}

# SAVE / CLOSE
$btnSave = New-Object System.Windows.Forms.Button
$btnSave.Text = 'Save'
$btnSave.Location = New-Object System.Drawing.Point(602, 625)
$btnSave.Size = New-Object System.Drawing.Size(125, 38)
$form.Controls.Add($btnSave)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = 'Close'
$btnClose.Location = New-Object System.Drawing.Point(742, 625)
$btnClose.Size = New-Object System.Drawing.Size(125, 38)
$btnClose.Add_Click({ $form.Close() })
$form.Controls.Add($btnClose)

$btnSave.Add_Click({
    try {
        if ($txtNestoPassword.Text -and [string]::IsNullOrWhiteSpace($txtNestoUser.Text)) { throw 'Enter the Nesto username/email before saving a password.' }
        if (-not $txtNestoPassword.Text -and (Test-Path -LiteralPath $NestoCredentials) -and $txtNestoUser.Text.Trim() -ne (Get-CredentialUser $NestoCredentials)) { throw 'Enter the new password when changing the Nesto username.' }
        if ($chkNestoAuto.Checked -and -not $txtNestoPassword.Text -and -not (Test-Path -LiteralPath $NestoCredentials)) { throw 'Enter Nesto credentials before enabling automatic login.' }
        $newNestoUrl = $txtNestoUrl.Text.Trim()
        $newNestoUrl = $newNestoUrl -replace '[?#].*$', ''
        $newNestoUrl = $newNestoUrl.TrimEnd('/')
        $newNestoUrl = $newNestoUrl -replace '/\d{4}-\d{2}-\d{2}$', ''

        if ($newNestoUrl -and $newNestoUrl -notmatch '^https://nesto\.app/[^/]+/[^/]+/recordedAssignments$') {
            throw 'Invalid Nesto Recorded Assignments URL.'
        }

        [System.IO.File]::WriteAllText(
            $NestoUrlFile,
            $newNestoUrl,
            (New-Object System.Text.UTF8Encoding($false))
        )

        Save-Credential -Path $NestoCredentials -User $txtNestoUser.Text.Trim() -Password $txtNestoPassword.Text
        [ordered]@{auto_login=[bool]$chkNestoAuto.Checked} | ConvertTo-Json | Set-Content -LiteralPath $NestoSettings -Encoding UTF8
        $txtNestoPassword.Text = ''

        $newLightspeedUrl = $txtLightspeedUrl.Text.Trim()
        if ($newLightspeedUrl -notmatch '^https://manager\.lsk\.lightspeed\.app/') {
            throw 'Invalid Lightspeed Manager URL.'
        }

        $lightspeedObject = [ordered]@{
            login_url = $newLightspeedUrl
            auto_login = [bool]$chkLightspeedAuto.Checked
            download_dir = $txtLightspeedDownload.Text.Trim()
        }
        $lightspeedObject | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $LightspeedSettings -Encoding UTF8
        Save-Credential -Path $LightspeedCredentials -User $txtLightspeedUser.Text.Trim() -Password $txtLightspeedPassword.Text

        $newBomitoUrl = $txtBomitoUrl.Text.Trim()
        if ($newBomitoUrl -notmatch '^https://login\.bomito\.com/.+reporting_financialaccounts_overview\.cfm') {
            throw 'Invalid Bomito G/L Accounts URL.'
        }

        $newRestaurant = $txtBomitoRestaurant.Text.Trim()
        if ([string]::IsNullOrWhiteSpace($newRestaurant)) {
            throw 'Restaurant keyword cannot be empty.'
        }

        $newLinks = [ordered]@{}
        foreach ($item in $BomitoCodes) {
            $value = $script:BomitoLinkBoxes[$item.Code].Text.Trim()
            if ($value) {
                $newLinks[$item.Code] = $value
            }
        }

        $bomitoObject = [ordered]@{
            overview_url = $newBomitoUrl
            restaurant = $newRestaurant
            auto_login = [bool]$chkBomitoAuto.Checked
            account_links = $newLinks
        }
        $bomitoObject | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $BomitoSettings -Encoding UTF8
        [System.IO.File]::WriteAllText(
            $BomitoRestaurantFile,
            $newRestaurant,
            (New-Object System.Text.UTF8Encoding($false))
        )
        Save-Credential -Path $BomitoCredentials -User $txtBomitoUser.Text.Trim() -Password $txtBomitoPassword.Text

        $txtLightspeedPassword.Text = ''
        $txtBomitoPassword.Text = ''

        if ($CompletionFile) { [IO.File]::WriteAllText($CompletionFile, 'configured') }
        [System.Windows.Forms.MessageBox]::Show(
            'Configuration saved successfully.',
            'Access Manager',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show(
            $_.Exception.Message,
            'Access Manager',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error
        ) | Out-Null
    }
})


if ($InitialSetup) {
    foreach ($control in @($tabNesto.Controls)) {
        if ($control.Top -lt 100) { $control.Visible = $false }
        else { $control.Top -= 75 }
    }
    foreach ($control in @($tabLightspeed.Controls)) {
        if ($control.Top -lt 60) { $control.Visible = $false }
        else { $control.Top -= 35 }
    }
    foreach ($control in @($panelBomito.Controls)) {
        if ($control.Top -lt 45 -or $control.Top -ge 230) { $control.Visible = $false }
        else { $control.Top -= 35 }
    }
    $downloadFolderLabel.Visible = $false
    $txtLightspeedDownload.Visible = $false
    $panelBomito.AutoScrollMinSize = New-Object System.Drawing.Size(0, 0)
    $notice = New-Label 'Portal addresses can be changed later in Admin > Access. Nesto requires the restaurant-specific link.' 20 500 800
    $tabs.TabPages[0].Controls.Add($notice)
}
[void]$form.ShowDialog()

