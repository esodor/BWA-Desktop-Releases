"""Validate a complete Lightspeed monthly Business Report without Office.

CLI: python -I month_report_reader.py REQUEST.json RESULT.json
Request: {"path": "...pdf", "period": "2026-07", "restaurantPrefix": "..."}
restaurantPrefix is optional and is the exact filename prefix of an already
verified daily report. Result: {ok, error, restaurant, period, total}. `total`
is the report's CA Brut (Ventes), including VAT and excluding tips. The source
PDF is never modified. Current supported report layout is French Lightspeed.

The URL ends on the last calendar day, while the downloaded filename ends on
the first day of the following month. Receipt timestamps may cross midnight;
they must not be used instead of the report's explicit accounting period.
"""
import calendar
import datetime
import json
import pathlib
import re
import sys
import unicodedata
from decimal import Decimal

from pypdf import PdfReader


MONTHS = (
    "janvier", "fevrier", "mars", "avril", "mai", "juin",
    "juillet", "aout", "septembre", "octobre", "novembre", "decembre",
)
MONEY = re.compile(r"(?<![\d.,])[-−]?\d(?:[\d \u00a0\u202f]*\d)?[,.]\d{2}(?!\d)")


def normalize(value):
    unaccented = "".join(
        c for c in unicodedata.normalize("NFKD", str(value)).casefold()
        if not unicodedata.combining(c)
    )
    return re.sub(r"[^a-z0-9]+", " ", unaccented).strip()


def compact(value):
    return normalize(value).replace(" ", "")


def read_month_report(config):
    if not isinstance(config, dict):
        raise ValueError("Richiesta del report mensile non valida.")
    period = config.get("period")
    if not isinstance(period, str) or not re.fullmatch(r"\d{4}-\d{2}", period):
        raise ValueError("Il mese deve avere il formato AAAA-MM.")
    try:
        first = datetime.date.fromisoformat(period + "-01")
        last = first.replace(day=calendar.monthrange(first.year, first.month)[1])
        next_month = last + datetime.timedelta(days=1)
    except (ValueError, OverflowError):
        raise ValueError("Mese del report non valido.") from None

    source = config.get("path")
    if not isinstance(source, str) or not source.strip():
        raise ValueError("Seleziona il Business Report mensile in PDF.")
    path = pathlib.Path(source)
    pattern = (
        r"(.+)_business_report_month_" + first.strftime("%Y%m%d") + "_"
        + next_month.strftime("%Y%m%d") + r"(?: \(\d+\))?\.pdf"
    )
    match = re.fullmatch(pattern, path.name, re.IGNORECASE)
    if not match:
        raise ValueError("Nome o periodo del file non corrispondente al Business Report mensile selezionato.")
    prefix = match[1]
    expected_prefix = config.get("restaurantPrefix")
    if expected_prefix is not None:
        if not isinstance(expected_prefix, str) or not expected_prefix.strip():
            raise ValueError("Identificativo del ristorante atteso non valido.")
        if prefix.casefold() != expected_prefix.strip().casefold():
            raise ValueError("Il Business Report mensile appartiene a un altro ristorante.")

    with path.open("rb") as stream:
        if stream.read(5) != b"%PDF-":
            raise ValueError("Il file scaricato non è un PDF valido: Lightspeed potrebbe avere restituito una pagina di errore.")
    reader = PdfReader(path)
    if reader.is_encrypted:
        raise ValueError("Il PDF mensile è cifrato e non può essere verificato.")
    if not reader.pages:
        raise ValueError("Il PDF mensile non contiene pagine.")
    pages = [page.extract_text(extraction_mode="layout") or "" for page in reader.pages]
    first_lines = [line.strip() for line in pages[0].splitlines() if line.strip()]
    headings = [i for i, line in enumerate(first_lines) if normalize(line).startswith("rapport operationnel pour ")]
    if len(headings) != 1:
        raise ValueError("Intestazione del Business Report mensile non riconosciuta. È richiesto il rapporto completo in francese.")
    heading_index = headings[0]
    expected_heading = (
        "rapport operationnel pour "
        + f"1 {MONTHS[first.month-1]} {first.year} "
        + f"{last.day} {MONTHS[last.month-1]} {last.year}"
    )
    if normalize(first_lines[heading_index]) != expected_heading:
        raise ValueError("Il periodo interno del PDF non coincide con l'intero mese selezionato.")
    identities = [
        line for line in first_lines[:heading_index]
        if not line.isdigit() and not normalize(line).startswith("genere par ")
    ]
    if not identities:
        raise ValueError("Nome del ristorante assente nel PDF mensile.")
    restaurant = identities[0]
    restaurant_id = compact(restaurant)
    # The downloaded name comprises business prefix + '_' + location slug.
    # Match the complete location identity, not one city/name fragment.
    location_slug = prefix.rsplit("_", 1)[-1]
    if not restaurant_id or compact(location_slug) != restaurant_id:
        raise ValueError("Il ristorante scritto nel PDF non corrisponde al nome del file scaricato.")

    lines = [line.strip() for page in pages for line in page.splitlines() if line.strip()]
    totals = []
    for line in lines:
        amount = MONEY.search(line)
        if amount and normalize(line[:amount.start()]) == "ca brut ventes":
            number = re.sub(r"[\s\u00a0\u202f]", "", amount[0]).replace("−", "-")
            if "," in number:
                number = number.replace(".", "").replace(",", ".")
            totals.append(Decimal(number))
    if len(totals) != 1:
        raise ValueError("Totale lordo mancante o ambiguo nel Business Report mensile.")
    return {"ok": True, "error": "", "restaurant": restaurant, "period": period, "total": float(totals[0])}


def main():
    if len(sys.argv) != 3:
        print(__doc__, file=sys.stderr)
        return 2
    result = {"ok": False, "error": "", "restaurant": "", "period": "", "total": 0}
    try:
        config = json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8-sig"))
        if isinstance(config, dict) and isinstance(config.get("period"), str):
            result["period"] = config["period"]
        result = read_month_report(config)
    except Exception as error:
        result["error"] = str(error)
    output = pathlib.Path(sys.argv[2])
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    temporary.replace(output)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
