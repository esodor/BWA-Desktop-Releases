﻿param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^\d{4}-\d{2}$')]
    [string]$Period,

    [Parameter(Mandatory = $true)]
    [string]$Output,
    [string]$AdditionalAccountsPath = "",
    [switch]$VisibleBrowser
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '../AccessConfig/BrowserWindow.ps1')
if ($env:BWA_VISIBLE_BROWSER -eq '1') { $VisibleBrowser = $true }

$AppName = 'BWA-BomitoBot'
$AppDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) $AppName
$ProfileDir = Join-Path $AppDir 'edge-profile'
$LogDir = Join-Path $AppDir 'logs'
$DownloadDir = Join-Path $AppDir ('downloads\' + $Period)
$RestaurantConfigFile = Join-Path $AppDir 'restaurant.txt'
$SettingsFile = Join-Path $AppDir 'bomito_settings.json'
$CredentialsFile = Join-Path $AppDir 'credentials.dat'

$DefaultRestaurantTarget = ''
$RestaurantSelectionUrl = 'https://login.bomito.com/application/login_default.cfm'
$DefaultOverviewUrl = 'https://login.bomito.com/application/reporting_financialaccounts_overview.cfm?md=1'
$OverviewUrl = $DefaultOverviewUrl
$RestaurantTarget = $DefaultRestaurantTarget
$AutoLoginEnabled = $true

$BelvalFallbackLinks = @{}
$AccountFallbackLinks = @{}

if (Test-Path -LiteralPath $SettingsFile) {
    try {
        $settings = Get-Content -LiteralPath $SettingsFile -Raw -ErrorAction Stop | ConvertFrom-Json

        if ($settings.overview_url) { $OverviewUrl = ([string]$settings.overview_url).Trim() }
        if ($settings.restaurant) { $RestaurantTarget = ([string]$settings.restaurant).Trim() }
        if ($null -ne $settings.auto_login) { $AutoLoginEnabled = [bool]$settings.auto_login }

        if ($settings.account_links) {
            foreach ($p in $settings.account_links.PSObject.Properties) {
                $value = ([string]$p.Value).Trim()
                if ($value) { $AccountFallbackLinks[$p.Name] = $value }
            }
        }
    } catch {}
}
elseif (Test-Path -LiteralPath $RestaurantConfigFile) {
    try {
        $legacyRestaurant = (Get-Content -LiteralPath $RestaurantConfigFile -Raw -ErrorAction Stop).Trim()
        if ($legacyRestaurant) { $RestaurantTarget = $legacyRestaurant }
    } catch {}
}

if ($env:BWA_SUPPORT_BOMITO_RESTAURANT) { $RestaurantTarget = $env:BWA_SUPPORT_BOMITO_RESTAURANT }
if (-not $RestaurantTarget) { throw 'Configura il nome del ristorante in Admin > Accessi prima di avviare Bomito.' }
if (-not $OverviewUrl) { $OverviewUrl = $DefaultOverviewUrl }

# The known links are safe defaults only for Belval. For another restaurant
# the configurator can provide the restaurant-specific fallback links.
if ($RestaurantTarget -match '(?i)Belval') {
    foreach ($code in $BelvalFallbackLinks.Keys) {
        if (-not $AccountFallbackLinks.ContainsKey($code)) {
            $AccountFallbackLinks[$code] = $BelvalFallbackLinks[$code]
        }
    }
}

$OverviewUrl = $OverviewUrl.Trim()
if ($OverviewUrl -notmatch '^https://login\.bomito\.com/.+reporting_financialaccounts_overview\.cfm') {
    throw 'Link Bomito G/L accounts non valido. Usa il pulsante Configura Accessi nel BWA.'
}
$FinancialOverviewBase = $OverviewUrl -replace '\?.*$', ''
$MonthUrl = "${FinancialOverviewBase}?md=f3&newfiltertype=month"
$Port = 9341
$LoginTimeoutSeconds = 300

New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
New-Item -ItemType Directory -Path $DownloadDir -Force | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$LogFile = Join-Path $LogDir "bomito_${Period}_${stamp}.log"
$ScreenshotFile = Join-Path $LogDir "errore_${Period}_${stamp}.png"

$script:WebSocket = $null
$script:CdpId = 0
$script:CdpCancellation = $null
$script:Stage = 'inizializzazione'

$Accounts = @(
    @{ Code='60610020'; Label='Food'; Required=$true },
    @{ Code='60610010'; Label='Drinks'; Required=$true },
    @{ Code='60330010'; Label='Paper' },
    @{ Code='60330060'; Label='Operating Supplies' },
    @{ Code='60330030'; Label='Glass' },
    @{ Code='60330020'; Label='Silver / Cutlery' },
    @{ Code='60330040'; Label='China / Porcelain' },
    @{ Code='60320000'; Label='Cleaning Supplies'; Required=$true },
    @{ Code='61830000'; Label='Waste disposal' },
    @{ Code='61853000'; Label='Linen / Work Clothing' },
    @{ Code='61228000'; Label='Repair & Maintenance' },
    @{ Code='60330070'; Label='Outside Service' },
    @{ Code='64130000'; Label='Software' },
    @{ Code='61532000'; Label='Telefon' },
    @{ Code='61228010'; Label='Service ID' },
    @{ Code='61845000'; Label='Electricity 61845000' },
    @{ Code='60315000'; Label='Electricity 60315000' },
    @{ Code='61843000'; Label='Gas' }
)

if ($AdditionalAccountsPath) {
    $extraAccounts = Get-Content -LiteralPath $AdditionalAccountsPath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($extra in $extraAccounts) {
        if ([string]$extra.Account -notmatch '^\d{6,12}$' -or [string]::IsNullOrWhiteSpace([string]$extra.Name)) { throw 'Categoria Bomito non valida.' }
        if ($Accounts.Code -notcontains [string]$extra.Account) { $Accounts += @{ Code=[string]$extra.Account; Label=[string]$extra.Name } }
    }
}

function Add-Log {
    param([string]$Text)
    $line = "{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    if ($env:BWA_RUN_LOG) { try { Add-Content -LiteralPath $env:BWA_RUN_LOG -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8 } catch {} }
}

function Safe-Text {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    return (($Text -replace "`t", ' ') -replace "[\r\n]+", ' ').Trim()
}

function Write-ResultFile {
    param(
        [string]$Status,
        [string]$Message,
        $Rows = @(),
        [string[]]$MissingAccounts = @()
    )

    $parent = Split-Path -Parent $Output
    if ($parent) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }

    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add("status=$Status")
    $lines.Add("period=$Period")
    $lines.Add("restaurant=$(Safe-Text $RestaurantTarget)")
    $lines.Add("count=$(@($Rows).Count)")
    $lines.Add("message=$(Safe-Text $Message)")
    $lines.Add("missing_accounts=$(Safe-Text ($MissingAccounts -join ','))")
    $lines.Add("log=$(Safe-Text $LogFile)")
    $lines.Add('---DATA---')
    $lines.Add("account`tdate`tdocument`tsupplier`tamount")

    foreach ($row in @($Rows)) {
        $lines.Add(
            (Safe-Text $row.account) + "`t" +
            (Safe-Text $row.date) + "`t" +
            (Safe-Text $row.document) + "`t" +
            (Safe-Text $row.supplier) + "`t" +
            (Safe-Text $row.amount)
        )
    }

    [System.IO.File]::WriteAllLines(
        $Output,
        $lines,
        [System.Text.Encoding]::Default
    )
}

function Find-EdgeExecutable {
    $candidates = New-Object System.Collections.Generic.List[string]

    foreach ($registryPath in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'
    )) {
        try {
            $value = (Get-ItemProperty -LiteralPath $registryPath -ErrorAction Stop).'(default)'
            if ($value) { $candidates.Add([string]$value) }
        } catch {}
    }

    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA, $env:ProgramW6432)) {
        if ($base) { $candidates.Add((Join-Path $base 'Microsoft\Edge\Application\msedge.exe')) }
    }

    try {
        $command = Get-Command msedge.exe -ErrorAction Stop
        if ($command.Source) { $candidates.Add([string]$command.Source) }
    } catch {}

    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            Add-Log "Edge trovato: $candidate"
            return $candidate
        }
    }

    throw 'Microsoft Edge non trovato.'
}

function Test-DebugEndpoint {
    try {
        $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
        return $true
    } catch {
        return $false
    }
}

function Start-DedicatedEdge {
    $edge = Find-EdgeExecutable

    Reset-BwaLegacyHeadless -Port $Port -Profile $ProfileDir
    $backgroundMode = (-not $VisibleBrowser -and $AutoLoginEnabled -and (Test-Path -LiteralPath $CredentialsFile))
    if (-not (Test-DebugEndpoint)) {
        Add-Log "Avvio Edge dedicato: $edge"
        $arguments = @(
            "--remote-debugging-port=$Port",
            "--user-data-dir=`"$ProfileDir`"",
            '--no-first-run',
            '--no-default-browser-check',
            $RestaurantSelectionUrl
        )
        $backgroundMode = (-not $VisibleBrowser -and $AutoLoginEnabled -and (Test-Path -LiteralPath $CredentialsFile))
        $script:BackgroundMode = $backgroundMode
        if ($backgroundMode) {
            $arguments = @('--window-position=-32000,-32000','--window-size=1600,1000','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding','--disable-background-timer-throttling') + $arguments
            Add-Log 'Edge Bomito avviato in background.'
            $windowStyle = 'Hidden'
        } else { $arguments = @('--start-maximized') + $arguments; $windowStyle = 'Normal' }
        Start-Process -FilePath $edge -ArgumentList $arguments -WindowStyle $windowStyle | Out-Null
    }

    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if (Test-DebugEndpoint) { Set-BwaBrowserVisibility -Port $Port -Profile $ProfileDir -Visible (-not $backgroundMode); Add-Log "Browser normale pronto; finestra visibile: $(-not $backgroundMode)"; return }
        Start-Sleep -Milliseconds 400
    }

    throw 'Impossibile collegarsi a Microsoft Edge.'
}

function Get-PageTarget {
    # Do not wrap the REST result in @(): Windows PowerShell 5.1 emits
    # JSON arrays as one object. The next pipeline must enumerate its pages.
    $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 5
    $pages = @($targets | Where-Object { $_.type -eq 'page' })

    if ($pages.Count -eq 0) { throw 'Nessuna pagina Edge disponibile.' }

    $preferred = $pages |
        Where-Object { $_.url -like '*login.bomito.com*' } |
        Select-Object -First 1

    if ($null -eq $preferred) {
        $preferred = $pages | Select-Object -First 1
    }

    return $preferred
}

function Connect-Cdp {
    $target = Get-PageTarget

    $script:WebSocket = New-Object System.Net.WebSockets.ClientWebSocket
    $uri = New-Object System.Uri($target.webSocketDebuggerUrl)

    $null = $script:WebSocket.ConnectAsync(
        $uri,
        [Threading.CancellationToken]::None
    ).GetAwaiter().GetResult()

    Add-Log "CDP collegato a $($target.url)"
}

function Receive-WebSocketText {
    $buffer = New-Object byte[] 65536
    $stream = New-Object System.IO.MemoryStream

    try {
        do {
            $segment = [System.ArraySegment[byte]]::new($buffer)
            $result = $script:WebSocket.ReceiveAsync(
                $segment,
                $script:CdpCancellation.Token
            ).GetAwaiter().GetResult()

            if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) {
                throw 'La connessione con Edge e stata chiusa.'
            }

            $stream.Write($buffer, 0, $result.Count)

        } while (-not $result.EndOfMessage)

        return [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
    }
    finally {
        $stream.Dispose()
    }
}

function Invoke-Cdp {
    param(
        [Parameter(Mandatory = $true)][string]$Method,
        [hashtable]$Params = @{}
    )

    $script:CdpCancellation = New-Object Threading.CancellationTokenSource
    $script:CdpCancellation.CancelAfter(20000)
    try {
    $script:CdpId++
    $id = $script:CdpId

    $request = @{
        id = $id
        method = $Method
        params = $Params
    } | ConvertTo-Json -Depth 30 -Compress

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($request)
    $segment = [System.ArraySegment[byte]]::new($bytes)

    $null = $script:WebSocket.SendAsync(
        $segment,
        [System.Net.WebSockets.WebSocketMessageType]::Text,
        $true,
        $script:CdpCancellation.Token
    ).GetAwaiter().GetResult()

    while ($true) {
        $responseText = Receive-WebSocketText
        $response = $responseText | ConvertFrom-Json

        if ($response.id -eq $id) {
            if ($response.error) {
                throw "CDP $Method`: $($response.error.message)"
            }
            return $response
        }
    }
    } finally {
        $script:CdpCancellation.Dispose()
        $script:CdpCancellation = $null
    }
}

function Invoke-JavaScript {
    param([Parameter(Mandatory = $true)][string]$Expression)

    $response = Invoke-Cdp -Method 'Runtime.evaluate' -Params @{
        expression = $Expression
        returnByValue = $true
        awaitPromise = $true
        userGesture = $true
    }

    if ($response.result.exceptionDetails) {
        $details = $response.result.exceptionDetails
        $message = [string]$details.text

        try {
            if ($details.exception -and $details.exception.description) {
                $message = [string]$details.exception.description
            }
        } catch {}

        try {
            if ($details.lineNumber -ne $null) {
                $message += " (linea JS " + ([int]$details.lineNumber + 1) + ")"
            }
        } catch {}

        throw "Errore JavaScript: $message"
    }

    return $response.result.result.value
}

function Get-BodyText {
    return [string](Invoke-JavaScript "(document.body && document.body.innerText) ? document.body.innerText : ''")
}

function Get-CurrentUrl {
    return [string](Invoke-JavaScript 'location.href')
}

function Navigate {
    param([Parameter(Mandatory = $true)][string]$Url)
    Invoke-Cdp -Method 'Page.navigate' -Params @{ url=$Url } | Out-Null
}


function Get-StoredCredential {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return $null }

    # v1.39+: PSCredential / Export-Clixml. On Windows the SecureString is
    # encrypted for the current Windows user with DPAPI.
    try {
        $cred = Import-Clixml -LiteralPath $Path -ErrorAction Stop
        if ($cred -is [System.Management.Automation.PSCredential]) {
            return [PSCustomObject]@{
                username = [string]$cred.UserName
                password = [string]$cred.GetNetworkCredential().Password
            }
        }
    }
    catch {}

    # Backward compatibility with v1.38.
    try {
        Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
        $b64 = (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop).Trim()
        if (-not $b64) { return $null }
        $encrypted = [Convert]::FromBase64String($b64)
        $plain = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $encrypted,
            $null,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        $json = [System.Text.Encoding]::UTF8.GetString($plain)
        return ($json | ConvertFrom-Json)
    }
    catch {
        Add-Log "Credenziali salvate non leggibili: $($_.Exception.Message)"
        return $null
    }
}

function Test-LoginPageLikely {
    $js = @'
(() => {
  const visible=e=>{
    try{
      const r=e.getBoundingClientRect(), s=getComputedStyle(e);
      return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden" && !e.disabled;
    }catch(err){ return false; }
  };

  const inputs=[...document.querySelectorAll('input')].filter(visible);
  const hasPassword=inputs.some(i => (i.type||'').toLowerCase()==='password');
  if(hasPassword) return true;

  const hasUser=inputs.some(i => {
    const x=((i.type||'')+' '+(i.name||'')+' '+(i.id||'')+' '+(i.autocomplete||'')+' '+(i.placeholder||'')).toLowerCase();
    return (i.type||'').toLowerCase()==='email' || /user|email|e-mail|login|mail/.test(x);
  });

  if(!hasUser) return false;

  const text=((document.body && document.body.innerText)||'').toLowerCase();
  return /login|log in|sign in|anmelden|connexion|accedi|e-mail|email|password|passwort|mot de passe/.test(text);
})()
'@

    try { return [bool](Invoke-JavaScript $js) } catch { return $false }
}

function Try-AutoLogin {
    param(
        $Credential,
        [string]$SiteName
    )

    if ($null -eq $Credential) { return $false }

    $username = [string]$Credential.username
    $password = [string]$Credential.password

    if (-not $username -or -not $password) { return $false }

    $userJson = $username | ConvertTo-Json -Compress
    $passJson = $password | ConvertTo-Json -Compress

    $js = @"
(async () => {
  const username=$userJson;
  const password=$passJson;

  const visible=e=>{
    try{
      const r=e.getBoundingClientRect(), s=getComputedStyle(e);
      return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden" && !e.disabled;
    }catch(err){ return false; }
  };

  const setValue=(el,val)=>{
    if(!el) return;
    try{
      const proto=Object.getPrototypeOf(el);
      const desc=Object.getOwnPropertyDescriptor(proto,'value') ||
                 Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
      if(desc && desc.set) desc.set.call(el,val); else el.value=val;
    }catch(err){ el.value=val; }
    for(const ev of ['input','change','keyup']){
      try{ el.dispatchEvent(new Event(ev,{bubbles:true})); }catch(err){}
    }
  };

  const inputs=[...document.querySelectorAll('input')].filter(visible);
  const passwordInput=inputs.find(i => (i.type||'').toLowerCase()==='password');

  const userInputs=inputs.filter(i => {
    const x=((i.type||'')+' '+(i.name||'')+' '+(i.id||'')+' '+(i.autocomplete||'')+' '+(i.placeholder||'')).toLowerCase();
    if((i.type||'').toLowerCase()==='password') return false;
    return (i.type||'').toLowerCase()==='email' || /user|email|e-mail|login|mail/.test(x);
  });

  const userInput=userInputs[0] || inputs.find(i => ['text','email'].includes((i.type||'text').toLowerCase()));

  const clickSubmit=(root)=>{
    const buttons=[...(root||document).querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);
    const preferred=buttons.find(b=>{
      const t=((b.innerText||b.value||b.textContent||'')+'').trim().toLowerCase();
      return /login|log in|sign in|anmelden|connexion|accedi|weiter|next|continue|continuer/.test(t);
    });
    const button=preferred || buttons.find(b => (b.type||'').toLowerCase()==='submit');
    if(button){ button.click(); return true; }
    return false;
  };

  if(passwordInput){
    if(userInput) setValue(userInput,username);
    setValue(passwordInput,password);

    const form=passwordInput.form || (userInput && userInput.form);
    if(form){
      const submit=[...form.querySelectorAll('button,input[type=submit]')].find(visible);
      if(submit){
        submit.focus();
        const r=submit.getBoundingClientRect();
        return JSON.stringify({action:'password-physical-submit',x:r.left+r.width/2,y:r.top+r.height/2});
      }
      try{ if(form.requestSubmit){ form.requestSubmit(); return 'password-requestSubmit'; } }catch(err){}
      try{ form.submit(); return 'password-form-submit'; }catch(err){}
    }

    if(clickSubmit(document)) return 'password-button';

    try{
      passwordInput.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
      passwordInput.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
      return 'password-enter';
    }catch(err){}

    return 'password-filled';
  }

  // Support login providers that ask the username/email on a first page.
  if(userInput){
    setValue(userInput,username);
    if(clickSubmit(userInput.form || document)) return 'username-next';
    try{
      userInput.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
      userInput.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
      return 'username-enter';
    }catch(err){}
  }

  return 'not-found';
})()
"@

    try {
        $action = [string](Invoke-JavaScript $js)
        if ($action -like '{*') {
            try {
                $physical = $action | ConvertFrom-Json
                if ($physical.action -eq 'password-physical-submit') {
                    Invoke-BomitoPhysicalClick -X ([double]$physical.x) -Y ([double]$physical.y)
                    Add-Log "$SiteName`: auto-login avviato con clic fisico sul pulsante Anmelden."
                    return $true
                }
            }
            catch {
                Add-Log "$SiteName`: dati del clic login non validi: $($_.Exception.Message)"
            }
        }
        if ($action -and $action -ne 'not-found') {
            Add-Log "$SiteName`: auto-login avviato ($action)."
            return $true
        }
    }
    catch {
        Add-Log "$SiteName`: auto-login non riuscito: $($_.Exception.Message)"
    }

    return $false
}

function Wait-ForBomitoOverview {
    Add-Log "Apro Bomito: $OverviewUrl"

    Invoke-Cdp -Method 'Page.enable' | Out-Null
    Invoke-Cdp -Method 'Runtime.enable' | Out-Null
    Navigate $OverviewUrl

    $credential = Get-StoredCredential -Path $CredentialsFile
    $autoAttempts = 0
    $nextAutoAttempt = Get-Date '2000-01-01'

    $deadline = (Get-Date).AddSeconds($LoginTimeoutSeconds)
    $lastNavigation = Get-Date '2000-01-01'
    $loginLogged = $false

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 800

        try {
            $body = Get-BodyText
            $hasPassword = [bool](Invoke-JavaScript "!!document.querySelector('input[type=password]')")
            $loginLikely = $hasPassword -or (Test-LoginPageLikely)

            if ($loginLikely -and $AutoLoginEnabled -and $credential -and
                $autoAttempts -lt 3 -and (Get-Date) -ge $nextAutoAttempt) {

                if (Try-AutoLogin -Credential $credential -SiteName 'Bomito') {
                    $autoAttempts++
                    $nextAutoAttempt = (Get-Date).AddSeconds(4)
                    Start-Sleep -Milliseconds 900
                    continue
                }
            }

            if ($loginLikely) {
                if (-not $loginLogged) {
                    if ($AutoLoginEnabled -and $credential) {
                        Add-Log 'Login Bomito ancora richiesto dopo tentativo automatico; attendo eventuale accesso manuale.'
                    } else {
                        Add-Log 'Login Bomito richiesto: credenziali automatiche non configurate; attendo accesso manuale.'
                    }
                    $loginLogged = $true
                }
                continue
            }

            if ($body -match '(?i)G/L\s*accounts' -and
                ($body -match '60610020' -or $body -match '(?i)COS\s*Food')) {

                Add-Log 'Pagina G/L accounts caricata.'
                return
            }

            $currentUrl = Get-CurrentUrl

            if ($currentUrl -notlike '*reporting_financialaccounts_overview.cfm*') {
                if (((Get-Date) - $lastNavigation).TotalSeconds -ge 5) {
                    Navigate $OverviewUrl
                    $lastNavigation = Get-Date
                }
            }
        }
        catch {
            Add-Log "Attesa Bomito: $($_.Exception.Message)"
        }
    }

    throw 'Tempo scaduto. Controlla le credenziali Bomito oppure effettua il login manualmente e riprova.'
}

function Test-BomitoRestaurantSelected {
    param([Parameter(Mandatory = $true)][string]$Target)

    $targetJson = $Target | ConvertTo-Json -Compress

    $js = @"
(() => {
  const target=$targetJson;
  const norm=s=>String(s||'')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/\s+/g,' ')
    .trim();
  const wanted=norm(target);
  const visible=e=>{
    const r=e.getBoundingClientRect();
    const s=getComputedStyle(e);
    return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
  };
  if(!wanted) return JSON.stringify({selected:false,text:''});

  const selects=[...document.querySelectorAll('select')].filter(visible);
  for(const sel of selects){
    const opt=sel.options && sel.selectedIndex>=0 ? sel.options[sel.selectedIndex] : null;
    if(opt) return JSON.stringify({selected:norm(opt.textContent).includes(wanted),text:String(opt.textContent||'').trim()});
  }

  const top=[...document.querySelectorAll('button,a,[role="button"]')].filter(e=>{
    if(!visible(e)) return false;
    const r=e.getBoundingClientRect();
    if(r.top<50 || r.top>360 || r.width<120 || r.width>650 || r.height>90) return false;
    const t=norm(e.innerText || e.textContent || e.value || '');
    if(!t || t.length>180) return false;
    return /osteria|lo\s+lux|s\.?\s*[àa]\.?\s*r\.?\s*l/i.test(t);
  }).map(e=>{
    const r=e.getBoundingClientRect();
    const t=norm(e.innerText || e.textContent || e.value || '');
    let score=80;
    if(e.querySelector && e.querySelector('svg,i,.caret,.fa-caret-down,.fa-chevron-down')) score+=60;
    if(r.top>=80 && r.top<=180) score+=40;
    if(r.left>=500) score+=20;
    score-=Math.min(30,Math.abs(r.width-380)/20);
    return {text:t,score};
  }).sort((a,b)=>b.score-a.score);

  return JSON.stringify({selected:top.length>0 && top[0].text.includes(wanted),text:top.length?top[0].text:''});
})()
"@

    $result = (Invoke-JavaScript $js) | ConvertFrom-Json
    $script:LastBomitoRestaurantText = [string]$result.text
    return [bool]$result.selected
}

function Click-BomitoRestaurantSelector {
    $js = @'
(() => {
  const visible=e=>{
    const r=e.getBoundingClientRect();
    const s=getComputedStyle(e);
    return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
  };
  const norm=s=>String(s||'').replace(/\s+/g,' ').trim();
  const nodes=[...document.querySelectorAll('select,button,a,[role="button"],div,span')]
    .filter(e=>{
      if(!visible(e)) return false;
      const r=e.getBoundingClientRect();
      // The compact Bomito header places the restaurant menu at y=110.
      // Exclude the account identity banner, but include both header layouts.
      if(r.top<50 || r.top>360 || r.width<120 || r.width>650 || r.height>90) return false;
      const t=norm(e.innerText || e.textContent || e.value || '');
      if(!t || t.length>180) return false;
      return /osteria|lo\s+lux|s\.?\s*[àa]\.?\s*r\.?\s*l/i.test(t);
    })
    .map(e=>{
      const r=e.getBoundingClientRect();
      const tag=e.tagName.toLowerCase();
      let score=0;
      if(tag==='select') score+=100;
      if(tag==='button' || tag==='a' || e.getAttribute('role')==='button') score+=80;
      if(r.top>=190 && r.top<=290) score+=40;
      if(r.left>=600) score+=20;
      if(e.querySelector && e.querySelector('svg,i,.caret,.fa-caret-down,.fa-chevron-down')) score+=20;
      score-=Math.min(30, Math.abs(r.width-380)/20);
      return {e,score,text:norm(e.innerText||e.textContent||e.value||'')};
    })
    .sort((a,b)=>b.score-a.score);

  if(!nodes.length) return JSON.stringify({ok:false,reason:'selector-not-found'});
  const n=nodes[0];
  n.e.click();
  return JSON.stringify({ok:true,text:n.text,score:n.score});
})()
'@

    return (Invoke-JavaScript $js) | ConvertFrom-Json
}

function Invoke-BomitoPhysicalClick {
    param([Parameter(Mandatory = $true)][double]$X,[Parameter(Mandatory = $true)][double]$Y)
    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{type='mouseMoved';x=$X;y=$Y;button='none'} | Out-Null
    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{type='mousePressed';x=$X;y=$Y;button='left';clickCount=1} | Out-Null
    Invoke-Cdp -Method 'Input.dispatchMouseEvent' -Params @{type='mouseReleased';x=$X;y=$Y;button='left';clickCount=1} | Out-Null
}

function Open-BomitoRestaurantSelection {
    param([Parameter(Mandatory = $true)][string]$Target)

    Add-Log "Apro la pagina di scelta ristorante Bomito: $RestaurantSelectionUrl"
    Invoke-Cdp -Method 'Page.enable' | Out-Null
    Invoke-Cdp -Method 'Runtime.enable' | Out-Null
    Navigate $RestaurantSelectionUrl

    $targetPattern = [regex]::Escape($Target)
    $credential = Get-StoredCredential -Path $CredentialsFile
    $autoAttempts = 0
    $lastAutoAttemptAt = Get-Date '2000-01-01'
    $nextAutoAttempt = Get-Date '2000-01-01'
    $loginLogged = $false
    $deadline = (Get-Date).AddSeconds($LoginTimeoutSeconds)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 700
        try {
            $body = Get-BodyText
            $loginLikely = Test-LoginPageLikely

            if ($loginLikely -and $AutoLoginEnabled -and $credential -and
                $autoAttempts -lt 3 -and (Get-Date) -ge $nextAutoAttempt) {

                if (Try-AutoLogin -Credential $credential -SiteName 'Bomito') {
                    $autoAttempts++
                    $lastAutoAttemptAt = Get-Date
                    $nextAutoAttempt = (Get-Date).AddSeconds(4)
                    Start-Sleep -Milliseconds 900
                    continue
                }
            }

            if ($loginLikely) {
                if (-not $VisibleBrowser -and $AutoLoginEnabled -and $credential -and $autoAttempts -ge 3 -and
                    ((Get-Date) - $lastAutoAttemptAt).TotalSeconds -ge 7) {
                    throw 'Bomito non ha accettato le credenziali salvate. Apri Admin > Accessi, reinserisci e-mail e password Bomito e verifica che funzionino anche sul sito.'
                }
                if (-not $loginLogged) {
                    if ($AutoLoginEnabled -and $credential) {
                        Add-Log 'Login Bomito ancora richiesto dopo il tentativo automatico.'
                    } else {
                        Add-Log 'Login Bomito richiesto; attendo accesso manuale.'
                    }
                    $loginLogged = $true
                }
                continue
            }

            if ($body -match "(?i)$targetPattern") {
                $currentUrl = Get-CurrentUrl
                Add-Log "Pagina scelta ristorante caricata: $currentUrl | trovato: $Target"
                return
            }
        }
        catch {
            if ($_.Exception.Message -like 'Bomito non ha accettato le credenziali salvate*') { throw }
            Add-Log "Attesa pagina scelta ristorante: $($_.Exception.Message)"
        }
    }

    throw "La pagina di scelta ristorante Bomito non mostra '$Target'. Nessuna fattura importata."
}

function Select-BomitoRestaurantFromStartPage {
    param([Parameter(Mandatory = $true)][string]$Target)

    $choice = Click-BomitoRestaurantOption -Target $Target
    if (-not $choice.ok) {
        throw "Nella pagina iniziale Bomito non trovo il ristorante '$Target'. Nessuna fattura importata."
    }

    Add-Log "Ristorante scelto dalla pagina iniziale: $($choice.text)"
    Start-Sleep -Milliseconds 1800

    # La scelta imposta il ristorante nella sessione Bomito. Solo dopo apriamo
    # il link G/L: aprirlo prima puo lasciare attivo il ristorante predefinito.
    Wait-ForBomitoOverview

    if (-not (Test-BomitoRestaurantSelected -Target $Target)) {
        throw "Bomito ha aperto G/L con il ristorante errato (selettore: '$script:LastBomitoRestaurantText'). Atteso '$Target'. Nessuna fattura importata."
    }

    Add-Log "Pagina G/L aperta con ristorante confermato: $Target (selettore: $script:LastBomitoRestaurantText)"
}

function Click-BomitoRestaurantOption {
    param([Parameter(Mandatory = $true)][string]$Target)

    $targetJson = $Target | ConvertTo-Json -Compress

    $js = @"
(() => {
  const target=$targetJson;
  const norm=s=>String(s||'')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g,'')
    .replace(/\s+/g,' ')
    .trim();
  const wanted=norm(target);
  const visible=e=>{
    const r=e.getBoundingClientRect();
    const s=getComputedStyle(e);
    return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
  };

  for(const sel of [...document.querySelectorAll('select')].filter(visible)){
    const opts=[...sel.options];
    const i=opts.findIndex(o=>norm(o.textContent).includes(wanted));
    if(i>=0){
      sel.selectedIndex=i;
      sel.value=opts[i].value;
      sel.dispatchEvent(new Event('input',{bubbles:true}));
      sel.dispatchEvent(new Event('change',{bubbles:true}));
      return JSON.stringify({ok:true,mode:'select',text:opts[i].textContent.trim()});
    }
  }

  const raw=[...document.querySelectorAll('a,button,[role="option"],[role="menuitem"],li,div,span')]
    .filter(e=>{
      if(!visible(e)) return false;
      const r=e.getBoundingClientRect();
      if(r.top<80 || r.top>700) return false;
      const t=norm(e.innerText || e.textContent || '');
      return t && t.length<=200 && t.includes(wanted);
    })
    .map(e=>{
      let click=e.closest('a,button,[role="option"],[role="menuitem"],li');
      if(!click) click=e;
      const r=click.getBoundingClientRect();
      const text=String(click.innerText||click.textContent||'').replace(/\s+/g,' ').trim();
      let score=0;
      const tag=click.tagName.toLowerCase();
      if(tag==='a' || tag==='button') score+=100;
      if(click.getAttribute('role')==='option' || click.getAttribute('role')==='menuitem') score+=100;
      if(tag==='li') score+=70;
      if(norm(text)===wanted) score+=80;
      score-=Math.min(80,text.length/3);
      score-=Math.min(30,Math.max(0,r.top-500)/10);
      return {click,score,text};
    })
    .sort((a,b)=>b.score-a.score);

  if(!raw.length) return JSON.stringify({ok:false,reason:'target-option-not-found'});
  const chosen=raw[0];
  const rect=chosen.click.getBoundingClientRect();
  return JSON.stringify({ok:true,mode:'menu',text:chosen.text,score:chosen.score,x:rect.left+rect.width/2,y:rect.top+rect.height/2});
})()
"@

    $result = (Invoke-JavaScript $js) | ConvertFrom-Json
    if ($result.ok -and $result.mode -eq 'menu') {
        Invoke-BomitoPhysicalClick -X ([double]$result.x) -Y ([double]$result.y)
    }
    return $result
}

function Ensure-BomitoRestaurant {
    param([Parameter(Mandatory = $true)][string]$Target)

    Add-Log "Ristorante Bomito richiesto: $Target"

    if (Test-BomitoRestaurantSelected -Target $Target) {
        Add-Log "Ristorante Bomito gia corretto: $Target"
        return
    }

    $direct = Click-BomitoRestaurantOption -Target $Target
    if ($direct.ok) {
        Add-Log "Selezione ristorante diretta: $($direct.mode) | $($direct.text)"
    }
    else {
        $selector = Click-BomitoRestaurantSelector
        if (-not $selector.ok) {
            throw "Non trovo il selettore del ristorante Bomito. Target: $Target"
        }

        Add-Log "Apro selettore ristorante: $($selector.text)"
        Start-Sleep -Milliseconds 700

        $choice = Click-BomitoRestaurantOption -Target $Target
        if (-not $choice.ok) {
            throw "Nel menu Bomito non trovo il ristorante '$Target'."
        }

        Add-Log "Ristorante selezionato: $($choice.text)"
    }

    $deadline = (Get-Date).AddSeconds(35)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 700
        try {
            if (Test-BomitoRestaurantSelected -Target $Target) {
                Add-Log "Ristorante Bomito verificato: $Target"
                # The restaurant menu already returns to the correct G/L context.
                # Reloading the generic overview URL here resets Bomito to the
                # default restaurant on some accounts.
                return
            }
        } catch {
            Add-Log "Verifica ristorante: $($_.Exception.Message)"
        }
    }

    throw "Non riesco a selezionare/verificare il ristorante Bomito '$Target'."
}

function Get-VisiblePeriod {
    $js = @'
JSON.stringify((() => {
  const rx=/^20\d{2}\/(0[1-9]|1[0-2])$/;
  const visible=e=>{
    const r=e.getBoundingClientRect();
    const s=getComputedStyle(e);
    return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
  };

  const items=[...document.querySelectorAll('a,button,span,div,input,td')]
    .filter(e=>{
      if(!visible(e)) return false;
      const t=((e.value || e.textContent || "")+"").trim();
      return rx.test(t);
    })
    .map(e=>{
      const r=e.getBoundingClientRect();
      return {period:((e.value || e.textContent || "")+"").trim(),
              left:r.left,right:r.right,top:r.top,bottom:r.bottom};
    });

  if(!items.length) return {period:null};
  items.sort((a,b)=>a.top-b.top || a.left-b.left);
  return items[0];
})())
'@

    return (Invoke-JavaScript $js) | ConvertFrom-Json
}

function Wait-ForMonthMode {
    $deadline = (Get-Date).AddSeconds(45)

    while ((Get-Date) -lt $deadline) {
        try {
            $info = Get-VisiblePeriod
            if ($info.period) {
                Add-Log "Vista mensile attiva: $($info.period)"
                return
            }
        } catch {}

        Start-Sleep -Milliseconds 500
    }

    throw 'Non riesco ad attivare la vista mensile di Bomito.'
}

function Activate-MonthMode {
    Add-Log 'Attivo filtro Month.'
    Navigate $MonthUrl
    Start-Sleep -Seconds 1

    try {
        $info = Get-VisiblePeriod
        if ($info.period) { return }
    } catch {}

    # Fallback: find the exact Month filter link in the currently loaded page.
    $monthHref = [string](Invoke-JavaScript @'
(() => {
  const a=[...document.querySelectorAll('a[href]')]
    .find(x => /newfiltertype=month/i.test(x.href||""));
  return a ? a.href : "";
})()
'@)

    if ($monthHref) {
        Add-Log "Fallback filtro mese: $monthHref"
        Navigate $monthHref
    }

    Wait-ForMonthMode
}

function Period-Index {
    param([string]$Text)

    $parts = $Text.Split('/')

    if ($parts.Count -ne 2) {
        throw "Periodo non valido: $Text"
    }

    return ([int]$parts[0] * 12) + [int]$parts[1]
}

function Click-PeriodSide {
    param([ValidateSet('left','right')][string]$Side)

    $sideJson = $Side | ConvertTo-Json -Compress

    $js = @"
(() => {
  const side=$sideJson;
  const rx=/^20\d{2}\/(0[1-9]|1[0-2])`$/;

  const visible=e=>{
    const r=e.getBoundingClientRect();
    const s=getComputedStyle(e);
    return r.width>0 && r.height>0 && s.display!=="none" && s.visibility!=="hidden";
  };

  const periods=[...document.querySelectorAll('a,button,span,div,input,td')]
    .filter(e=>{
      if(!visible(e)) return false;
      const t=((e.value || e.textContent || "")+"").trim();
      return rx.test(t);
    })
    .map(e=>({e,r:e.getBoundingClientRect()}));

  if(!periods.length) return false;

  periods.sort((a,b)=>a.r.top-b.r.top || a.r.left-b.r.left);

  const p=periods[0];
  const pr=p.r;
  const cy=pr.top+pr.height/2;

  const clickables=[...document.querySelectorAll(
      'a,button,input[type=button],input[type=submit]')]
    .filter(visible)
    .map(e=>({e,r:e.getBoundingClientRect()}))
    .filter(x=>Math.abs((x.r.top+x.r.height/2)-cy)<50);

  let candidates;

  if(side==="left"){
    candidates=clickables
      .filter(x=>x.r.right<=pr.left+12)
      .sort((a,b)=>Math.abs(a.r.right-pr.left)-Math.abs(b.r.right-pr.left));
  } else {
    candidates=clickables
      .filter(x=>x.r.left>=pr.right-12)
      .sort((a,b)=>Math.abs(a.r.left-pr.right)-Math.abs(b.r.left-pr.right));
  }

  if(!candidates.length) return false;

  candidates[0].e.click();
  return true;
})()
"@

    return [bool](Invoke-JavaScript $js)
}

function Wait-PeriodChange {
    param([string]$OldPeriod, [int]$TimeoutSeconds = 20)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)

    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 350

        try {
            $info = Get-VisiblePeriod
            if ($info.period -and $info.period -ne $OldPeriod) {
                return [string]$info.period
            }
        } catch {}
    }

    return ''
}

function Set-BomitoPeriod {
    param([string]$TargetPeriod)

    $targetSlash = $TargetPeriod.Replace('-', '/')
    $targetIndex = Period-Index $targetSlash

    $info = Get-VisiblePeriod

    if (-not $info.period) {
        throw 'Mese corrente Bomito non leggibile.'
    }

    if ($info.period -eq $targetSlash) {
        Add-Log "Periodo gia corretto: $targetSlash"
        return
    }

    # Learn which arrow means previous/next month from the live page.
    $before = [string]$info.period

    if (-not (Click-PeriodSide 'left')) {
        throw 'Non riesco a premere il controllo mese a sinistra.'
    }

    $after = Wait-PeriodChange $before

    if (-not $after) {
        throw 'Bomito non ha cambiato mese dopo il primo click.'
    }

    $beforeIndex = Period-Index $before
    $afterIndex = Period-Index $after
    $delta = $afterIndex - $beforeIndex

    if ([Math]::Abs($delta) -ne 1) {
        throw "Cambio mese inatteso: $before -> $after"
    }

    $forwardSide = if ($delta -gt 0) { 'left' } else { 'right' }
    $backwardSide = if ($delta -lt 0) { 'left' } else { 'right' }

    Add-Log "Direzione mesi: forward=$forwardSide backward=$backwardSide"

    for ($i=0; $i -lt 120; $i++) {
        $currentInfo = Get-VisiblePeriod

        if (-not $currentInfo.period) {
            throw 'Periodo Bomito non leggibile durante la navigazione.'
        }

        if ($currentInfo.period -eq $targetSlash) {
            Add-Log "Periodo impostato: $targetSlash"
            return
        }

        $currentIndex = Period-Index $currentInfo.period
        $side = if ($targetIndex -gt $currentIndex) {
            $forwardSide
        } else {
            $backwardSide
        }

        $oldPeriod = [string]$currentInfo.period

        if (-not (Click-PeriodSide $side)) {
            throw "Non riesco a premere il controllo mese '$side'."
        }

        $newPeriod = Wait-PeriodChange $oldPeriod

        if (-not $newPeriod) {
            throw "Bomito non ha cambiato mese da $oldPeriod."
        }

        Add-Log "Mese: $oldPeriod -> $newPeriod"
    }

    throw 'Troppi tentativi durante la selezione del mese.'
}

function Get-AccountLinks {
    $codes = @($Accounts | ForEach-Object { $_.Code })
    $codesJson = $codes | ConvertTo-Json -Compress

    # Bomito does not always render account cards as normal <a href> links.
    # Some installations/versions use onclick/data-* attributes on the card.
    # Search the entire DOM and every relevant attribute/handler, then extract
    # the real reporting_financialaccounts_detail.cfm URL.
    $js = @"
JSON.stringify((() => {
  const codes=$codesJson;
  const out={};

  const decodeHtml = (s) => {
    if(!s) return '';
    const ta=document.createElement('textarea');
    ta.innerHTML=String(s);
    return ta.value
      .replace(/\\u0026/gi,'&')
      .replace(/\\x26/gi,'&');
  };

  const normalizeUrl = (raw, code) => {
    if(!raw) return '';
    let s=decodeHtml(raw).replace(/\\/g,'');

    // Direct URL inside href, onclick, data-url, outerHTML, etc.
    const re=/((?:https?:\/\/[^\s"'<>]+)?(?:\/?application\/)?reporting_financialaccounts_detail\.cfm\?[^\s"'<>)]*)/ig;
    let m;
    while((m=re.exec(s))!==null){
      let candidate=m[1].replace(/&amp;/gi,'&');
      try{
        const u=new URL(candidate, location.href);
        if(u.searchParams.get('no')===code) return u.href;
      }catch(e){}
    }

    return '';
  };

  const attrsFor = (e) => {
    const vals=[];
    if(!e) return vals;

    for(const name of ['href','onclick','data-href','data-url','data-link','data-target','formaction']){
      try{
        const v=e.getAttribute && e.getAttribute(name);
        if(v) vals.push(v);
      }catch(err){}
    }

    try{
      if(typeof e.onclick==='function') vals.push(e.onclick.toString());
    }catch(err){}

    try{ vals.push(e.outerHTML||''); }catch(err){}
    return vals;
  };

  const all=[...document.querySelectorAll('body *')];
  const pageHtml=document.documentElement ? document.documentElement.outerHTML : '';

  for(const code of codes){
    let found='';

    // 1) Normal anchors - fastest path.
    for(const a of document.querySelectorAll('a[href]')){
      found=normalizeUrl(a.href, code);
      if(found) break;
    }

    // 2) Elements/cards containing the account code plus ancestors/descendants.
    if(!found){
      const codeNodes=all.filter(e => {
        const t=((e.innerText||e.textContent||'')+'').trim();
        return t.includes(code);
      });

      // Prefer the smallest text container: usually the number/card itself.
      codeNodes.sort((a,b) => {
        const at=((a.innerText||a.textContent||'')+'').length;
        const bt=((b.innerText||b.textContent||'')+'').length;
        return at-bt;
      });

      for(const node of codeNodes.slice(0,30)){
        const candidates=[];
        let cur=node;
        for(let depth=0; cur && depth<8; depth++,cur=cur.parentElement){
          candidates.push(cur);
          try{
            for(const d of cur.querySelectorAll('a,button,[onclick],[data-href],[data-url],[data-link]')){
              candidates.push(d);
            }
          }catch(err){}
        }

        for(const el of candidates){
          for(const raw of attrsFor(el)){
            found=normalizeUrl(raw, code);
            if(found) break;
          }
          if(found) break;
        }
        if(found) break;
      }
    }

    // 3) Last DOM-level scan. This also catches URLs in inline scripts.
    if(!found){
      found=normalizeUrl(pageHtml, code);
    }

    if(found) out[code]=found;
  }

  return out;
})())
"@

    $links = (Invoke-JavaScript $js) | ConvertFrom-Json

    # Restaurant-specific fallback links are configurable. The bot always
    # prefers links discovered live from the current G/L accounts page.
    foreach ($code in $AccountFallbackLinks.Keys) {
        if (-not $links.PSObject.Properties[$code]) {
            $fallbackUrl = [string]$AccountFallbackLinks[$code]
            if ($fallbackUrl) {
                $links | Add-Member -NotePropertyName $code -NotePropertyValue $fallbackUrl -Force
                Add-Log "Conto $code`: uso link detail configurato come fallback."
            }
        }
    }

    return $links
}

function Write-AccountDiagnostics {
    param([string[]]$MissingCodes)

    if (-not $MissingCodes -or $MissingCodes.Count -eq 0) { return }

    try {
        $codesJson = $MissingCodes | ConvertTo-Json -Compress
        $js = @"
JSON.stringify((() => {
  const codes=$codesJson;
  const out={};
  const all=[...document.querySelectorAll('body *')];

  for(const code of codes){
    const matches=all
      .filter(e=>(((e.innerText||e.textContent||'')+'').includes(code)))
      .sort((a,b)=>(((a.innerText||a.textContent||'')+'').length)-(((b.innerText||b.textContent||'')+'').length))
      .slice(0,8)
      .map(e=>({
        tag:e.tagName,
        text:((e.innerText||e.textContent||'')+'').trim().slice(0,500),
        href:e.getAttribute ? e.getAttribute('href') : null,
        onclick:e.getAttribute ? e.getAttribute('onclick') : null,
        dataHref:e.getAttribute ? e.getAttribute('data-href') : null,
        dataUrl:e.getAttribute ? e.getAttribute('data-url') : null,
        html:(e.outerHTML||'').slice(0,2000)
      }));
    out[code]=matches;
  }
  return out;
})())
"@

        $diag = Invoke-JavaScript $js
        $diagPath = Join-Path $LogDir ("account_dom_${Period}_${stamp}.json")
        [System.IO.File]::WriteAllText(
            $diagPath,
            [string]$diag,
            [System.Text.Encoding]::UTF8
        )
        Add-Log "Diagnostica DOM conti salvata: $diagPath"
    }
    catch {
        Add-Log "Impossibile salvare diagnostica DOM conti: $($_.Exception.Message)"
    }
}

function Fetch-AccountRows {
    param($Links)

    $map = @{}
    foreach ($p in $Links.PSObject.Properties) {
        $map[$p.Name] = [string]$p.Value
    }

    $mapJson = $map | ConvertTo-Json -Compress -Depth 5

    $js = @"
(async () => {
  const links=$mapJson;
  const rows=[];
  const errors=[];

  for(const code of Object.keys(links)){
    try{
      const resp=await fetch(links[code], {
        credentials:'include',
        cache:'no-store'
      });

      const html=await resp.text();
      const doc=new DOMParser().parseFromString(html,'text/html');

      if(doc.querySelector('input[type=password]')){
        errors.push(code + ': sessione Bomito non valida');
        continue;
      }

      const trs=[...doc.querySelectorAll('tr')];

      for(const tr of trs){
        const cells=[...tr.querySelectorAll('td')]
          .map(td=>(td.innerText||td.textContent||'').trim());

        if(cells.length<4) continue;
        if(!/^\d{2}\.\d{2}\.\d{4}$/.test(cells[1])) continue;

        rows.push({
          account:code,
          supplier:cells[0],
          date:cells[1],
          document:cells[2],
          amount:cells[cells.length-1]
        });
      }
    }
    catch(e){
      errors.push(code + ': ' + (e && e.message ? e.message : String(e)));
    }
  }

  return JSON.stringify({rows,errors});
})()
"@

    return (Invoke-JavaScript $js) | ConvertFrom-Json
}

function Save-AccountExtractions {
    param($Rows)

    foreach ($account in $Accounts) {
        $code = $account.Code
        $path = Join-Path $DownloadDir ($code + '.tsv')

        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add("account`tdate`tdocument`tsupplier`tamount")

        foreach ($row in @($Rows | Where-Object { $_.account -eq $code })) {
            $lines.Add(
                (Safe-Text $row.account) + "`t" +
                (Safe-Text $row.date) + "`t" +
                (Safe-Text $row.document) + "`t" +
                (Safe-Text $row.supplier) + "`t" +
                (Safe-Text $row.amount)
            )
        }

        [System.IO.File]::WriteAllLines(
            $path,
            $lines,
            [System.Text.Encoding]::Default
        )
    }
}

function Save-ErrorScreenshot {
    try {
        if ($script:WebSocket -and
            $script:WebSocket.State -eq [System.Net.WebSockets.WebSocketState]::Open) {

            $shot = Invoke-Cdp -Method 'Page.captureScreenshot' -Params @{
                format='png'
                captureBeyondViewport=$true
            }

            if ($shot.result.data) {
                [System.IO.File]::WriteAllBytes(
                    $ScreenshotFile,
                    [Convert]::FromBase64String($shot.result.data)
                )
            }
        }
    }
    catch {
        Add-Log "Screenshot errore non salvato: $($_.Exception.Message)"
    }
}

try {
    if (Test-Path -LiteralPath $Output) {
        Remove-Item -LiteralPath $Output -Force
    }

    Add-Log "Avvio BomitoBot per periodo $Period"

    $script:Stage = 'avvio Microsoft Edge'
    Start-DedicatedEdge

    $script:Stage = 'collegamento al browser'
    Connect-Cdp

    $script:Stage = 'accesso e pagina scelta ristorante Bomito'
    Open-BomitoRestaurantSelection -Target $RestaurantTarget

    $script:Stage = 'selezione ristorante Bomito dalla pagina iniziale'
    Select-BomitoRestaurantFromStartPage -Target $RestaurantTarget

    $script:Stage = 'attivazione filtro Month'
    Activate-MonthMode

    $script:Stage = 'selezione mese'
    Set-BomitoPeriod $Period

    $script:Stage = 'verifica ristorante dopo selezione mese'
    if (-not (Test-BomitoRestaurantSelected -Target $RestaurantTarget)) {
        Add-Log "Il cambio mese ha perso il ristorante $RestaurantTarget; ripeto selezione ristorante e mese."
        Ensure-BomitoRestaurant -Target $RestaurantTarget
        Activate-MonthMode
        Set-BomitoPeriod $Period
        if (-not (Test-BomitoRestaurantSelected -Target $RestaurantTarget)) {
            throw "Bomito non mantiene selezionato il ristorante '$RestaurantTarget' (selettore: '$script:LastBomitoRestaurantText'). Nessuna fattura importata."
        }
    }
    Add-Log "Ristorante confermato prima della lettura importi: $RestaurantTarget (selettore: $script:LastBomitoRestaurantText)"

    $script:Stage = 'ricerca conti contabili'
    $links = Get-AccountLinks

    $missing = New-Object System.Collections.Generic.List[string]
    $missingRequired = New-Object System.Collections.Generic.List[string]

    foreach ($account in $Accounts) {
        $prop = $links.PSObject.Properties[$account.Code]

        if (-not $prop) {
            $missing.Add($account.Code)

            if ($account.ContainsKey('Required') -and $account.Required) {
                $missingRequired.Add("$($account.Code) $($account.Label)")
            }
        }
    }

    if ($missing.Count -gt 0) {
        Write-AccountDiagnostics -MissingCodes @($missing)
    }

    if ($missingRequired.Count -gt 0) {
        throw (
            'Conti principali Bomito non trovati nella vista mensile: ' +
            ($missingRequired -join ', ')
        )
    }

    if ($missing.Count -gt 0) {
        Add-Log "Conti non presenti nel mese: $($missing -join ', ')"
    }

    $script:Stage = 'estrazione fatture'
    $fetch = Fetch-AccountRows $links

    $script:Stage = 'verifica finale ristorante Bomito'
    if (-not (Test-BomitoRestaurantSelected -Target $RestaurantTarget)) {
        throw "Il ristorante attivo e cambiato durante la lettura (selettore: '$script:LastBomitoRestaurantText'). Nessuna fattura importata."
    }
    Add-Log "Verifica finale ristorante superata: $RestaurantTarget (selettore: $script:LastBomitoRestaurantText)"

    if ($fetch.errors -and @($fetch.errors).Count -gt 0) {
        Add-Log "Avvisi estrazione: $($fetch.errors -join ' | ')"
    }

    $rows = @($fetch.rows)

    foreach ($account in $Accounts) {
        $rowCount = @($rows | Where-Object { $_.account -eq $account.Code }).Count
        Add-Log "Conto $($account.Code) $($account.Label): $rowCount righe estratte."
    }

    # Save one extraction file per account, like the files consumed by the macro.
    Save-AccountExtractions $rows

    Write-ResultFile `
        -Status 'OK' `
        -Message 'Fatture Bomito estratte correttamente.' `
        -Rows $rows `
        -MissingAccounts @($missing)

    Add-Log "Completato. Righe lette: $($rows.Count)."

    try {
        Invoke-Cdp -Method 'Browser.close' | Out-Null
    } catch {}

    exit 0
}
catch {
    $originalFailure=$_
    try { Set-BwaBrowserVisibility -Port $Port -Profile $ProfileDir -Visible $true } catch {}
    $message = "Fase: $script:Stage. $($originalFailure.Exception.Message)"

    Add-Log "ERRORE: $message"
    Save-ErrorScreenshot

    Write-ResultFile `
        -Status 'ERROR' `
        -Message $message `
        -Rows @()

    exit 1
}
finally {
    try {
        if ($script:WebSocket) {
            $script:WebSocket.Dispose()
        }
    } catch {}
}
