﻿# Keep the normal Edge engine and session; only change the dedicated window visibility.
function Get-BwaOwnedBrowser {
    param([int]$Port,[string]$Profile)
    $listener=Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if(-not $listener){return $null}
    $owned=Get-CimInstance Win32_Process -Filter ('ProcessId='+$listener.OwningProcess) -ErrorAction Stop
    $command=[string]$owned.CommandLine
    $profileArgument='--user-data-dir="?'+[regex]::Escape($Profile.TrimEnd('\'))+'"?(?=\s|$)'
    if($owned.Name -ine 'msedge.exe' -or $command -notmatch $profileArgument -or $command -notmatch ('--remote-debugging-port='+$Port+'(?=\s|$)')){throw 'La porta del bot appartiene a un altro processo. Nessuna finestra modificata.'}
    return $owned
}
function Reset-BwaLegacyHeadless {
    param([int]$Port,[string]$Profile)
    $owned=Get-BwaOwnedBrowser -Port $Port -Profile $Profile
    if($owned -and $owned.CommandLine -match '(?i)(?:^|\s)--headless(?:=\S+)?(?:\s|$)'){
        Stop-Process -Id $owned.ProcessId -ErrorAction Stop
        $deadline=(Get-Date).AddSeconds(10)
        while((Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue) -and (Get-Date) -lt $deadline){Start-Sleep -Milliseconds 250}
        if(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue){throw 'Chiudi il precedente browser dedicato e riprova.'}
    }
}
function Set-BwaBrowserVisibility {
    param([int]$Port,[string]$Profile,[bool]$Visible)
    $owned=Get-BwaOwnedBrowser -Port $Port -Profile $Profile
    if(-not $owned){throw 'Browser dedicato non disponibile.'}
    if(-not ('BwaBrowserWindows' -as [type])){
        Add-Type @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;
public static class BwaBrowserWindows {
 public delegate bool Callback(IntPtr window,IntPtr data);
 [DllImport("user32.dll")]static extern bool EnumWindows(Callback callback,IntPtr data);
 [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(IntPtr window,out uint process);
 [DllImport("user32.dll")]public static extern bool IsWindowVisible(IntPtr window);
 [DllImport("user32.dll")]static extern bool ShowWindowAsync(IntPtr window,int command);
 [DllImport("user32.dll")]static extern bool SetWindowPos(IntPtr window,IntPtr after,int x,int y,int width,int height,uint flags);
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetClassName(IntPtr window,System.Text.StringBuilder name,int size);
 public static IntPtr[] Windows(uint process){var windows=new List<IntPtr>();EnumWindows(delegate(IntPtr w,IntPtr d){uint p;GetWindowThreadProcessId(w,out p);var name=new System.Text.StringBuilder(128);GetClassName(w,name,128);if(p==process&&name.ToString().StartsWith("Chrome_WidgetWin_"))windows.Add(w);return true;},IntPtr.Zero);return windows.ToArray();}
 public static int Set(uint process,bool visible){var windows=Windows(process);foreach(var w in windows){if(visible){SetWindowPos(w,IntPtr.Zero,80,80,1280,900,0x0014);ShowWindowAsync(w,9);}else ShowWindowAsync(w,0);}return windows.Length;}
}
'@
    }
    $deadline=(Get-Date).AddSeconds(8)
    do{$count=[BwaBrowserWindows]::Set([uint32]$owned.ProcessId,$Visible);if($count -gt 0){return};Start-Sleep -Milliseconds 200}while((Get-Date) -lt $deadline)
    throw 'Finestra del browser dedicato non disponibile.'
}
