"""Read the original BWA Budget layout without Excel or macro execution."""
import sys,json,zipfile,xml.etree.ElementTree as ET,posixpath,datetime as dt,re,hashlib,pathlib
from decimal import Decimal
TARGETS='B7|C8|C9|C10|C11|C12|C13|C14|C16|C18|C19|C20|C24|C27|C28|C32|C33|C35|C36|C37|C38|C39|C40|C42|C43|C44|C45|C46|C47|C48|C49|C51|C52|C53|C54|C55|C56|C58|C59|C60|C62|B66|B67|B68|B69|B70|C71|C72|C73|C74|B75'.split('|')
CODES='1020|1110|1111|1120|1121|1122|1130|1131|1201|1203|1204|0|1215|1221|1223|1230|1240|1270|1271|1272|1273|1274|1275|1280|1281|1282|1283|1284|1285|1286|1287|1290|1300|1310|1330|1340|1341|1350|1351|1352|1360|1420|1450|1470|1430|1520|1545|1546|1547|1556|1590'.split('|')
TEST=set('1020|1110|1122|1201|1271|1286|1310|1330|1420|1470|1545|1556'.split('|'))
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def col(n):
 s=''
 while n:n,r=divmod(n-1,26);s=chr(65+r)+s
 return s
def read(path):
 p=pathlib.Path(path)
 with zipfile.ZipFile(p) as z:
  if sum(e.file_size for e in z.infolist())>100*1024*1024:raise ValueError('Budget: file troppo grande')
  strings=[]
  if 'xl/sharedStrings.xml' in z.namelist():strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml'))]
  def text(c):
   if c is None:return ''
   t=c.get('t');v=c.find('s:v',NS)
   if t=='inlineStr':return ''.join(c.find('s:is',NS).itertext())
   if v is None:return ''
   if t=='s':return strings[int(v.text)]
   return v.text or ''
  def number(c,ref):
   if c is not None and c.get('t')=='e':raise ValueError('Budget: errore nella cella '+ref)
   value=text(c).strip()
   if not value:
    if c is not None and c.find('s:f',NS) is not None:raise ValueError('Budget: formula senza risultato salvato in '+ref+'. Ricalcolare e salvare il file sorgente.')
    return Decimal(0)
   try:
    result=Decimal(value)
    if not result.is_finite():raise ValueError()
    return result
   except Exception:raise ValueError('Budget: importo non numerico in '+ref)
  rels={r.get('Id'):r.get('Target') for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  book=ET.fromstring(z.read('xl/workbook.xml'));chosen=None;score=0
  for sh in book.find('s:sheets',NS):
   target=rels[sh.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
   target=target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)
   cells={c.get('r'):c for c in ET.fromstring(z.read(target)).findall('.//s:sheetData/s:row/s:c',NS)}
   rows={}
   for ref,c in cells.items():
    if re.fullmatch(r'B\d+',ref):
     raw=text(c).strip()
     try:raw=str(int(Decimal(raw))) if Decimal(raw)==int(Decimal(raw)) else raw
     except Exception:pass
     if raw in CODES:rows.setdefault(raw,[]).append(int(ref[1:]))
   n=len(TEST.intersection(rows))
   if n>score:score=n;chosen=(sh.get('name'),cells,rows)
  if score<10:raise ValueError('Budget: nessun foglio BWA Budget compatibile')
  sheet,cells,rows=chosen
  for code in CODES:
   if code=='0':continue
   if len(rows.get(code,[]))!=1:raise ValueError('Budget: codice BWA mancante o duplicato '+code)
  raw=text(cells.get('D4'));year=None
  try:
   numeric=Decimal(raw);date1904=book.find('s:workbookPr',NS)
   epoch=dt.datetime(1904,1,1) if date1904 is not None and date1904.get('date1904') in ('1','true') else dt.datetime(1899,12,30)
   year=int(numeric) if 2000<=numeric<=2100 else (epoch+dt.timedelta(days=float(numeric))).year
  except Exception:
   for fmt in ('%Y-%m-%d','%d/%m/%Y','%d.%m.%Y'):
    try:year=dt.datetime.strptime(raw,fmt).year;break
    except ValueError:pass
  if year is None or not 2000<=year<=2100:
   match=re.search(r'20\d{2}',sheet);year=int(match[0]) if match else None
  if year is None or not 2000<=year<=2100:raise ValueError('Budget: anno non riconosciuto')
  amounts={}
  for code in CODES:
   amounts[code]=[0]*12 if code=='0' else [float(number(cells.get(col(4+m*4)+str(rows[code][0])),sheet+'!'+col(4+m*4)+str(rows[code][0]))) for m in range(12)]
  return dict(Year=year,Amounts=amounts,SourceName=p.name,SourceSheet=sheet,SourceHash=hashlib.sha256(p.read_bytes()).hexdigest())
if __name__=='__main__':
 try:result={'ok':True,'budget':read(sys.argv[1])}
 except Exception as e:result={'ok':False,'error':str(e)}
 pathlib.Path(sys.argv[2]).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
 if not result['ok']:sys.exit(1)
