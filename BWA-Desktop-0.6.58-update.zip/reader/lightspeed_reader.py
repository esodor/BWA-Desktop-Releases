"""Read Lightspeed French business PDF and XLS exports without Office.
No network or writes to the source files. Fail closed on an unknown layout.
"""
import sys,json,re,unicodedata,hashlib,datetime,pathlib
from decimal import Decimal
from pypdf import PdfReader
import xlrd

def norm(s):
    return re.sub(r'[^a-z0-9%]+',' ',''.join(c for c in unicodedata.normalize('NFKD',str(s)).lower() if not unicodedata.combining(c))).strip()
MONEY=re.compile(r'(?<![\d.,])[-−]?\d(?:[\d \u00a0\u202f]*\d)?[,.]\d{2}(?!\d)')
def money(s):
    if isinstance(s,(int,float)): return Decimal(str(s))
    s=str(s).strip().replace('−','-');s=re.sub(r'[\s\u00a0\u202f]','',s)
    if ',' in s:s=s.replace('.','').replace(',','.')
    return Decimal(s)
def amounts(line):return [money(m[0]) for m in MONEY.finditer(line)]
def scalar(lines,labels,required=True):
    labels={norm(x) for x in labels};found=[]
    for line in lines:
        m=MONEY.search(line)
        if m and norm(line[:m.start()]) in labels:found.append(money(m[0]))
    if not found and not required:return Decimal(0)
    if len(found)!=1:raise ValueError('Valore mancante o ambiguo: '+next(iter(labels)))
    return found[0]
def workbook(path):
    b=xlrd.open_workbook(path,on_demand=True)
    if b.nsheets!=1:raise ValueError('Report XLS con numero di fogli inatteso')
    s=b.sheet_by_index(0);return [s.row_values(i) for i in range(s.nrows)]
def filecheck(path,kind,date):
    path=pathlib.Path(path);tomorrow=date+datetime.timedelta(days=1)
    m=re.fullmatch(r'(.+)_'+kind+'_'+date.strftime('%Y%m%d')+'_'+tomorrow.strftime('%Y%m%d')+r'(?: \(\d+\))?\.(pdf|xls)',path.name,re.I)
    if not m:raise ValueError('Nome, data o tipo del report non corrispondente: '+path.name)
    return m[1].lower()
ALIASES={
 'Cash':['Espèces','Cash','Bargeld'], 'Lightspeed':['Lightspeed Payments'],
 'Maestro':['Maestro','Kreditkarte','Mastercard','Maestro / Mastercard'],
 'Tap':['Tap to Pay sur iPhone','Tap to Pay auf dem iPhone','Tap to Pay on iPhone'],
 'Uber':['Uber Eats External','Uber Eats'], 'Wolt':['Wolt External'], 'Visa':['Visa'],
 'Amex':['American Express','Amex'], 'Invoice':['Facture','Invoice'],
 'Webshop':['LO Webshop Pick Up','LO Webshop PickUp','LO Webshop Pickup','LO Webshop Pick-Up','Webshop Pick Up'],
 'WebshopDelivery':['LO Webshop Delivery','LO Webshop Delivey'],
 'Sodexo':['Sodexo','Pluxee (Sodexo)','Pluxee'], 'Edenred':['Edenred','Ticket Resto','Ticket Restaurant'], 'GiftCard':['Gift Card']}
def check_restaurant(expected, actual):
    words=[w for w in norm(expected or '').split() if w not in ('l','osteria','losteria')]
    key=''.join(words)
    found=[w for w in norm(actual or '').replace('losteria',' ').split() if w not in ('l','osteria')]
    # Verified Lightspeed site name: Kirchberg Infinity is exported without spaces.
    # Expand only this known token; arbitrary substring matches can select another site.
    found=[part for word in found for part in ('kirchberg infinity'.split() if word=='kirchberginfinity' else [word])]
    words=[part for word in words for part in ('kirchberg infinity'.split() if word=='kirchberginfinity' else [word])]
    if not key:raise ValueError('Configura il nome completo del ristorante in Admin, inclusa la sede.')
    if not any(found[i:i+len(words)]==words for i in range(len(found))):raise ValueError('Il report non corrisponde al ristorante configurato: '+str(expected))

def parse(config):
    date=datetime.date.fromisoformat(config['date']);paths=[config[k] for k in ['business','discounts','cancellations']]
    identities=[filecheck(p,k,date) for p,k in zip(paths,['business_report_day','discounts','cancellations'])]
    if len(set(identities))!=1:raise ValueError('I tre report appartengono a ristoranti diversi')
    example=config.get('expectedReportIdentity')
    if example:
        if identities[0]!=example.lower():raise ValueError('Il report non corrisponde al ristorante configurato: '+str(config.get('expectedRestaurant')))
    else:check_restaurant(config.get('expectedRestaurant'),identities[0])
    reader=PdfReader(paths[0]);
    if reader.is_encrypted:raise ValueError('PDF cifrato non supportato')
    lines='\n'.join(p.extract_text(extraction_mode='layout') or '' for p in reader.pages).splitlines()
    lines=[s.strip() for s in lines if s.strip()]
    months=['janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre']
    heading=next((norm(s) for s in lines if norm(s).startswith('rapport operationnel pour ')),None)
    expected=f'{date.day} {months[date.month-1]} {date.year}'
    if not heading or not heading.endswith(expected):raise ValueError('La data interna del PDF non corrisponde alla giornata')
    start=next((i for i,s in enumerate(lines) if norm(s)=='montants recus'),None)
    end=next((i for i,s in enumerate(lines) if norm(s).startswith('ca net pourboires inclus') and amounts(s)),None)
    taxstart=next((i for i,s in enumerate(lines) if 'rapport des taxes' in norm(s)),None)
    if None in (start,end,taxstart) or not start<end<taxstart:raise ValueError('Sezioni del Business Report non riconosciute')
    payments={k:Decimal(0) for k in ALIASES};seen=set()
    aliases={norm(alias):key for key,names in ALIASES.items() for alias in names}
    for line in lines[start+1:end]:
        m=MONEY.search(line)
        if not m:continue
        label=norm(line[:m.start()])
        if not label or label in ['entrees','sorties'] or 'moins les pourboires' in label:continue
        if label not in aliases:raise ValueError('Pagamento non riconosciuto: '+line[:m.start()].strip())
        if label in seen:raise ValueError('Pagamento duplicato ambiguo: '+label)
        seen.add(label);payments[aliases[label]]+=money(m[0])
    if not seen:raise ValueError('Nessun pagamento leggibile')
    gross=scalar(lines,['CA Brut (Ventes)']);net=scalar(lines,['CA net, sans les taxes'])
    inc=amounts(lines[end])[0];tips=abs(scalar(lines[end:taxstart],['Moins les pourboires']))
    totalpayments=scalar(lines[end:taxstart],['Total des paiements'],False)
    carry=scalar(lines[end:taxstart],['Total des reports'],False)
    aftertips=scalar(lines[end:taxstart],['CA net sans les pourboires'])
    taxgross={str(i):Decimal(0) for i in [3,14,17]};taxnet={str(i):Decimal(0) for i in [3,14,17]};found=[]
    for i in range(taxstart+1,len(lines)):
        label=norm(lines[i]);m=re.fullmatch(r'tva (\d+)%',label)
        if not m:continue
        rate=m[1]
        if rate not in taxgross or rate in found:raise ValueError('Aliquota inattesa o duplicata: '+rate)
        found.append(rate);block=[]
        for line in lines[i+1:]:
            if norm(line).startswith('tva ') or norm(line).startswith('taxes sur les articles'):break
            block.append(line)
        taxgross[rate]=scalar(block,['Montant taxe comprise']);taxnet[rate]=scalar(block,['Montant hors-taxe'])
    if not found:raise ValueError('Nessuna aliquota leggibile')
    checks={'Pagamenti vs totale con mance':sum(payments.values())-inc,'Lordo vs aliquote':sum(taxgross.values())-gross,'Netto vs aliquote':sum(taxnet.values())-net,'Pagamenti, mance e riporti vs lordo':inc-tips+carry-gross,'Totale finale vs lordo':aftertips-gross}
    for name,diff in checks.items():
        if abs(diff)>Decimal('.05'):raise ValueError(f'{name}: differenza {diff:.2f} EUR; importazione fermata')
    if payments['GiftCard']!=0:raise ValueError('Gift Card presente: distinguere vendita e rimborso prima di importare questo report')
    delivery=payments['Uber']+payments['Wolt']
    if delivery>taxgross['3']:raise ValueError('Delivery superiore al lordo TVA 3%; classificazione da verificare')
    covers=None;average=None
    for line in lines:
        if norm(line).startswith('moyenne par couvert sur encaissements'):
            m=re.search(r'(\d+)\s+couverts?',line,re.I)
            if m and amounts(line):covers=int(m[1]);average=amounts(line)[-1]
    if covers is None or average is None:raise ValueError('Coperti o media per coperto non leggibili')
    discountrows=workbook(paths[1]);promo=Decimal(0);discount100=Decimal(0)
    if len(discountrows)<3:raise ValueError('Report sconti incompleto')
    # Use the restaurant aggregate, never add category/product descendants again.
    top=discountrows[2];restaurant=str(top[0]).strip()
    check_restaurant(config.get('expectedRestaurant'),restaurant)
    if not restaurant or norm(restaurant).split()[:2]!=['l','osteria']:raise ValueError('Totale ristorante assente nel report sconti')
    if not any(norm(s)==norm(restaurant) for s in lines[:10]):raise ValueError('Il ristorante interno del PDF e del report sconti non coincide')
    if not all(word in norm(identities[0]).replace(' ','') for word in norm(restaurant).split()[2:3]):raise ValueError('Ristorante interno del report sconti non corrispondente')
    for j,label in enumerate(discountrows[0]):
        if norm(label) in ['100% promo personal','100% rabatt','100%']:
            if j>=len(discountrows[1]) or norm(discountrows[1][j]) not in ['montant','amount']:raise ValueError('Colonna importo sconti non riconosciuta')
            value=money(top[j]) if top[j]!='' else Decimal(0)
            if norm(label)=='100% promo personal':promo+=value
            else:discount100+=value
    canc=workbook(paths[2]);heads=[norm(x) for x in canc[0]] if canc else []
    if 'somme' not in heads or 'motif' not in heads or 'date' not in heads:raise ValueError('Intestazioni cancellazioni non riconosciute')
    amountcol=heads.index('somme');datecol=heads.index('date');motifs=[i for i,x in enumerate(heads) if x=='motif'];loss=Decimal(0)
    for row in canc[1:]:
        if not any(str(x).strip() for x in row):continue
        d=datetime.datetime.strptime(str(row[datecol])[:10],'%d.%m.%Y').date()
        if d not in [date,date+datetime.timedelta(days=1)]:raise ValueError('Cancellazione fuori dal periodo')
        if any('AP-' in str(row[i]).upper() for i in motifs):loss+=abs(money(row[amountcol]))
    sources=[{'Name':pathlib.Path(p).name,'Sha256':hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in paths]
    warnings=[]
    if carry:warnings.append('Riporto presente: '+str(carry)+' EUR (Cash Reconciliation, riga 47).')
    return {'Date':date.isoformat(),'Restaurant':restaurant,'Payments':payments,'TaxGross':taxgross,'ReportGross':gross,'ReportedNet':net,'PaymentTotal':inc,'Carry':carry,'Tips':tips,'Covers':covers,'Average':average,'Promo':promo,'Discount100':discount100,'ApLoss':loss,'Sources':sources,'Warnings':warnings,'Food':taxgross['3']-delivery,'Delivery':delivery,'Checks':checks}
def main():
    config=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
    try:result={'ok':True,'closing':parse(config)}
    except Exception as e:result={'ok':False,'error':str(e)}
    target=pathlib.Path(sys.argv[2]);temp=target.with_suffix('.tmp');temp.write_text(json.dumps(result,ensure_ascii=False,default=lambda x:float(x) if isinstance(x,Decimal) else str(x)),encoding='utf-8');temp.replace(target)
    return 0 if result['ok'] else 1
if __name__=='__main__':sys.exit(main())
