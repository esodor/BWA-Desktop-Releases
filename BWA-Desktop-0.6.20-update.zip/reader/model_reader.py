"""Import a user's local BWA workbook. Never executes VBA or Excel."""
import sys,json,zipfile,pathlib,posixpath,re,shutil,xml.etree.ElementTree as E
S={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def col(n):
 out=''
 while n:n,r=divmod(n-1,26);out=chr(65+r)+out
 return out
def xy(a):
 m=re.fullmatch(r'\$?([A-Z]+)\$?(\d+)',a);n=0
 for c in m[1]:n=n*26+ord(c)-64
 return n,int(m[2])
def shift(f,dx,dy):
 pattern=r'("(?:[^"]|"")*"|\'(?:[^\']|\'\')*\')|(?<![A-Za-z0-9_.])(?P<ca>\$?)(?P<c>[A-Z]{1,3})(?P<ra>\$?)(?P<r>\d+)(?![A-Za-z0-9_!(])'
 def sub(m):
  if m[1]:return m[1]
  x,y=xy(m['c']+m['r']);x+=0 if m['ca'] else dx;y+=0 if m['ra'] else dy
  if x<1 or y<1:raise ValueError('Formula condivisa non valida')
  return m['ca']+col(x)+m['ra']+str(y)
 return re.sub(pattern,sub,f)
def read(source,target):
 with zipfile.ZipFile(source) as z:
  if len(z.namelist())>10000 or sum(i.file_size for i in z.infolist())>256*1024*1024:raise ValueError('Modello troppo grande')
  strings=[''.join(n.itertext()) for n in E.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',S)] if 'xl/sharedStrings.xml' in z.namelist() else []
  styles=E.fromstring(z.read('xl/styles.xml'));xfs=list(styles.find('s:cellXfs',S));fmts={int(n.get('numFmtId')):n.get('formatCode') for n in styles.findall('s:numFmts/s:numFmt',S)}
  relationships={r.get('Id'):r.get('Target') for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
  output=[]
  for sh in E.fromstring(z.read('xl/workbook.xml')).findall('s:sheets/s:sheet',S):
   name=sh.get('name');rel=relationships[sh.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')];path=rel.lstrip('/') if rel.startswith('/') else posixpath.normpath('xl/'+rel)
   cells=E.fromstring(z.read(path)).findall('s:sheetData/s:row/s:c',S);masters={}
   for c in cells:
    f=c.find('s:f',S)
    if f is not None and f.get('t')=='shared' and f.text:masters[f.get('si')]=(c.get('r'),f.text)
   result=[]
   for c in cells:
    f=c.find('s:f',S);formula=None if f is None else f.text
    if f is not None and f.get('t')=='shared' and not formula:
     ref,text=masters[f.get('si')];x,y=xy(c.get('r'));mx,my=xy(ref);formula=shift(text,x-mx,y-my)
    typ=c.get('t','n');v=c.find('s:v',S);value='' if v is None else (v.text or '')
    if typ=='s':value=strings[int(value)] if value else ''
    elif typ=='inlineStr':value=''.join(t.text or '' for t in c.findall('s:is//s:t',S))
    xf=xfs[int(c.get('s','0'))];prot=xf.find('s:protection',S);locked=prot is None or prot.get('locked','1')!='0';fid=int(xf.get('numFmtId','0'));fmt=fmts.get(fid,'');kind='percent' if fid in (9,10) or '%' in fmt else 'number'
    if fid in (14,15,16,17,22) or (re.search(r'[dy]',re.sub(r'"[^"]*"|\[[^\]]*\]','',fmt),re.I) and '0' not in fmt):kind='date'
    result.append(dict(Ref=c.get('r'),Value=value,Formula=formula,Locked=locked,Type=typ,Format=kind))
   output.append(dict(Name=name,Cells=result))
  names={x['Name'] for x in output}
  if not {'BWA','START','Listen','WaWi','Cash Reconciliation','Costcheck','Cash Costs'}.issubset(names):raise ValueError('Seleziona il modello BWA originale compatibile')
  lookup={sh['Name']+'!'+c['Ref']:c for sh in output for c in sh['Cells']}
  if not all(k in lookup for k in ['BWA!B7','WaWi!Y15','Cash Reconciliation!C74','START!C4']):raise ValueError('Struttura BWA non compatibile')
  target.mkdir(parents=True,exist_ok=True);(target/'model.json').write_text(json.dumps(output,ensure_ascii=False),encoding='utf-8');shutil.copyfile(source,target/'export-template.xlsm')
if __name__=='__main__':
 target=pathlib.Path(sys.argv[2])
 try:read(pathlib.Path(sys.argv[1]),target)
 except Exception as e:
  target.mkdir(parents=True,exist_ok=True);(target/'result.json').write_text(str(e),encoding='utf-8');sys.exit(1)
