﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName Microsoft.VisualBasic
Add-Type -AssemblyName System.Windows.Forms

$appDir = Join-Path $(if ($env:BWA_BOT_ROOT) { $env:BWA_BOT_ROOT } else { $env:LOCALAPPDATA }) 'BWA-NestoBot'
$configFile = Join-Path $appDir 'nesto_url.txt'
$defaultUrl = ''
New-Item -ItemType Directory -Path $appDir -Force | Out-Null

$current = $defaultUrl
if (Test-Path -LiteralPath $configFile) {
    $saved = (Get-Content -LiteralPath $configFile -Raw -ErrorAction SilentlyContinue).Trim()
    if ($saved) { $current = $saved }
}

$message = @"
Incolla il link Nesto della pagina Recorded Assignments del ristorante.

Puoi incollare il link con o senza la data finale.
Esempio:
https://nesto.app/lolux/CODICE_RISTORANTE/recordedAssignments/2026-08-05
"@

$url = [Microsoft.VisualBasic.Interaction]::InputBox($message, 'Configura ristorante Nesto', $current)
if ([string]::IsNullOrWhiteSpace($url)) { exit 0 }

$url = $url.Trim()
$url = $url -replace '[?#].*$', ''
$url = $url.TrimEnd('/')
$url = $url -replace '/\d{4}-\d{2}-\d{2}$', ''

if ($url -notmatch '^https://nesto\.app/[^/]+/[^/]+/recordedAssignments$') {
    [System.Windows.Forms.MessageBox]::Show(
        "Link non valido.`r`n`r`nApri Nesto sul ristorante desiderato e copia l'indirizzo della pagina Recorded Assignments.",
        'Configura ristorante Nesto',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    exit 2
}

[System.IO.File]::WriteAllText($configFile, $url, [System.Text.UTF8Encoding]::new($false))
[System.Windows.Forms.MessageBox]::Show(
    "Ristorante Nesto aggiornato correttamente:`r`n`r`n$url",
    'Configura ristorante Nesto',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
) | Out-Null
