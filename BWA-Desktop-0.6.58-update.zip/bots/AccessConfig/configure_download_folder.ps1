﻿param([string]$Language='it')
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
. (Join-Path $PSScriptRoot 'DownloadFolder.ps1')
$texts=@{
 it=@('Cartella download Lightspeed','Scegli la cartella dove salvare i report. Vuota = gestione automatica.','Sfoglia...','Automatico','Salva','Cartella non disponibile.','Impostazione salvata.');
 en=@('Lightspeed download folder','Choose where to save reports. Empty = automatic management.','Browse...','Automatic','Save','Folder unavailable.','Setting saved.');
 fr=@('Dossier de téléchargement Lightspeed','Choisissez où enregistrer les rapports. Vide = gestion automatique.','Parcourir...','Automatique','Enregistrer','Dossier indisponible.','Paramètre enregistré.');
 de=@('Lightspeed Downloadordner','Ordner zum Speichern der Berichte wählen. Leer = automatisch.','Durchsuchen...','Automatisch','Speichern','Ordner nicht verfügbar.','Einstellung gespeichert.')
}
if(-not $texts.ContainsKey($Language)){$Language='it'}
$t=$texts[$Language]
$root=Join-Path $(if($env:BWA_BOT_ROOT){$env:BWA_BOT_ROOT}else{$env:LOCALAPPDATA}) 'BWA-LightspeedBot'
$settingsPath=Join-Path $root 'settings.json'
$settings=if(Test-Path -LiteralPath $settingsPath){Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json}else{[pscustomobject]@{}}
$dialog=New-Object Windows.Forms.Form
$dialog.Text=$t[0];$dialog.ClientSize=New-Object Drawing.Size(710,210);$dialog.StartPosition='CenterScreen';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false
$label=New-Object Windows.Forms.Label;$label.Text=$t[1];$label.SetBounds(20,20,670,42);$dialog.Controls.Add($label)
$path=New-Object Windows.Forms.TextBox;$path.SetBounds(20,70,670,25);$path.Text=[string]$settings.download_dir;$dialog.Controls.Add($path)
$browse=New-Object Windows.Forms.Button;$browse.Text=$t[2];$browse.SetBounds(20,115,150,36);$dialog.Controls.Add($browse)
$auto=New-Object Windows.Forms.Button;$auto.Text=$t[3];$auto.SetBounds(180,115,150,36);$dialog.Controls.Add($auto)
$save=New-Object Windows.Forms.Button;$save.Text=$t[4];$save.SetBounds(540,115,150,36);$dialog.Controls.Add($save)
$browse.Add_Click({$picker=New-Object Windows.Forms.FolderBrowserDialog;try{$picker.Description=$t[0];$picker.SelectedPath=if($path.Text){$path.Text}else{Get-BwaWindowsDownloads};if($picker.ShowDialog($dialog) -eq 'OK'){$path.Text=$picker.SelectedPath}}finally{$picker.Dispose()}})
$auto.Add_Click({$path.Clear()})
$save.Add_Click({try{
 $chosen=$path.Text.Trim()
 if($chosen){$chosen=Resolve-BwaDownloadFolder -Configured $chosen;if(-not [IO.Directory]::Exists($chosen)){throw $t[5]};$probe=Join-Path $chosen ('bwa-write-check-'+[Guid]::NewGuid().ToString('N')+'.tmp');try{[IO.File]::WriteAllText($probe,'')}finally{if(Test-Path -LiteralPath $probe){[IO.File]::Delete($probe)}}}
 # Re-read on save so credentials and any concurrent settings are preserved.
 $current=if(Test-Path -LiteralPath $settingsPath){Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json}else{[pscustomobject]@{}}
 $current | Add-Member -NotePropertyName download_dir -NotePropertyValue $chosen -Force
 [IO.Directory]::CreateDirectory($root) | Out-Null
 $temporary=$settingsPath+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
 [IO.File]::WriteAllText($temporary,($current|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
 if(Test-Path -LiteralPath $settingsPath){[IO.File]::Replace($temporary,$settingsPath,$null)}else{[IO.File]::Move($temporary,$settingsPath)}
 [Windows.Forms.MessageBox]::Show($t[6],$t[0]) | Out-Null;$dialog.Close()
}catch{[Windows.Forms.MessageBox]::Show($_.Exception.Message,$t[0]) | Out-Null}})
try{[void]$dialog.ShowDialog()}finally{$dialog.Dispose()}
