"""Local staging only: no writes to Outlook, BWA, or online services."""
from pathlib import Path
import hashlib,json,re,sqlite3,subprocess,unicodedata
from decimal import Decimal
from parse_gvs_text import parse as gvs
from parse_munhowen_text import parse as munhowen

ROOT=Path(__file__).resolve().parent

def identity(value):
    return re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD',value).encode('ascii','ignore').decode().lower())

def outlook(stores=False,store='',days=30):
    args=[str(ROOT/'OutlookReader.exe')]
    args+=['--list'] if stores else [store,str(days)]
    try:
        result=subprocess.run(args,capture_output=True,timeout=180,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    except subprocess.TimeoutExpired:
        raise RuntimeError('Outlook non risponde. Controlla eventuali richieste di accesso e riprova.')
    if result.returncode:
        raise RuntimeError(result.stderr.decode('utf-8',errors='replace').strip() or 'Lettura Outlook non riuscita')
    return json.loads(result.stdout.decode('utf-8-sig'))

class Archive:
    def __init__(self,folder):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(self.folder/'orders.sqlite',timeout=20)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS orders(restaurant TEXT,supplier TEXT,number TEXT,fingerprint TEXT,payload TEXT,
          PRIMARY KEY(restaurant,supplier,number));
        CREATE TABLE IF NOT EXISTS receipts(message TEXT,restaurant TEXT,digest TEXT,status TEXT,details TEXT,
          PRIMARY KEY(message,restaurant));
        ''')
    def close(self):self.db.close()
    def import_message(self,message,restaurant):
        key=identity(restaurant)
        if len(key)<3:raise ValueError('Inserisci il nome del ristorante')
        body=message.get('body','');digest=hashlib.sha256(body.encode()).hexdigest()
        message_id=message.get('id') or digest
        # An unread flag is deliberately not part of the import key.
        def save(status,details):
            self.db.execute('INSERT OR REPLACE INTO receipts VALUES(?,?,?,?,?)',(message_id,key,digest,status,details));self.db.commit()
            return dict(status=status,details=details)
        try:
            if re.search(r'gvsgroup\.de|GVS.Group',body,re.I):data=gvs(body)
            elif re.search(r'munhowen',body,re.I):data=munhowen(body)
            else:return dict(status='ignored',details='Email estranea ai fornitori')
            if identity(data['restaurant'])!=key:return save('other_restaurant','Ordine di '+data['restaurant'])
            # Preserve both amount bases; never infer VAT from an order without tax rates.
            if data['supplier']=='GVS':
                data['amount']=data['included_total'];data['amount_basis']='Totale ordine senza Vides'
                data['excluded']=data['excluded_vides']
            else:
                data['amount']=data['net_total'];data['amount_basis']='Merce HTVA, senza cauzioni'
                data['excluded']=data['excluded_deposit']
            fingerprint=hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            with self.db:
                old=self.db.execute('SELECT fingerprint FROM orders WHERE restaurant=? AND supplier=? AND number=?',(key,data['supplier'],data['number'])).fetchone()
                if old:
                    status='duplicate' if old[0]==fingerprint else 'conflict'
                else:
                    self.db.execute('INSERT INTO orders VALUES(?,?,?,?,?)',(key,data['supplier'],data['number'],fingerprint,json.dumps(data,ensure_ascii=False)))
                    status='imported'
            return save(status,data['supplier']+' '+data['number']+(' - contenuto modificato: revisione richiesta' if status=='conflict' else ''))
        except (ValueError,KeyError,TypeError,ArithmeticError) as error:
            return save('review',str(error))
    def orders(self,restaurant):
        return [json.loads(row[0]) for row in self.db.execute('SELECT payload FROM orders WHERE restaurant=? ORDER BY supplier,number',(identity(restaurant),))]
    def problems(self,restaurant):
        return [row[0] for row in self.db.execute("SELECT details FROM receipts WHERE restaurant=? AND status IN ('review','conflict')",(identity(restaurant),))]

def supplier_of(message):
    body=message.get('body','');subject=message.get('subject','')
    if re.search(r'gvsgroup\.de|GVS.Group',body,re.I) and re.search(r'(?:commande|order|bestellung)[^#\n]{0,35}#\s*[\w-]+',subject+'\n'+body,re.I):return 'GVS'
    if re.search(r'munhowen',body,re.I) and re.search(r'WEB-\d+',body) and re.search(r'confirmation de commande',body,re.I):return 'Munhowen'
    return None

def unique_messages(messages):
    seen=set();unique=[];hidden=0
    for message in messages:
        supplier=supplier_of(message)
        if not supplier:continue
        try:
            order=(gvs if supplier=='GVS' else munhowen)(message['body'])
            order['restaurant']=identity(order['restaurant'])
            signature=json.dumps(order,sort_keys=True,ensure_ascii=False)
        except (ValueError,KeyError,TypeError,ArithmeticError):
            # Unsupported formats are retained unless their complete body is identical.
            # Never discard a revised order merely because the order number is equal.
            signature=message.get('body','')
        key=(supplier,hashlib.sha256(signature.encode()).hexdigest())
        if key in seen:hidden+=1;continue
        seen.add(key);unique.append(dict(message,supplier=supplier))
    return unique,hidden

def discover(store='',days=30):
    reply=outlook(store=store,days=days)
    reply['messages'],reply['duplicates_hidden']=unique_messages(reply['messages'])
    return reply

def import_messages(folder,restaurant,messages,errors=None):
    archive=Archive(folder)
    try:
        result=[]
        from order_issues import describe
        for m in messages:
            if not supplier_of(m):continue
            row=dict(archive.import_message(m,restaurant),id=m.get('id',''),subject=m.get('subject',''))
            if row['status'] in ('review','conflict'):row['issue']=describe(m,'conflict' if row['status']=='conflict' else row['details'])
            result.append(row)
        return dict(results=result,errors=errors or [],orders=archive.orders(restaurant),problems=archive.problems(restaurant))
    finally:archive.close()

def scan(folder,restaurant,store='',days=30):
    reply=discover(store,days)
    return import_messages(folder,restaurant,reply['messages'],reply['errors'])
