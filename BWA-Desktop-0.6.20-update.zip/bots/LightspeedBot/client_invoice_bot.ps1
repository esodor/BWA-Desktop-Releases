﻿param(
 [Parameter(Mandatory=$true)][string]$Date,
 [Parameter(Mandatory=$true)][string]$Output,
 [Parameter(Mandatory=$true)][string]$DownloadFolderOverride
)
$ErrorActionPreference='Stop'
$result=[ordered]@{ok=$false;error='';date=$Date;restaurant='';restaurantPrefix='';invoices=@();sources=@()}
$destination=[IO.Path]::GetFullPath($Output)
$runFolder=[IO.Path]::GetFullPath($DownloadFolderOverride)
$socket=$null
function Write-InvoiceResult {
 $temporary=$destination+'.tmp'
 [IO.File]::WriteAllText($temporary,($result|ConvertTo-Json -Depth 30),[Text.UTF8Encoding]::new($false))
 Move-Item -LiteralPath $temporary -Destination $destination -Force
}
try {
 $day=[DateTime]::ParseExact($Date,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
 if($day.ToString('yyyy-MM-dd') -ne $Date){throw 'Data non valida'}
 New-Item -ItemType Directory -Path $runFolder -Force | Out-Null
 New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
 . (Join-Path $PSScriptRoot 'lightspeed_bot.ps1') -Url 'https://manager.lsk.lightspeed.app/receipt/index?lang=fr_FR' -DownloadFolderOverride $runFolder -LibraryOnly
 Add-Log "Fatture automatiche: $Date"
 Start-DedicatedEdge
 Connect-Cdp
 Invoke-Cdp -Method 'Page.enable' | Out-Null
 Invoke-Cdp -Method 'Runtime.enable' | Out-Null
 Navigate-Requested | Out-Null
 $credential=Get-StoredCredential
 $deadline=(Get-Date).AddSeconds($LoginTimeoutSeconds)
 $nextLogin=Get-Date '2000-01-01';$attempts=0;$redirectAt=Get-Date '2000-01-01';$ready=$false
 while((Get-Date) -lt $deadline){
  Start-Sleep -Milliseconds 350
  if(Test-LoginPageLikely){
   if($AutoLoginEnabled -and $credential -and $attempts -lt 5 -and (Get-Date) -ge $nextLogin){if(Try-AutoLogin $credential){$attempts++;$nextLogin=(Get-Date).AddSeconds(3)}}
   continue
  }
  $state=Invoke-JavaScript "JSON.stringify({url:location.href,ready:!!document.querySelector('#receiptsForm #dbtable'),title:document.title})" | ConvertFrom-Json
  if($state.ready){$ready=$true;break}
  if($state.url -match '^https://(manager|pos-admin)\.lsk\.lightspeed\.app/' -and $state.url -notmatch '/receipt/index' -and (Get-Date) -ge $redirectAt){Navigate-Requested | Out-Null;$redirectAt=(Get-Date).AddSeconds(4)}
  if($state.url -match '/receipt/index' -and $state.title -match 'erreur|error|Fehler'){throw 'Lightspeed ha restituito un errore aprendo i ticket. Riprova dopo il login.'}
 }
 if(-not $ready){throw 'Impossibile aprire i ticket Lightspeed. Verifica gli accessi Lightspeed in Admin.'}
 $reader=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'client_invoice_reader.js') -Raw -Encoding UTF8
 Invoke-JavaScript $reader | Out-Null
 $dateJson=$Date | ConvertTo-Json -Compress
 $allRows=New-Object System.Collections.Generic.List[object]
 $start=0;$expected=0
 do {
  $listJs=@"
(async()=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),16000);try{const data=new URLSearchParams({sEcho:'1',iDisplayStart:'$start',iDisplayLength:'100',sSearch:'Facture',iColumns:'13'});const response=await fetch('/receipt/accounts/day/'+$dateJson+'/'+$dateJson+'?fiscal=true',{method:'POST',body:data,signal:controller.signal});if(!response.ok)throw new Error('Elenco ticket HTTP '+response.status);return JSON.stringify(await response.json());}finally{clearTimeout(timer);}})()
"@
  $page=Invoke-JavaScript $listJs | ConvertFrom-Json
  if($null -eq $page.data -or $null -eq $page.data.aaData -or $null -eq $page.iTotalDisplayRecords){throw 'Elenco ticket Lightspeed non riconosciuto'}
  $expected=[int]$page.iTotalDisplayRecords
  if($expected -gt 500){throw 'Troppi ticket Facture in una singola giornata: verifica il filtro data'}
  $rows=@($page.data.aaData)
  foreach($row in $rows){$allRows.Add($row)}
  if($rows.Count -eq 0 -and $start -lt $expected){throw 'Elenco ticket incompleto'}
  $start+=$rows.Count
 }while($start -lt $expected)
 $listPath=Join-Path $runFolder ('Elenco Facture '+$day.ToString('dd.MM.yyyy')+'.json')
 [IO.File]::WriteAllText($listPath,(@{date=$Date;rows=@($allRows.ToArray())}|ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
 $result.sources=@($listPath)
 $restaurantJs=@'
(()=>{for(const script of document.scripts){const match=(script.textContent||'').match(/"location_name"\s*:\s*("(?:[^"\\]|\\.)*")/);if(match)return JSON.parse(match[1]);}throw new Error('Nome del ristorante Lightspeed non verificabile');})()
'@
 $result.restaurant=[string](Invoke-JavaScript $restaurantJs)
 $seen=New-Object 'System.Collections.Generic.HashSet[string]'
 foreach($row in $allRows){
  if($row.Count -lt 13){throw 'Struttura elenco ticket non riconosciuta'}
  if(([string]$row[12]) -match 'cancelled|training|inactive|correction'){continue}
  if(-not (@($row[6]) | Where-Object {([string]$_).Trim() -eq 'Facture'})){continue}
  $account=[string]$row[0];$ticket=[string]$row[11]
  if($account -notmatch '^A[0-9]+\.[0-9]+$' -or $ticket -notmatch '^R[0-9]+\.[0-9]+$'){throw 'Identificativo ticket Lightspeed non riconosciuto'}
  if(-not $seen.Add($ticket)){throw 'Ticket duplicato nel riepilogo Lightspeed'}
  $request=@{date=$Date;ticket=$ticket;account=$account;total=[string]$row[4]}|ConvertTo-Json -Compress
  $detailJs=@"
(async()=>{const expected=$request,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),16000);try{const response=await fetch('/receipt/loadReceipt?id='+encodeURIComponent(expected.account),{signal:controller.signal});if(!response.ok)throw new Error('Ticket HTTP '+response.status);const doc=new DOMParser().parseFromString(await response.text(),'text/html');const previews=[...doc.querySelectorAll('pre.receipt-preview')].map(x=>x.textContent).filter(x=>x.includes(expected.ticket));if(previews.length!==1)throw new Error('Anteprima fiscale univoca non disponibile per '+expected.ticket);const text=previews[0];const invoice=BwaInvoiceReader.parseReceipt(text,expected);const link=doc.querySelector('a[href^="/receipt/receiptToPdf?"]');if(!link)throw new Error('PDF originale del ticket non disponibile');const url=new URL(link.getAttribute('href'),location.origin);if(url.origin!==location.origin||url.pathname!=='/receipt/receiptToPdf'||url.searchParams.get('id')!==expected.account)throw new Error('Collegamento PDF non corrispondente');return JSON.stringify({invoice:invoice,text:text,pdfUrl:url.href});}finally{clearTimeout(timer);}})()
"@
  $detail=Invoke-JavaScript $detailJs | ConvertFrom-Json
  $pdfUrlJson=[string]$detail.pdfUrl|ConvertTo-Json -Compress
  $pdfJs=@"
(async()=>{const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),16000);try{const r=await fetch($pdfUrlJson,{signal:controller.signal});if(!r.ok)throw new Error('PDF ticket HTTP '+r.status);const a=new Uint8Array(await r.arrayBuffer());if(a.length<100||a.length>15000000||String.fromCharCode(...a.slice(0,5))!=='%PDF-')throw new Error('Il ticket scaricato non e un PDF valido');let s='';for(let i=0;i<a.length;i+=32768)s+=String.fromCharCode(...a.subarray(i,i+32768));return btoa(s);}finally{clearTimeout(timer);}})()
"@
  $pdfBase64=[string](Invoke-JavaScript $pdfJs)
  $base='Ticket '+$ticket+' '+$day.ToString('dd.MM.yyyy')
  $pdfPath=Join-Path $runFolder ($base+'.pdf');$textPath=Join-Path $runFolder ($base+'.txt')
  [IO.File]::WriteAllBytes($pdfPath,[Convert]::FromBase64String($pdfBase64))
  [IO.File]::WriteAllText($textPath,[string]$detail.text,[Text.UTF8Encoding]::new($false))
  $invoice=$detail.invoice
  $invoice|Add-Member -NotePropertyName ReceiptPath -NotePropertyValue $pdfPath
  $invoice|Add-Member -NotePropertyName ReceiptTextPath -NotePropertyValue $textPath
  $result.invoices+=@($invoice);$result.sources+=@($pdfPath,$textPath)
  Add-Log "Ticket $ticket verificato e archiviato; pagamento Facture $($invoice.PaymentAmount)."
 }
 $result.ok=$true
 Write-InvoiceResult
 Add-Log "Fatture automatiche completate: $($result.invoices.Count)"
 exit 0
}catch{
 $result.error=$_.Exception.Message
 try{if($LogFile){Add-Log ('ERRORE fatture automatiche: '+$result.error)}}catch{}
 try{Write-InvoiceResult}catch{}
 Write-Error $result.error -ErrorAction Continue
 exit 1
}finally{try{if($script:WebSocket){$script:WebSocket.Dispose()}}catch{}}
