@echo off
setlocal
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=%SystemRoot%\SysNative\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
  echo Windows PowerShell non trovato.
  exit /b 53
)
"%PS%" -NoLogo -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0bomito_bot.ps1" %*
exit /b %errorlevel%
