import json

CURRENT=None

def configure(data):
    global CURRENT
    CURRENT=data

def load(labels):
    data=CURRENT
    if data is None:return {}
    if data.get('schema')!=1 or not isinstance(data.get('products'),list):
        raise ValueError('Catalogo categorie condiviso non valido')
    result={}
    for row in data['products']:
        supplier=row.get('supplier');code=row.get('code');category=row.get('category')
        if supplier not in ('GVS','Munhowen') or not isinstance(code,str) or not code.strip() or category not in labels:
            raise ValueError('Articolo del catalogo condiviso non valido')
        if (supplier,code) in result:
            raise ValueError('Articolo duplicato nel catalogo condiviso')
        result[supplier,code]=dict(code=code,name=row.get('name') or code,category=category)
    return result
