// Retry only Nesto's explicit failed-session page. Never retry a rejected password or MFA.
(() => {
  if (location.protocol !== 'https:' || !['nesto.app', 'account.nesto.app'].includes(location.hostname) || location.port) return 'manual-origin';
  const normalize = value => (value || '').replace(/\s+/g, ' ').trim();
  const text = normalize(document.body && document.body.innerText);
  if (/Falscher Benutzername oder falsches Passwort|incorrect (username|user name) or password|invalid (username|user name) or password|identifiant ou mot de passe incorrect|nome utente o password (non validi|errati)/i.test(text)) return 'invalid-credentials';
  if (!/Anmeldung fehlgeschlagen|Die Anmeldung ist fehlgeschlagen|login failed|sign.in failed|authentication failed|échec de (la )?connexion|accesso (non riuscito|fallito)/i.test(text)) return 'not-found';
  if (document.querySelector('input[type=password],input[autocomplete=one-time-code],input[autocomplete=new-password]')) return 'manual-form';
  const visible = e => { const r=e.getBoundingClientRect(),s=getComputedStyle(e); return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden' && !e.disabled; };
  const allowed = /^(zum login|zur anmeldung|back to (log ?in|sign ?in)|return to (log ?in|sign ?in)|retour à la connexion|torna (al login|all.accesso))$/i;
  const candidates = [...document.querySelectorAll('button,a,input[type=submit]')].filter(visible).filter(e=>allowed.test(normalize(e.innerText || e.value)));
  if (candidates.length!==1) return 'failed-session-manual';
  const target = candidates[0];
  for (const url of [target.tagName==='A' && target.href, target.form && target.form.action].filter(Boolean)) {
    const destination = new URL(url, location.href);
    if (destination.protocol!=='https:' || !['nesto.app','account.nesto.app'].includes(destination.hostname) || destination.port) return 'manual-origin';
  }
  if (!__ALLOW_CLICK__) return 'failed-session';
  target.click();
  return 'clicked';
})()
