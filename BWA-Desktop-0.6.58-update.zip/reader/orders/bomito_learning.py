"""Learn only unassigned products from accepted, reconciled Bomito article rows."""
from collections import defaultdict
from datetime import datetime
from decimal import Decimal
import re
from orders import identity

ACCOUNTS={'60610010':'beverages','60330010':'paper','60330060':'op','60330030':'tableware','60330020':'tableware','60330040':'tableware','60320000':'cleaning','60330050':'marketing'}
def restaurant_key(value):
    key=identity(value)
    return key[8:] if key.startswith('losteria') else key
def supplier_key(value):
    key=identity(value)
    if key=='gvs' or key.startswith('gvsgroup'):return 'GVS'
    if key.startswith('munhowen'):return 'Munhowen'
    return None
def learn(db,restaurant,period,rows):
    datetime.strptime(period+'-01','%Y-%m-%d')
    db.execute('CREATE TABLE IF NOT EXISTS bomito_article_evidence(restaurant TEXT,supplier TEXT,code TEXT,category TEXT,document TEXT,date TEXT,name TEXT,account TEXT,PRIMARY KEY(restaurant,supplier,code,category,document,date))')
    candidates=set();ignored=0;key=identity(restaurant)
    with db:
        for r in rows:
            if restaurant_key(r.get('restaurant',''))!=restaurant_key(restaurant):ignored+=1;continue
            supplier=supplier_key(r.get('supplier',''));code=str(r.get('code','')).strip()
            date=r.get('date','');document=r.get('document','')
            try:datetime.strptime(date,'%Y-%m-%d')
            except (ValueError,TypeError):ignored+=1;continue
            if not supplier or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._/-]{1,39}',code) or not date.startswith(period+'-') or not document:ignored+=1;continue
            account=r.get('account');category=ACCOUNTS.get(account)
            if account=='60610020':
                # Match the existing BWA Food / GVS Frische invoice rule.
                category='food' if abs(Decimal(str(r['invoice_amount'])))>450 else 'vegetables'
            if not category:ignored+=1;continue
            db.execute('INSERT OR REPLACE INTO bomito_article_evidence VALUES(?,?,?,?,?,?,?,?)',(key,supplier,code,category,document,date,str(r.get('name',''))[:300],account))
            candidates.add((supplier,code))
        learned=0;conflicts=0;preserved=0
        for supplier,code in sorted(candidates):
            args=(key,supplier,code)
            if db.execute('SELECT 1 FROM categories WHERE restaurant=? AND supplier=? AND code=?',args).fetchone():preserved+=1;continue
            if db.execute('SELECT 1 FROM reviewed_categories WHERE restaurant=? AND supplier=? AND code=?',args).fetchone():preserved+=1;continue
            evidence=list(db.execute('SELECT DISTINCT category FROM bomito_article_evidence WHERE restaurant=? AND supplier=? AND code=?',args))
            if len(evidence)!=1:conflicts+=1;continue
            db.execute('INSERT INTO reviewed_categories VALUES(?,?,?,?,?,?)',(*args,evidence[0][0],'bomito_verified','Categoria appresa da fattura Bomito: '+period))
            learned+=1
    return dict(learned=learned,conflicts=conflicts,preserved=preserved,ignored=ignored)
