"""Tickets aggregation using the original BWA email macro's time boundaries."""
import sys,json,pathlib,datetime as dt,re,hashlib,unicodedata
from decimal import Decimal
import xlrd
def norm(v):
 return ''.join(c for c in unicodedata.normalize('NFKD',str(v)).lower() if not unicodedata.combining(c)).strip()
def read(path,date):
 day=dt.date.fromisoformat(date);p=pathlib.Path(path)
 expected='_tickets_'+day.strftime('%Y%m%d')+'_'+(day+dt.timedelta(days=1)).strftime('%Y%m%d')
 if expected not in p.stem:raise ValueError('Tickets: data del file diversa dalla chiusura')
 w=xlrd.open_workbook(str(p));s=w.sheet_by_index(0);header=None
 for r in range(min(20,s.nrows)):
  cols={norm(v):i for i,v in enumerate(s.row_values(r))}
  if all(k in cols for k in ('date','paye','profil')):header=r;break
 if header is None:raise ValueError('Tickets: colonne Date, Paye e Profil mancanti')
 totals=[Decimal(0)]*4;count=0
 for r in range(header+1,s.nrows):
  row=s.row_values(r)
  if not any(str(v).strip() for v in row):continue
  if 'annulee' in cols and norm(row[cols['annulee']]) in ('oui','yes','ja'):continue
  raw=row[cols['date']]
  if isinstance(raw,(int,float)):stamp=xlrd.xldate_as_datetime(raw,w.datemode)
  else:
   stamp=None
   for fmt in ('%d/%m/%y %H:%M','%d/%m/%Y %H:%M','%d/%m/%Y %H:%M:%S','%d/%m/%y %H:%M:%S','%Y-%m-%d %H:%M:%S'):
    try:stamp=dt.datetime.strptime(str(raw).strip(),fmt);break
    except ValueError:pass
   if stamp is None:raise ValueError('Tickets: data non leggibile alla riga '+str(r+1))
  # A business day can include after-midnight receipts, outside the original time bands.
  if stamp.date() not in (day,day+dt.timedelta(days=1)):raise ValueError('Tickets: ricevuta fuori giornata')
  value=str(row[cols['paye']]).strip().replace('\u00a0','').replace(' ','')
  if ',' in value:value=value.replace('.','').replace(',','.')
  paid=Decimal(value);t=stamp.time();count+=1
  for i,(start,end) in enumerate(((dt.time(10),dt.time(15)),(dt.time(15,1),dt.time(18)),(dt.time(18,1),dt.time(23)))):
   if start<=t<=end:totals[i]+=paid;break
  profile=norm(row[cols['profil']])
  if 'viavia' in profile or 'via via' in profile:totals[3]+=paid
 if count==0:raise ValueError('Tickets: nessuna ricevuta valida')
 return dict(Date=date,Sales10=float(totals[0]),Sales15=float(totals[1]),Sales18=float(totals[2]),ViaVia=float(totals[3]),SourceName=p.name,SourceHash=hashlib.sha256(p.read_bytes()).hexdigest(),Count=count)
if __name__=='__main__':
 try:result={'ok':True,'details':read(sys.argv[1],sys.argv[2])}
 except Exception as e:result={'ok':False,'error':str(e)}
 pathlib.Path(sys.argv[3]).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
 if not result['ok']:sys.exit(1)
