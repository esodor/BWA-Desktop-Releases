﻿$ErrorActionPreference='Stop'
$ollamaExe=Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
if(-not(Test-Path -LiteralPath $ollamaExe)){
 Write-Host 'Download di Ollama dal sito ufficiale. Servono alcuni GB liberi e Internet solo per la configurazione.'
 $setupFile=Join-Path $env:TEMP ('BWA-Ollama-'+[Guid]::NewGuid().ToString('N')+'.exe')
 Invoke-WebRequest -UseBasicParsing -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile $setupFile
 $signature=Get-AuthenticodeSignature -LiteralPath $setupFile
 if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Ollama Inc\.') {throw 'Firma installer non valida. Installazione interrotta.'}
 Start-Process -FilePath $setupFile -Wait
}
if(-not(Test-Path -LiteralPath $ollamaExe)){throw 'Ollama non installato. Riprova dopo aver completato la sua installazione.'}
& $ollamaExe pull qwen2.5:7b
if($LASTEXITCODE -ne 0){throw 'Modello non scaricato. Controlla la connessione e riprova.'}
Write-Host 'Mini Matteo locale pronto. Torna al programma e scrivigli una domanda.'
Read-Host 'Premi Invio per chiudere'