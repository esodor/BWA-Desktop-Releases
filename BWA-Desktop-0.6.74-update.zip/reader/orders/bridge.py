import sys,json
from datetime import date,timedelta,datetime
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from orders import Archive,identity,outlook,discover,import_messages
from categories import Categories,LABELS

def delivery_iso(value):
    for fmt in ('%Y-%m-%d','%d.%m.%Y','%d/%m/%Y'):
        try:return datetime.strptime(value,fmt).date().isoformat()
        except ValueError:pass
    raise ValueError('Data di consegna non valida: '+str(value))

def execute(q):
    from shared_catalog import configure
    configure(q.get("shared_catalog"))
    folder=Path(q['folder']);restaurant=q['restaurant'];op=q['op']
    folder.mkdir(parents=True,exist_ok=True)
    settings=folder/'settings.json'
    cfg=json.loads(settings.read_text(encoding='utf-8')) if settings.exists() else {}
    cfg.setdefault('background',True)
    cfg['auto']=cfg['background']
    if op=='settings':return cfg
    if op=='configure':
        cfg.update(store=q.get('store',''),auto=q.get('auto',False),background=q.get('auto',False),restaurant=restaurant)
        tmp=settings.with_suffix('.tmp');tmp.write_text(json.dumps(cfg),encoding='utf-8');tmp.replace(settings);return cfg
    restaurant=cfg.get('restaurant') or restaurant
    if op=='stores':return outlook(stores=True)
    if op=='scan':
        period=q.get('period')
        first=date.fromisoformat(period+'-01') if period else date.today().replace(day=1)
        days=max(1,(date.today()-(first-timedelta(days=31))).days+1)
        reply=discover(cfg.get('store',''),days=days)
        messages=[]
        from orders import supplier_of,gvs,munhowen
        for message in reply['messages']:
            try:
                supplier=supplier_of(message)
                parsed=(gvs if supplier=='GVS' else munhowen)(message['body'])
                if delivery_iso(parsed['delivery_date'])[:7]==first.strftime('%Y-%m'):messages.append(message)
            except (ValueError,KeyError,TypeError,ArithmeticError) as error:
                from order_issues import describe
                issue=describe(message,error)
                if issue['date'] and not issue['date'].startswith(first.strftime('%Y-%m')):continue
                reply['errors'].append(issue)
        result=import_messages(folder,restaurant,messages,reply['errors'])
        from order_issues import save
        result['issues']=save(folder,first.strftime('%Y-%m'),result['errors'],result['results'])
        result['duplicates_hidden']=reply.get('duplicates_hidden',0);return result
    a=Archive(folder)
    try:
        c=Categories(a)
        if op=='learn_bomito':
            from bomito_learning import learn
            return learn(a.db,restaurant,q['period'],q['articles'])
        orders=a.orders(restaurant)
        for order in orders:order['delivery_date']=delivery_iso(order['delivery_date'])
        if op=='list':
            for o in orders:o['summary']=c.summary(o)
            return dict(orders=orders,problems=a.problems(restaurant))
        if op=='confirm':
            c.confirm(restaurant,q['supplier'],q['codes'],q['category']);return dict(ok=True)
        if op=='mapping':
            products={('GVS',code):dict(code=code,name=r['name'],total='0') for code,r in c.candidates.items()}
            for key,row in c.shared.items():products[key]=dict(code=row['code'],name=row['name'],total='0')
            seen=set()
            for o in orders:
                for item in o['items']:
                    products[o['supplier'],item['code']]=item
                    seen.add((o['supplier'],item['code']))
            result=[]
            for (supplier,code),item in sorted(products.items()):
                row=c.lines(dict(restaurant=restaurant,supplier=supplier,items=[item]))[0]
                row['supplier']=supplier;row['seen']=(supplier,code) in seen;result.append(row)
            return dict(products=result)
        if op=='details':
            o=next(o for o in orders if o['supplier']==q['supplier'] and o['number']==q['number'])
            return dict(items=c.lines(o),summary=c.summary(o),basis=o['amount_basis'])
        raise ValueError('Operazione ordini non valida')
    finally:a.close()

if __name__=='__main__':
    try:print(json.dumps(dict(ok=True,data=execute(json.loads(sys.stdin.read()))),ensure_ascii=True,default=str))
    except Exception as e:print(json.dumps(dict(ok=False,error=str(e)),ensure_ascii=True));sys.exit(1)
