﻿param(
    [Parameter(Mandatory = $true)]
    [string]$Url,
    [string]$DownloadFolderOverride,
    [string]$ExpectedPattern,
    [switch]$VisibleBrowser,
    [switch]$LibraryOnly
)

$ErrorActionPreference = 'Stop'

# BWA LightspeedBot FIX v1.1 - 2026-08-12

$AppName = 'BWA-LightspeedBot'
$AppDir = Join-Path $env:LOCALAPPDATA $AppName
$ProfileDir = Join-Path $AppDir 'edge-profile'
$LogDir = Join-Path $AppDir 'logs'
$CredentialsFile = Join-Path $AppDir 'credentials.dat'
$SettingsFile = Join-Path $AppDir 'settings.json'
$DefaultLoginUrl = 'https://manager.lsk.lightspeed.app/'
$LoginUrl = $DefaultLoginUrl
$AutoLoginEnabled = $true
$DownloadDir = Join-Path $env:USERPROFILE 'Downloads'
$Port = 9342
$LoginTimeoutSeconds = 180

New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
New-Item -ItemType Directory -Path $DownloadDir -Force | Out-Null

if (Test-Path -LiteralPath $SettingsFile) {
    try {
        $settings = Get-Content -LiteralPath $SettingsFile -Raw -ErrorAction Stop | ConvertFrom-Json
        if ($settings.login_url) { $LoginUrl = [string]$settings.login_url }
        if ($null -ne $settings.auto_login) { $AutoLoginEnabled = [bool]$settings.auto_login }
        if ($settings.download_dir -and (Test-Path -LiteralPath ([string]$settings.download_dir) -PathType Container)) {
            $DownloadDir = [string]$settings.download_dir
        }
    } catch {}
}

$Url = $Url.Trim()
if ($Url -notmatch '^https://manager\.lsk\.lightspeed\.app/') {
    throw 'Il link richiesto non appartiene a Lightspeed Manager.'
}
if ($LoginUrl -notmatch '^https://manager\.lsk\.lightspeed\.app/') {
    $LoginUrl = $DefaultLoginUrl
}

if (-not $ExpectedPattern -and $Url -match '/day/(\d{4}-\d{2}-\d{2})/') {
    try {
        $reportDay = [DateTime]::ParseExact($Matches[1], 'yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
        $reportKind = $null
        $reportExtension = $null
        if ($Url -match '/businessReportPrint/') {
            $reportKind = 'business_report_day'
            $reportExtension = 'pdf'
        } elseif ($Url -match '/exportDiscountBreakdown/') {
            $reportKind = 'discounts'
            $reportExtension = 'xls'
        } elseif ($Url -match '/exportCancellations/') {
            $reportKind = 'cancellations'
            $reportExtension = 'xls'
        } elseif ($Url -match '/receipt/exportReceipts/') {
            $reportKind = 'tickets'
            $reportExtension = 'xls'
        }
        if ($reportKind) {
            $ExpectedPattern = '*_' + $reportKind + '_' + $reportDay.ToString('yyyyMMdd') + '_' + $reportDay.AddDays(1).ToString('yyyyMMdd') + '*.' + $reportExtension
        }
    } catch {}
}

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$LogFile = Join-Path $LogDir "lightspeed_${stamp}.log"
$script:WebSocket = $null
$script:CdpId = 0

function Add-Log {
    param([string]$Text)
    Add-Content -LiteralPath $LogFile -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Text) -Encoding UTF8
}

function Find-EdgeExecutable {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($registryPath in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe'
    )) {
        try {
            $value = (Get-ItemProperty -LiteralPath $registryPath -ErrorAction Stop).'(default)'
            if ($value) { $candidates.Add([string]$value) }
        } catch {}
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA, $env:ProgramW6432)) {
        if ($base) { $candidates.Add((Join-Path $base 'Microsoft\Edge\Application\msedge.exe')) }
    }
    try {
        $command = Get-Command msedge.exe -ErrorAction Stop
        if ($command.Source) { $candidates.Add([string]$command.Source) }
    } catch {}
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $candidate }
    }
    throw 'Microsoft Edge non trovato.'
}

function Test-DebugEndpoint {
    try {
        $null = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/version" -TimeoutSec 2
        return $true
    } catch { return $false }
}

function Start-DedicatedEdge {
    $edge = Find-EdgeExecutable
    if (-not (Test-DebugEndpoint)) {
        Add-Log "Avvio Edge dedicato Lightspeed: $edge"
        $arguments = @(
            "--remote-debugging-port=$Port",
            "--user-data-dir=`"$ProfileDir`"",
            '--no-first-run',
            '--no-default-browser-check',
            '--disable-pdf-extension',
            'about:blank'
        )
        $backgroundMode = (-not $VisibleBrowser -and $AutoLoginEnabled -and (Test-Path -LiteralPath $CredentialsFile))
        if ($backgroundMode) {
            $arguments = @('--headless=new','--disable-gpu','--window-size=1600,1000') + $arguments
            Add-Log 'Edge Lightspeed avviato in background.'
            $windowStyle = 'Hidden'
        } else { $arguments = @('--start-maximized') + $arguments; $windowStyle = 'Normal' }
        Start-Process -FilePath $edge -ArgumentList $arguments -WindowStyle $windowStyle | Out-Null
    }
    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if (Test-DebugEndpoint) { return }
        Start-Sleep -Milliseconds 350
    }
    throw 'Impossibile collegarsi a Microsoft Edge per Lightspeed.'
}

function Get-PageTarget {
    $targets = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/json/list" -TimeoutSec 5
    # Edge exposes its download hub as a page. Never navigate internal panels.
    $pages = @($targets | Where-Object { $_.type -eq 'page' -and $_.webSocketDebuggerUrl })
    $preferred = $pages | Where-Object { $_.url -match '^https://(manager|pos-admin)\.lsk\.lightspeed\.app/' } | Select-Object -First 1
    if ($null -eq $preferred) { $preferred = $pages | Where-Object { $_.url -eq 'about:blank' } | Select-Object -First 1 }
    if ($null -eq $preferred) {
        Add-Log 'Apro una scheda normale per Lightspeed; ignoro i pannelli interni Edge.'
        $preferred = Invoke-RestMethod -Method Put -Uri "http://127.0.0.1:$Port/json/new?about:blank" -TimeoutSec 5
    }
    if (-not $preferred.webSocketDebuggerUrl -or $preferred.url -match '^(edge|chrome|devtools|chrome-extension):') { throw 'Nessuna scheda Lightspeed utilizzabile.' }
    return $preferred
}
function Connect-Cdp {
    $target = Get-PageTarget

    $wsUrl = [string]$target.webSocketDebuggerUrl
    if ([string]::IsNullOrWhiteSpace($wsUrl)) {
        throw 'Lightspeed: URL WebSocket CDP non disponibile.'
    }

    Add-Log "CDP WebSocket: $wsUrl"

    try {
        [System.Uri]$uri = $wsUrl
    } catch {
        throw "Lightspeed: URL WebSocket CDP non valida: $wsUrl"
    }

    $script:WebSocket = New-Object System.Net.WebSockets.ClientWebSocket

    try {
        $null = $script:WebSocket.ConnectAsync(
            $uri,
            [Threading.CancellationToken]::None
        ).GetAwaiter().GetResult()
    } catch {
        throw "Lightspeed: impossibile collegarsi al WebSocket CDP. $($_.Exception.Message)"
    }

    Add-Log "CDP collegato a $($target.url)"
}

function Receive-WebSocketText {
    $buffer = New-Object byte[] 65536
    $stream = New-Object System.IO.MemoryStream
    do {
        $segment = [System.ArraySegment[byte]]::new($buffer)
        $result = $script:WebSocket.ReceiveAsync($segment,$script:CdpCancellation.Token).GetAwaiter().GetResult()
        if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { throw 'Connessione Edge chiusa.' }
        $stream.Write($buffer,0,$result.Count)
    } while (-not $result.EndOfMessage)
    $text = [System.Text.Encoding]::UTF8.GetString($stream.ToArray())
    $stream.Dispose()
    return $text
}

function Invoke-Cdp {
    param([Parameter(Mandatory=$true)][string]$Method,[hashtable]$Params=@{})
    $script:CdpCancellation = New-Object Threading.CancellationTokenSource
    $script:CdpCancellation.CancelAfter(20000)
    try {
    $script:CdpId++
    $id=$script:CdpId
    $request=@{id=$id;method=$Method;params=$Params}|ConvertTo-Json -Depth 20 -Compress
    $bytes=[System.Text.Encoding]::UTF8.GetBytes($request)
    $segment=[System.ArraySegment[byte]]::new($bytes)
    $null = $script:WebSocket.SendAsync($segment,[System.Net.WebSockets.WebSocketMessageType]::Text,$true,$script:CdpCancellation.Token).GetAwaiter().GetResult()
    while($true){
        $responseText=Receive-WebSocketText
        $response=$responseText|ConvertFrom-Json
        if($response.id -eq $id){
            if($response.error){throw "CDP $Method`: $($response.error.message)"}
            return $response
        }
    }
    } finally { $script:CdpCancellation.Dispose() }
}

function Invoke-JavaScript {
    param([Parameter(Mandatory=$true)][string]$Expression)
    $response=Invoke-Cdp -Method 'Runtime.evaluate' -Params @{expression=$Expression;returnByValue=$true;awaitPromise=$true}
    if($response.result.exceptionDetails){throw "Errore JavaScript: $($response.result.exceptionDetails.text)"}
    return $response.result.result.value
}

function Get-CurrentUrl { return [string](Invoke-JavaScript 'location.href') }

function Get-StoredCredential {
    if (-not (Test-Path -LiteralPath $CredentialsFile)) { return $null }
    try {
        $cred=Import-Clixml -LiteralPath $CredentialsFile -ErrorAction Stop
        if($cred -is [System.Management.Automation.PSCredential]){
            return [PSCustomObject]@{username=[string]$cred.UserName;password=[string]$cred.GetNetworkCredential().Password}
        }
    } catch {}
    try {
        Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
        $b64=(Get-Content -LiteralPath $CredentialsFile -Raw -ErrorAction Stop).Trim()
        $enc=[Convert]::FromBase64String($b64)
        $plain=[System.Security.Cryptography.ProtectedData]::Unprotect($enc,$null,[System.Security.Cryptography.DataProtectionScope]::CurrentUser)
        return ([System.Text.Encoding]::UTF8.GetString($plain)|ConvertFrom-Json)
    } catch { return $null }
}

function Test-LoginPageLikely {
    $js=@'
(() => {
  const visible=e=>{try{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&!e.disabled;}catch(err){return false;}};
  const inputs=[...document.querySelectorAll('input')].filter(visible);
  if(inputs.some(i=>(i.type||'').toLowerCase()==='password')) return true;
  const hasUser=inputs.some(i=>{const x=((i.type||'')+' '+(i.name||'')+' '+(i.id||'')+' '+(i.autocomplete||'')+' '+(i.placeholder||'')).toLowerCase();return (i.type||'').toLowerCase()==='email'||/user|email|e-mail|login|mail/.test(x);});
  if(!hasUser) return false;
  const text=((document.body&&document.body.innerText)||'').toLowerCase();
  return /login|log in|sign in|connexion|accedi|email|password|continue|weiter/.test(text);
})()
'@
    try{return [bool](Invoke-JavaScript $js)}catch{return $false}
}

function Try-AutoLogin {
    param($Credential)
    if($null -eq $Credential){return $false}
    $username=[string]$Credential.username
    $password=[string]$Credential.password
    if(-not $username -or -not $password){return $false}
    $userJson=$username|ConvertTo-Json -Compress
    $passJson=$password|ConvertTo-Json -Compress
    $js=@"
(async()=>{
 const username=$userJson,password=$passJson;
 const visible=e=>{try{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.display!=="none"&&s.visibility!=="hidden"&&!e.disabled;}catch(err){return false;}};
 const setValue=(el,val)=>{if(!el)return;try{const p=Object.getPrototypeOf(el),d=Object.getOwnPropertyDescriptor(p,'value')||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(el,val);else el.value=val;}catch(err){el.value=val;}for(const ev of ['input','change','keyup']){try{el.dispatchEvent(new Event(ev,{bubbles:true}));}catch(err){}}};
 const inputs=[...document.querySelectorAll('input')].filter(visible);
 const pw=inputs.find(i=>(i.type||'').toLowerCase()==='password');
 const users=inputs.filter(i=>{const x=((i.type||'')+' '+(i.name||'')+' '+(i.id||'')+' '+(i.autocomplete||'')+' '+(i.placeholder||'')).toLowerCase();if((i.type||'').toLowerCase()==='password')return false;return (i.type||'').toLowerCase()==='email'||/user|email|e-mail|login|mail/.test(x);});
 const user=users[0]||inputs.find(i=>['text','email'].includes((i.type||'text').toLowerCase()));
 const clickSubmit=root=>{const buttons=[...(root||document).querySelectorAll('button,input[type=submit],input[type=button],a')].filter(visible);const preferred=buttons.find(b=>/login|log in|sign in|connexion|accedi|continue|next|weiter/.test(((b.innerText||b.value||b.textContent||'')+'').trim().toLowerCase()));const btn=preferred||buttons.find(b=>(b.type||'').toLowerCase()==='submit');if(btn){btn.click();return true;}return false;};
 if(pw){
   if(user)setValue(user,username);setValue(pw,password);
   const form=pw.form||(user&&user.form);
   if(form){const submit=[...form.querySelectorAll('button,input[type=submit]')].find(visible);if(submit){submit.click();return 'password-submit';}try{if(form.requestSubmit){form.requestSubmit();return 'password-requestSubmit';}}catch(err){}try{form.submit();return 'password-form-submit';}catch(err){}}
   if(clickSubmit(document))return 'password-button';
   try{pw.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));pw.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));return 'password-enter';}catch(err){}
   return 'password-filled';
 }
 if(user){setValue(user,username);if(clickSubmit(user.form||document))return 'username-next';try{user.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));user.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));return 'username-enter';}catch(err){}}
 return 'not-found';
})()
"@
    try{
        $action=[string](Invoke-JavaScript $js)
        if($action -and $action -ne 'not-found'){Add-Log "Auto-login Lightspeed avviato ($action).";return $true}
    }catch{Add-Log "Auto-login Lightspeed non riuscito: $($_.Exception.Message)"}
    return $false
}

function Navigate-Requested {
    $r=Invoke-Cdp -Method 'Page.navigate' -Params @{url=$Url}
    if($r.result.errorText){Add-Log "Page.navigate: $($r.result.errorText)"}
    if($r.result.isDownload){Add-Log 'Lightspeed ha avviato direttamente un download.';return $true}
    return $false
}

function Wait-ExpectedDownload {
    param([int]$TimeoutSeconds = 20)
    if (-not $ExpectedPattern) { return $true }
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    $lastPath = $null
    $lastLength = -1L
    $stableChecks = 0
    while ((Get-Date) -lt $deadline) {
        $file = Get-ChildItem -LiteralPath $DownloadDir -Filter $ExpectedPattern -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Extension -ne '.crdownload' -and $_.Length -gt 0 } |
            Sort-Object LastWriteTimeUtc -Descending |
            Select-Object -First 1
        if ($file) {
            if ($file.FullName -eq $lastPath -and $file.Length -eq $lastLength) {
                $stableChecks++
                if ($stableChecks -ge 2) {
                    Add-Log "Download verificato: $($file.Name) ($($file.Length) byte)."
                    return $true
                }
            } else {
                $lastPath = $file.FullName
                $lastLength = $file.Length
                $stableChecks = 0
            }
        }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Start-VerifiedDownload {
    $started = Navigate-Requested
    if (-not $started) { return $false }
    if (Wait-ExpectedDownload) { return $true }

    Add-Log "Il file atteso non e comparso; ripeto automaticamente il download una volta ($ExpectedPattern)."
    $started = Navigate-Requested
    if ($started -and (Wait-ExpectedDownload)) { return $true }
    throw "Lightspeed ha avviato il download, ma il file atteso non e stato creato: $ExpectedPattern"
}

if ($LibraryOnly) { return }

try {
    Add-Log "Richiesta: $Url"
    if ($DownloadFolderOverride) {
        $DownloadDir = [IO.Path]::GetFullPath($DownloadFolderOverride)
        New-Item -ItemType Directory -Path $DownloadDir -Force | Out-Null
    }
    Start-DedicatedEdge
    Connect-Cdp
    Invoke-Cdp -Method 'Page.enable' | Out-Null
    Invoke-Cdp -Method 'Runtime.enable' | Out-Null
    try { Invoke-Cdp -Method 'Browser.setDownloadBehavior' -Params @{behavior='allow';downloadPath=$DownloadDir;eventsEnabled=$true} | Out-Null } catch {
        try { Invoke-Cdp -Method 'Page.setDownloadBehavior' -Params @{behavior='allow';downloadPath=$DownloadDir} | Out-Null } catch {}
    }
    Add-Log "Cartella download Lightspeed: $DownloadDir"

    $credential=Get-StoredCredential
    $reportMode=($Url.TrimEnd('/') -ne $LoginUrl.TrimEnd('/'))
    $downloadStarted=Start-VerifiedDownload
    if($downloadStarted){exit 0}

    $deadline=(Get-Date).AddSeconds($LoginTimeoutSeconds)
    $autoAttempts=0
    $nextAuto=Get-Date '2000-01-01'
    $loginObserved=$false
    $reportReissued=$false
    $readySince=$null
    $navigationAt=Get-Date

    while((Get-Date) -lt $deadline){
        Start-Sleep -Milliseconds 550
        try{
            $current=Get-CurrentUrl
            $loginLikely=Test-LoginPageLikely

            if($loginLikely){
                $loginObserved=$true
                $readySince=$null
                if($AutoLoginEnabled -and $credential -and $autoAttempts -lt 5 -and (Get-Date) -ge $nextAuto){
                    if(Try-AutoLogin -Credential $credential){
                        $autoAttempts++
                        $nextAuto=(Get-Date).AddSeconds(3)
                        Start-Sleep -Milliseconds 850
                        continue
                    }
                }
                continue
            }

            if($current -match '^https://manager\.lsk\.lightspeed\.app/'){
                if($reportMode -and $loginObserved -and -not $reportReissued){
                    Add-Log 'Login completato; riapro il report Lightspeed richiesto.'
                    $reportReissued=$true
                    $navigationAt=Get-Date
                    if(Start-VerifiedDownload){exit 0}
                    Start-Sleep -Milliseconds 700
                    continue
                }

                if($null -eq $readySince){$readySince=Get-Date}
                $stable=((Get-Date)-$readySince).TotalSeconds
                $navAge=((Get-Date)-$navigationAt).TotalSeconds

                if(-not $reportMode -and $stable -ge 1.8){
                    Add-Log 'Dashboard Lightspeed pronta.'
                    exit 0
                }

                if($reportMode -and $navAge -ge 3.0 -and $stable -ge 1.5){
                    Add-Log 'Richiesta report Lightspeed completata/avviata.'
                    exit 0
                }
            } else {
                $readySince=$null
            }
        }catch{
            if ($null -eq $script:WebSocket -or $script:WebSocket.State -ne [System.Net.WebSockets.WebSocketState]::Open) { throw "Connessione al browser interrotta. Riapri Lightspeed e riprova Cominciamo. Dettaglio: $($_.Exception.Message)" }
            Add-Log "Attesa Lightspeed: $($_.Exception.Message)"
        }
    }

    throw 'Tempo scaduto. Controlla le credenziali Lightspeed oppure effettua il login manualmente.'
}
catch {
    Add-Log "ERRORE: $($_.Exception.Message)"
    exit 1
}
finally {
    try{if($script:WebSocket){$script:WebSocket.Dispose()}}catch{}
}
